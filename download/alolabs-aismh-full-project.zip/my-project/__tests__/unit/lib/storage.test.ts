import { describe, it, expect, vi, beforeEach } from 'vitest';

// Direct mock functions — avoids the importOriginal issue where mocked named
// exports are not properly forwarded to the source module's imports in Vitest/Bun.
const mockWriteFile = vi.fn().mockResolvedValue(undefined);
const mockReadFile = vi.fn().mockResolvedValue(Buffer.from('test-file-content'));
const mockUnlink = vi.fn().mockResolvedValue(undefined);
const mockCopyFile = vi.fn().mockResolvedValue(undefined);
const mockStat = vi.fn().mockResolvedValue({
  size: 1024,
  mtime: new Date('2025-01-15'),
  isFile: () => true,
  isDirectory: () => false,
});
const mockReaddir = vi.fn().mockResolvedValue([]);
const mockMkdir = vi.fn().mockResolvedValue(undefined);
const mockRm = vi.fn().mockResolvedValue(undefined);

vi.mock('fs/promises', () => ({
  default: {
    writeFile: (...args: unknown[]) => mockWriteFile(...args),
    readFile: (...args: unknown[]) => mockReadFile(...args),
    unlink: (...args: unknown[]) => mockUnlink(...args),
    copyFile: (...args: unknown[]) => mockCopyFile(...args),
    stat: (...args: unknown[]) => mockStat(...args),
    readdir: (...args: unknown[]) => mockReaddir(...args),
    mkdir: (...args: unknown[]) => mockMkdir(...args),
    rm: (...args: unknown[]) => mockRm(...args),
  },
  writeFile: (...args: unknown[]) => mockWriteFile(...args),
  readFile: (...args: unknown[]) => mockReadFile(...args),
  unlink: (...args: unknown[]) => mockUnlink(...args),
  copyFile: (...args: unknown[]) => mockCopyFile(...args),
  stat: (...args: unknown[]) => mockStat(...args),
  readdir: (...args: unknown[]) => mockReaddir(...args),
  mkdir: (...args: unknown[]) => mockMkdir(...args),
  rm: (...args: unknown[]) => mockRm(...args),
}));

// We test the LocalStorageProvider class directly, mocking only fs
import { LocalStorageProvider } from '@/lib/storage/local-storage';

describe('LocalStorageProvider', () => {
  let provider: LocalStorageProvider;

  beforeEach(() => {
    vi.clearAllMocks();
    provider = new LocalStorageProvider({
      basePath: '/tmp/test-upload',
      maxFileSize: 1024 * 1024, // 1MB for tests
    });
  });

  // ─── Constructor ─────────────────────────────────────────────────

  describe('constructor', () => {
    it('should use provided basePath', () => {
      const p = new LocalStorageProvider({ basePath: '/custom/path' });
      expect(p).toBeDefined();
    });

    it('should use default maxFileSize when not specified', () => {
      const p = new LocalStorageProvider({ basePath: '/tmp/test' });
      expect(p).toBeDefined();
    });
  });

  // ─── Upload ──────────────────────────────────────────────────────

  describe('upload', () => {
    it('should reject empty files', async () => {
      await expect(provider.upload(Buffer.alloc(0), 'empty.txt'))
        .rejects.toThrow('File is empty');
    });

    it('should reject files exceeding max size', async () => {
      const bigFile = Buffer.alloc(2 * 1024 * 1024); // 2MB > 1MB limit
      await expect(provider.upload(bigFile, 'big.bin'))
        .rejects.toThrow('exceeds maximum size');
    });

    it('should reject files not matching allowed types', async () => {
      const pngBuffer = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00]);
      await expect(
        provider.upload(pngBuffer, 'test.exe', {
          allowedTypes: ['application/pdf'],
        }),
      ).rejects.toThrow('not allowed');
    });

    it('should return an UploadedFile object on success', async () => {
      const buffer = Buffer.from('hello world');
      const result = await provider.upload(buffer, 'test.txt');

      expect(result).toBeDefined();
      expect(result.originalName).toContain('test.txt');
      expect(result.size).toBe(buffer.length);
      expect(result.mimeType).toBe('text/plain');
      expect(result.url).toContain('/api/storage/files?key=');
      expect(result.createdAt).toBeInstanceOf(Date);
    });

    it('should upload to a custom folder when specified', async () => {
      const buffer = Buffer.from('test data');
      const result = await provider.upload(buffer, 'doc.pdf', { folder: 'documents' });
      expect(result.id).toContain('documents/');
    });
  });

  // ─── Download ────────────────────────────────────────────────────

  describe('download', () => {
    it('should return file content as a buffer', async () => {
      const buffer = await provider.download('2025-01-15/some-file.txt');
      expect(Buffer.isBuffer(buffer)).toBe(true);
    });

    it('should throw a descriptive error when file not found', async () => {
      mockReadFile.mockRejectedValueOnce(new Error('ENOENT'));
      await expect(provider.download('nonexistent.txt'))
        .rejects.toThrow('Local download failed');
    });
  });

  // ─── Delete ──────────────────────────────────────────────────────

  describe('delete', () => {
    it('should call unlink with the correct path', async () => {
      await provider.delete('2025-01-15/file.txt');
      expect(mockUnlink).toHaveBeenCalledWith(
        expect.stringContaining('2025-01-15/file.txt'),
      );
    });

    it('should throw a descriptive error on failure', async () => {
      mockUnlink.mockRejectedValueOnce(new Error('ENOENT'));
      await expect(provider.delete('missing.txt'))
        .rejects.toThrow('Local delete failed');
    });
  });

  // ─── getPublicUrl ────────────────────────────────────────────────

  describe('getPublicUrl', () => {
    it('should generate a URL with the file key', () => {
      const url = provider.getPublicUrl('2025-01-15/abc-file.txt');
      expect(url).toBe('/api/storage/files?key=2025-01-15%2Fabc-file.txt');
    });
  });

  // ─── exists ──────────────────────────────────────────────────────

  describe('exists', () => {
    it('should return true when file exists', async () => {
      mockStat.mockResolvedValueOnce({} as any);
      expect(await provider.exists('some-file.txt')).toBe(true);
    });

    it('should return false when file does not exist', async () => {
      mockStat.mockRejectedValueOnce(new Error('ENOENT'));
      expect(await provider.exists('missing.txt')).toBe(false);
    });
  });

  // ─── verifySignedUrl ─────────────────────────────────────────────

  describe('verifySignedUrl', () => {
    it('should return true for a valid signed URL', async () => {
      const fileId = 'test-file.txt';
      const url = await provider.getSignedUrl(fileId, 3600);
      const parsed = new URL(url, 'http://localhost');
      const expires = parseInt(parsed.searchParams.get('expires')!, 10);
      const sig = parsed.searchParams.get('sig')!;

      expect(provider.verifySignedUrl(fileId, expires, sig)).toBe(true);
    });

    it('should return false for an expired URL', () => {
      const pastExpires = Math.floor(Date.now() / 1000) - 100;
      expect(provider.verifySignedUrl('file.txt', pastExpires, 'invalidsig')).toBe(false);
    });

    it('should return false for a tampered signature', () => {
      const futureExpires = Math.floor(Date.now() / 1000) + 3600;
      expect(provider.verifySignedUrl('file.txt', futureExpires, 'tampered')).toBe(false);
    });
  });

  // ─── copy ────────────────────────────────────────────────────────

  describe('copy', () => {
    it('should throw when source file does not exist', async () => {
      mockStat.mockRejectedValueOnce(new Error('ENOENT'));
      await expect(provider.copy('missing.txt', 'dest.txt'))
        .rejects.toThrow('Source file not found');
    });

    it('should return uploaded file info on success', async () => {
      const result = await provider.copy('source.txt', 'dest/destination.txt');
      expect(result).toBeDefined();
      expect(result.id).toBe('dest/destination.txt');
    });
  });
});