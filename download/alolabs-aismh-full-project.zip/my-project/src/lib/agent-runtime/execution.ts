/**
 * Agent Execution Engine
 * The CORE of the agent runtime. Connects AI router to real agent execution.
 */

import type {
  AgentTask, ExecutionResult, ExecutionError, TokenUsage,
  TaskPriority, DelegationResult,
} from './types';
import { DEFAULT_TIMEOUT_MS, MAX_DELEGATION_DEPTH, PRIORITY_WEIGHTS } from './types';
import { getAgentStateManager } from './state';
import { getAgentHealthMonitor } from './health';
import { db } from '@/lib/db';
import { getRouter } from '@/lib/ai-router';

// ─── Execution Queue (priority-sorted) ─────────────────────────────

class PriorityQueue {
  private queue: AgentTask[] = [];

  enqueue(task: AgentTask): void {
    const weight = PRIORITY_WEIGHTS[task.priority] ?? 10;
    // Insert sorted by priority (highest first)
    let inserted = false;
    for (let i = 0; i < this.queue.length; i++) {
      const existingWeight = PRIORITY_WEIGHTS[this.queue[i].priority] ?? 10;
      if (weight > existingWeight) {
        this.queue.splice(i, 0, task);
        inserted = true;
        break;
      }
    }
    if (!inserted) this.queue.push(task);
  }

  dequeue(): AgentTask | undefined {
    return this.queue.shift();
  }

  remove(taskId: string): void {
    this.queue = this.queue.filter(t => t.id !== taskId);
  }

  peek(): AgentTask | undefined {
    return this.queue[0];
  }

  get size(): number {
    return this.queue.length;
  }

  all(): AgentTask[] {
    return [...this.queue];
  }
}

// ─── Execution Engine ──────────────────────────────────────────────

export class AgentExecutionEngine {
  private stateManager: ReturnType<typeof getAgentStateManager>;
  private healthMonitor: ReturnType<typeof getAgentHealthMonitor>;
  private queue = new PriorityQueue();
  private processing = false;
  private delegationDepth = new Map<string, number>(); // taskId -> depth
  private abortControllers = new Map<string, AbortController>();
  private dispatchTimer: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.stateManager = getAgentStateManager();
    this.healthMonitor = getAgentHealthMonitor();
    this.startDispatcher();
  }

  // ─── Public API ────────────────────────────────────────────────

  /**
   * Submit a task for execution.
   * If async, queues and returns immediately.
   * If sync, blocks until completion.
   */
  async execute(params: {
    agentId: string;
    companyId: string;
    userId: string;
    task: string;
    priority?: TaskPriority;
    systemPrompt?: string;
    context?: Record<string, unknown>;
    tools?: string[];
    maxTokens?: number;
    timeoutMs?: number;
    mode?: 'sync' | 'async';
    parentTaskId?: string;
    delegationDepth?: number;
  }): Promise<AgentTask> {
    const taskId = `task_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const mode = params.mode ?? 'async';

    const agentTask: AgentTask = {
      id: taskId,
      agentId: params.agentId,
      companyId: params.companyId,
      userId: params.userId,
      parentTaskId: params.parentTaskId,
      tier: 'worker',
      priority: params.priority ?? 'normal',
      riskLevel: 'low',
      status: 'created',
      mode: mode === 'sync' ? 'sync' : 'async',
      input: params.task,
      context: params.context,
      systemPrompt: params.systemPrompt,
      tools: params.tools,
      maxTokens: params.maxTokens,
      timeoutMs: params.timeoutMs ?? DEFAULT_TIMEOUT_MS,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.stateManager.createTask(agentTask);

    if (mode === 'sync') {
      return this.runTask(taskId);
    }

    // Async: enqueue
    this.stateManager.transition(taskId, 'ready', 'Queued for execution');
    this.queue.enqueue(this.stateManager.getTask(taskId)!);

    return this.stateManager.getTask(taskId)!;
  }

  /** Cancel a running task */
  cancel(taskId: string): boolean {
    const task = this.stateManager.getTask(taskId);
    if (!task) return false;
    if (task.status !== 'running' && task.status !== 'ready') return false;

    this.queue.remove(taskId);
    const controller = this.abortControllers.get(taskId);
    if (controller) {
      controller.abort();
      this.abortControllers.delete(taskId);
    }

    try {
      this.stateManager.transition(taskId, 'failed', 'Cancelled by user');
    } catch { /* already in terminal state */ }
    return true;
  }

  /** Delegate a task to another agent */
  async delegate(params: {
    sourceTaskId: string;
    targetAgentId: string;
    task: string;
    context?: Record<string, unknown>;
  }): Promise<ExecutionResult> {
    const sourceTask = this.stateManager.getTask(params.sourceTaskId);
    if (!sourceTask) throw new Error(`Source task ${params.sourceTaskId} not found`);

    const currentDepth = this.delegationDepth.get(params.sourceTaskId) ?? 0;
    if (currentDepth >= MAX_DELEGATION_DEPTH) {
      throw new Error(`Max delegation depth (${MAX_DELEGATION_DEPTH}) exceeded`);
    }

    const result = await this.execute({
      agentId: params.targetAgentId,
      companyId: sourceTask.companyId,
      userId: sourceTask.userId,
      task: params.task,
      context: { ...params.context, delegatedFrom: params.sourceTaskId },
      mode: 'sync',
      parentTaskId: params.sourceTaskId,
      delegationDepth: currentDepth + 1,
    });

    return result.result!;
  }

  /** Get current queue status */
  getStatus() {
    return {
      queueDepth: this.queue.size,
      activeTasks: this.stateManager.getActiveTasks().length,
      processing: this.processing,
    };
  }

  /** Get all queued tasks */
  getQueue(): AgentTask[] {
    return this.queue.all();
  }

  destroy(): void {
    if (this.dispatchTimer) {
      clearInterval(this.dispatchTimer);
      this.dispatchTimer = null;
    }
    for (const controller of this.abortControllers.values()) {
      controller.abort();
    }
    this.abortControllers.clear();
    this.stateManager.destroy();
  }

  // ─── Internal: Task Runner ─────────────────────────────────────

  private async runTask(taskId: string): Promise<AgentTask> {
    const task = this.stateManager.getTask(taskId);
    if (!task) throw new Error(`Task ${taskId} not found`);

    const startTime = Date.now();
    const abortController = new AbortController();
    this.abortControllers.set(taskId, abortController);

    try {
      // 1. Transition to running
      if (!this.stateManager.canExecute(task.agentId, task.companyId)) {
        // Queue if at capacity
        if (task.status === 'created') {
          this.stateManager.transition(taskId, 'ready', 'At capacity, requeued');
          this.queue.enqueue(this.stateManager.getTask(taskId)!);
          return this.stateManager.getTask(taskId)!;
        }
      }

      this.stateManager.acquireSlot(task.agentId, task.companyId);
      this.stateManager.transition(taskId, 'running', 'Execution started');

      // 2. Load agent config from DB
      const agent = await db.agent.findUnique({ where: { agentId: task.agentId } });
      if (!agent) {
        throw new Error(`Agent ${task.agentId} not found in database`);
      }

      // 3. Build system prompt
      const systemPrompt = this.buildSystemPrompt(task, agent.selfImprovement ?? undefined);

      // 4. Build messages
      const messages = [
        { role: 'system' as const, content: systemPrompt },
        { role: 'user' as const, content: task.input },
      ];

      // 5. Add context as additional user message if provided
      if (task.context && Object.keys(task.context).length > 0) {
        messages.splice(1, 0, {
          role: 'user' as const,
          content: `Additional context:\n${JSON.stringify(task.context, null, 2)}`,
        });
      }

      // 6. Call AI Router
      const router = getRouter();
      const aiResponse = await router.chat(
        {
          model: '',
          messages,
          maxTokens: task.maxTokens ?? 4096,
          temperature: 0.7,
        },
        task.companyId,
        task.agentId,
      );

      // 7. Record token usage
      this.stateManager.recordTokens(task.companyId, aiResponse.usage.totalTokens);

      const tokenUsage: TokenUsage = {
        promptTokens: aiResponse.usage.promptTokens,
        completionTokens: aiResponse.usage.completionTokens,
        totalTokens: aiResponse.usage.totalTokens,
        costUsd: this.estimateCost(aiResponse.usage.totalTokens, aiResponse.model),
      };

      // 8. Build result
      const result: ExecutionResult = {
        content: aiResponse.content,
        confidence: 0.85,
        metadata: {
          model: aiResponse.model,
          finishReason: aiResponse.finishReason,
          latencyMs: aiResponse.latencyMs,
        },
      };

      // 9. Update task
      task.result = result;
      task.tokenUsage = tokenUsage;
      this.stateManager.transition(taskId, 'completed', 'Execution succeeded');

      // 10. Record health
      this.healthMonitor.recordSuccess(task.agentId, Date.now() - startTime);

      // 11. Audit log
      await this.createAuditLog(task, 'success', aiResponse.latencyMs);

      // 12. Store in DB if AuditLog model exists
      try {
        await db.auditLog.create({
          data: {
            action: 'agent_execution',
            resource: task.agentId,
            userId: task.userId,
            details: JSON.stringify({
              taskId, agentId: task.agentId, companyId: task.companyId,
              tokens: tokenUsage.totalTokens,
              latencyMs: Date.now() - startTime,
            }),
          },
        });
      } catch { /* audit log table might not exist */ }

      return this.stateManager.getTask(taskId)!;
    } catch (error) {
      const latency = Date.now() - startTime;
      const errorMessage = error instanceof Error ? error.message : String(error);
      const retryable = this.isRetryable(error);

      task.error = {
        code: this.classifyError(error),
        message: errorMessage,
        retryable,
        attempts: (task.error?.attempts ?? 0) + 1,
        maxRetries: 3,
        lastAttemptAt: new Date(),
      };

      try {
        this.stateManager.transition(taskId, 'failed', `Execution failed: ${errorMessage}`);
      } catch { /* already in terminal state */ }

      this.healthMonitor.recordFailure(task.agentId, latency, errorMessage);

      await this.createAuditLog(task, 'failure', latency).catch(() => {});

      return this.stateManager.getTask(taskId)!;
    } finally {
      this.abortControllers.delete(taskId);
      this.stateManager.releaseSlot(task.companyId);
    }
  }

  // ─── Internal: Dispatcher ──────────────────────────────────────

  private startDispatcher(): void {
    // Process queue every 500ms
    this.dispatchTimer = setInterval(() => {
      this.processQueue();
    }, 500);
  }

  private processQueue(): void {
    if (this.processing) return;
    if (this.queue.size === 0) return;

    const task = this.queue.dequeue();
    if (!task) return;

    // Skip if no longer in ready state
    if (task.status !== 'ready') return;

    this.processing = true;
    this.runTask(task.id)
      .catch((err) => console.error(`[AgentRuntime] Task ${task.id} error:`, err))
      .finally(() => { this.processing = false; });
  }

  // ─── Internal: Helpers ─────────────────────────────────────────

  private buildSystemPrompt(task: AgentTask, agentSystemPrompt?: string): string {
    const parts: string[] = [];

    if (agentSystemPrompt) {
      parts.push(agentSystemPrompt);
    } else {
      parts.push('You are a helpful AI assistant. Follow instructions carefully and provide accurate, useful responses.');
    }

    parts.push(`\nTask ID: ${task.id}`);
    parts.push(`Agent ID: ${task.agentId}`);
    parts.push(`Priority: ${task.priority}`);
    parts.push(`Risk Level: ${task.riskLevel}`);

    if (task.tools && task.tools.length > 0) {
      parts.push(`\nAvailable tools: ${task.tools.join(', ')}`);
    }

    return parts.join('\n');
  }

  private estimateCost(totalTokens: number, model: string): number {
    // Rough cost estimation (per 1M tokens)
 const costPerMillion: Record<string, number> = {
      'claude-3.5-sonnet': 3, 'gpt-4o': 2.5, 'gpt-4o-mini': 0.15,
      'llama3': 0, 'mistral': 0.4, 'deepseek': 0.14,
    };
    const rate = Object.entries(costPerMillion).find(([k]) => model.includes(k))?.[1] ?? 2;
    return (totalTokens / 1_000_000) * rate;
  }

  private isRetryable(error: unknown): boolean {
    if (error instanceof Error) {
      const msg = error.message.toLowerCase();
      return (
        msg.includes('timeout') ||
        msg.includes('econnrefused') ||
        msg.includes('econnreset') ||
        msg.includes('503') ||
        msg.includes('429') ||
        msg.includes('circuit')
      );
    }
    return false;
  }

  private classifyError(error: unknown): string {
    if (error instanceof Error) {
      const msg = error.message.toLowerCase();
      if (msg.includes('timeout')) return 'TIMEOUT';
      if (msg.includes('rate limit') || msg.includes('429')) return 'RATE_LIMITED';
      if (msg.includes('circuit')) return 'CIRCUIT_OPEN';
      if (msg.includes('not found')) return 'NOT_FOUND';
      if (msg.includes('auth') || msg.includes('unauthorized')) return 'AUTH_ERROR';
      if (msg.includes('budget') || msg.includes('token')) return 'BUDGET_EXCEEDED';
    }
    return 'UNKNOWN_ERROR';
  }

  private async createAuditLog(
    task: AgentTask,
    _status: string,
    _latency: number,
  ): Promise<void> {
    // Audit logging is done in the runTask success/failure paths
    // This method is a hook point for extensibility
  }
}

// Singleton
let _instance: AgentExecutionEngine | null = null;
export function getExecutionEngine(): AgentExecutionEngine {
  if (!_instance) _instance = new AgentExecutionEngine();
  return _instance;
}