/**
 * Agent Health Monitor
 * Tracks execution metrics and computes health scores for each agent.
 */

import type { AgentHealthSnapshot, TokenUsage } from './types';

interface HealthRecord {
  agentId: string;
  successCount: number;
  failCount: number;
  totalLatencyMs: number;
  recentLatencies: number[];  // last 100
  recentResults: boolean[];   // last 100: true=success
  lastExecutionAt: Date | null;
  lastErrorAt: Date | null;
  consecutiveFailures: number;
  lastError?: string;
}

class HealthStore {
  private records = new Map<string, HealthRecord>();
  private maxHistory = 100;

  get(agentId: string): HealthRecord | undefined {
    return this.records.get(agentId);
  }

  getOrCreate(agentId: string): HealthRecord {
    let rec = this.records.get(agentId);
    if (!rec) {
      rec = {
        agentId,
        successCount: 0, failCount: 0, totalLatencyMs: 0,
        recentLatencies: [], recentResults: [],
        lastExecutionAt: null, lastErrorAt: null,
        consecutiveFailures: 0,
      };
      this.records.set(agentId, rec);
    }
    return rec;
  }

  recordSuccess(agentId: string, latencyMs: number): void {
    const rec = this.getOrCreate(agentId);
    rec.successCount++;
    rec.totalLatencyMs += latencyMs;
    rec.recentLatencies.push(latencyMs);
    if (rec.recentLatencies.length > this.maxHistory) rec.recentLatencies.shift();
    rec.recentResults.push(true);
    if (rec.recentResults.length > this.maxHistory) rec.recentResults.shift();
    rec.lastExecutionAt = new Date();
    rec.consecutiveFailures = 0;
  }

  recordFailure(agentId: string, latencyMs: number, error?: string): void {
    const rec = this.getOrCreate(agentId);
    rec.failCount++;
    rec.totalLatencyMs += latencyMs;
    rec.recentLatencies.push(latencyMs);
    if (rec.recentLatencies.length > this.maxHistory) rec.recentLatencies.shift();
    rec.recentResults.push(false);
    if (rec.recentResults.length > this.maxHistory) rec.recentResults.shift();
    rec.lastExecutionAt = new Date();
    rec.lastErrorAt = new Date();
    rec.consecutiveFailures++;
    if (error) rec.lastError = error;
  }

  all(): HealthRecord[] {
    return Array.from(this.records.values());
  }

  clear(agentId: string): void {
    this.records.delete(agentId);
  }
}

export class AgentHealthMonitor {
  private store = new HealthStore();

  /** Record a successful execution */
  recordSuccess(agentId: string, latencyMs: number): void {
    this.store.recordSuccess(agentId, latencyMs);
  }

  /** Record a failed execution */
  recordFailure(agentId: string, latencyMs: number, error?: string): void {
    this.store.recordFailure(agentId, latencyMs, error);
  }

  /** Get health snapshot for a specific agent */
  getHealth(agentId: string): AgentHealthSnapshot {
    const rec = this.store.get(agentId);
    if (!rec) {
      return {
        agentId, status: 'ready', healthScore: 100,
        successRate: 1, avgLatencyMs: 0, errorRate: 0,
        totalExecutions: 0, consecutiveFailures: 0, isDegraded: false,
      };
    }

    const total = rec.successCount + rec.failCount;
    const successRate = total > 0 ? rec.successCount / total : 1;
    const avgLatency = rec.recentLatencies.length > 0
      ? rec.recentLatencies.reduce((a, b) => a + b, 0) / rec.recentLatencies.length
      : 0;
    const errorRate = rec.recentResults.length > 0
      ? rec.recentResults.filter(r => !r).length / rec.recentResults.length
      : 0;

    // Health score: 0-100 based on success rate, latency, and failures
    const score = Math.round(
      (successRate * 50) +
      (Math.max(0, 1 - avgLatency / 30_000) * 30) +
      (Math.max(0, 1 - rec.consecutiveFailures / 5) * 20)
    );

    return {
      agentId,
      status: rec.consecutiveFailures >= 5 ? 'failed' : rec.consecutiveFailures >= 3 ? 'degraded' as any : 'ready',
      healthScore: score,
      successRate: Math.round(successRate * 1000) / 1000,
      avgLatencyMs: Math.round(avgLatency),
      errorRate: Math.round(errorRate * 1000) / 1000,
      totalExecutions: total,
      lastExecutionAt: rec.lastExecutionAt ?? undefined,
      lastErrorAt: rec.lastErrorAt ?? undefined,
      consecutiveFailures: rec.consecutiveFailures,
      isDegraded: score < 50,
    };
  }

  /** Get health for all agents */
  getAllHealth(): AgentHealthSnapshot[] {
    const knownIds = new Set<string>();
    for (const rec of this.store.all()) knownIds.add(rec.agentId);
    return Array.from(knownIds).map(id => this.getHealth(id));
  }

  /** Get only degraded or failing agents */
  getUnhealthyAgents(): AgentHealthSnapshot[] {
    return this.getAllHealth().filter(h => h.isDegraded || h.consecutiveFailures >= 3);
  }

  /** Reset health data for an agent */
  resetHealth(agentId: string): void {
    this.store.clear(agentId);
  }
}

// Singleton
let _instance: AgentHealthMonitor | null = null;
export function getAgentHealthMonitor(): AgentHealthMonitor {
  if (!_instance) _instance = new AgentHealthMonitor();
  return _instance;
}