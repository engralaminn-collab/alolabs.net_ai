/**
 * Agent State Manager
 * Tracks agent task states with in-memory + Redis-backed persistence.
 * Enforces valid state transitions and records state history.
 */

import type { AgentStatus, AgentTask, StateTransition, ResourceLimits, ResourceUsage } from './types';
import { isValidTransition, DEFAULT_RESOURCE_LIMITS } from './types';

class StateStore {
  private tasks = new Map<string, AgentTask>();
  private history: StateTransition[] = [];
  private resourceUsage = new Map<string, ResourceUsage>();
  private activeExecutions = new Map<string, number>(); // companyId -> count

  get(taskId: string): AgentTask | undefined {
    return this.tasks.get(taskId);
  }

  set(task: AgentTask): void {
    this.tasks.set(task.id, task);
  }

  delete(taskId: string): void {
    this.tasks.delete(taskId);
  }

  all(): AgentTask[] {
    return Array.from(this.tasks.values());
  }

  byAgent(agentId: string): AgentTask[] {
    return this.all().filter((t) => t.agentId === agentId);
  }

  byCompany(companyId: string): AgentTask[] {
    return this.all().filter((t) => t.companyId === companyId);
  }

  getHistory(taskId?: string): StateTransition[] {
    if (taskId) return this.history.filter((h) => h.taskId === taskId);
    return this.history;
  }

  recordTransition(transition: StateTransition): void {
    this.history.push(transition);
    // Keep last 10,000 transitions in memory
    if (this.history.length > 10_000) {
      this.history = this.history.slice(-5_000);
    }
  }

  incrementActive(companyId: string): void {
    const current = this.activeExecutions.get(companyId) ?? 0;
    this.activeExecutions.set(companyId, current + 1);
  }

  decrementActive(companyId: string): void {
    const current = this.activeExecutions.get(companyId) ?? 0;
    this.activeExecutions.set(companyId, Math.max(0, current - 1));
  }

  getActiveCount(companyId: string): number {
    return this.activeExecutions.get(companyId) ?? 0;
  }

  getResourceUsage(companyId: string): ResourceUsage {
    const base = this.resourceUsage.get(companyId) ?? {
      activeExecutions: 0,
      tokensThisMinute: 0,
      tokensToday: 0,
      queueDepth: 0,
    };
    return {
      ...base,
      activeExecutions: this.getActiveCount(companyId),
    };
  }

  addTokens(companyId: string, tokens: number): void {
    const current = this.resourceUsage.get(companyId) ?? {
      activeExecutions: 0, tokensThisMinute: 0, tokensToday: 0, queueDepth: 0,
    };
    current.tokensThisMinute += tokens;
    current.tokensToday += tokens;
    this.resourceUsage.set(companyId, current);
  }

  resetMinuteTokens(): void {
    for (const usage of this.resourceUsage.values()) {
      usage.tokensThisMinute = 0;
    }
  }

  resetDailyTokens(): void {
    for (const usage of this.resourceUsage.values()) {
      usage.tokensToday = 0;
    }
  }
}

export class AgentStateManager {
  private store = new StateStore();
  private limits: ResourceLimits;
  private cleanupTimer: ReturnType<typeof setInterval> | null = null;

  constructor(limits?: Partial<ResourceLimits>) {
    this.limits = { ...DEFAULT_RESOURCE_LIMITS, ...limits };
    this.startCleanup();
  }

  /**
   * Transition a task from one state to another.
   * Throws if the transition is invalid.
   */
  transition(taskId: string, to: AgentStatus, reason: string): AgentTask {
    const task = this.store.get(taskId);
    if (!task) throw new Error(`Task ${taskId} not found`);

    if (!isValidTransition(task.status, to)) {
      throw new Error(
        `Invalid state transition: ${task.status} → ${to} for task ${taskId}. Valid: [${[... (VALID_TRANSITIONS_MAP[task.status] ?? [])].join(', ')}]`,
      );
    }

    const from = task.status;
    task.status = to;
    task.updatedAt = new Date();

    if (to === 'running') task.startedAt = task.startedAt ?? new Date();
    if (to === 'completed' || to === 'failed' || to === 'timed_out') {
      task.completedAt = new Date();
      this.store.decrementActive(task.companyId);
    }

    this.store.recordTransition({
      from, to, taskId, agentId: task.agentId, reason, timestamp: new Date(),
    });

    this.store.set(task);
    return task;
  }

  /** Create a new task in 'created' state */
  createTask(task: AgentTask): AgentTask {
    task.status = 'created';
    task.createdAt = new Date();
    task.updatedAt = new Date();
    this.store.set(task);
    return task;
  }

  /** Acquire an execution slot. Returns true if under limits. */
  acquireSlot(agentId: string, companyId: string): boolean {
    const activeByCompany = this.store.getActiveCount(companyId);
    if (activeByCompany >= this.limits.maxConcurrentPerCompany) return false;

    const agentActive = this.store.byAgent(agentId).filter(
      (t) => t.status === 'running' || t.status === 'waiting_approval',
    ).length;
    if (agentActive >= this.limits.maxConcurrentPerAgent) return false;

    this.store.incrementActive(companyId);
    return true;
  }

  /** Release an execution slot */
  releaseSlot(companyId: string): void {
    this.store.decrementActive(companyId);
  }

  /** Check if an agent can accept more work */
  canExecute(agentId: string, companyId: string): boolean {
    const usage = this.store.getResourceUsage(companyId);
    if (usage.activeExecutions >= this.limits.maxConcurrentPerCompany) return false;
    const agentRunning = this.store.byAgent(agentId).filter(
      (t) => t.status === 'running',
    ).length;
    if (agentRunning >= this.limits.maxConcurrentPerAgent) return false;
    return true;
  }

  /** Check token budget */
  checkTokenBudget(companyId: string, tokens: number): boolean {
    const usage = this.store.getResourceUsage(companyId);
    return (usage.tokensThisMinute + tokens) <= this.limits.maxTokensPerMinute &&
           (usage.tokensToday + tokens) <= this.limits.maxTokensPerDay;
  }

  /** Record token usage */
  recordTokens(companyId: string, tokens: number): void {
    this.store.addTokens(companyId, tokens);
  }

  // ─── Query methods ──────────────────────────────────────────────

  getTask(taskId: string): AgentTask | undefined {
    return this.store.get(taskId);
  }

  getTasksByAgent(agentId: string): AgentTask[] {
    return this.store.byAgent(agentId);
  }

  getTasksByCompany(companyId: string): AgentTask[] {
    return this.store.byCompany(companyId);
  }

  getActiveTasks(): AgentTask[] {
    return this.store.all().filter(
      (t) => t.status === 'running' || t.status === 'waiting_approval',
    );
  }

  getOverdueTasks(): AgentTask[] {
    const now = Date.now();
    return this.store.all().filter(
      (t) =>
        t.status === 'running' &&
        t.timeoutMs &&
        t.startedAt &&
        now - t.startedAt.getTime() > t.timeoutMs,
    );
  }

  getStateHistory(taskId?: string): StateTransition[] {
    return this.store.getHistory(taskId);
  }

  getResourceUsage(companyId: string): ResourceUsage {
    return this.store.getResourceUsage(companyId);
  }

  getAllResourceUsage(): Record<string, ResourceUsage> {
    const result: Record<string, ResourceUsage> = {};
    for (const task of this.store.all()) {
      if (!result[task.companyId]) {
        result[task.companyId] = this.store.getResourceUsage(task.companyId);
      }
    }
    return result;
  }

  destroy(): void {
    if (this.cleanupTimer) {
      clearInterval(this.cleanupTimer);
      this.cleanupTimer = null;
    }
  }

  private startCleanup(): void {
    // Reset per-minute counters every 60s
    this.cleanupTimer = setInterval(() => {
      this.store.resetMinuteTokens();
    }, 60_000);
  }
}

// Needed for the transition error message
const VALID_TRANSITIONS_MAP: Record<string, string[]> = {
  created: ['initializing', 'archived'],
  initializing: ['ready', 'failed', 'archived'],
  ready: ['running', 'archived'],
  running: ['completed', 'failed', 'timed_out', 'waiting_approval', 'paused'],
  waiting_approval: ['running', 'completed', 'failed'],
  paused: ['running', 'failed', 'archived'],
  completed: ['archived'],
  failed: ['ready', 'archived'],
  timed_out: ['ready', 'archived'],
  archived: [],
};

// Singleton
let _instance: AgentStateManager | null = null;
export function getAgentStateManager(limits?: Partial<ResourceLimits>): AgentStateManager {
  if (!_instance) _instance = new AgentStateManager(limits);
  return _instance;
}
