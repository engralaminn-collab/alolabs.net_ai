/**
 * Media Processing Utilities
 * Provides image processing (resize, compress, format conversion, thumbnail generation)
 * and media validation. Uses sharp when available; provides basic fallback otherwise.
 */

import type { ImageMetadata, ImageProcessOptions, ValidationResult } from './types';

// ─── Sharp Module (lazy loaded) ───────────────────────────────────────────────

type SharpPipeline = {
  resize: (options: { width?: number; height?: number; fit?: string; withoutEnlargement?: boolean }) => SharpPipeline;
  jpeg: (options?: { quality?: number }) => SharpPipeline;
  png: (options?: { quality?: number }) => SharpPipeline;
  webp: (options?: { quality?: number }) => SharpPipeline;
  toFormat: (format: string, options?: { quality?: number }) => SharpPipeline;
  toBuffer: () => Promise<Buffer>;
  metadata: () => Promise<{ width: number; height: number; format: string; size: number; channels?: number }>;
  clone: () => SharpPipeline;
};

type SharpConstructor = new (buf: Buffer) => SharpPipeline;

let sharpCtor: SharpConstructor | null = null;
let sharpChecked = false;

async function getSharp(): Promise<SharpConstructor | null> {
  if (sharpChecked) {
    return sharpCtor;
  }

  sharpChecked = true;
  try {
    const mod = await import('sharp');
    const Sharp = (mod.default || mod) as unknown as SharpConstructor;
    sharpCtor = Sharp;
    return Sharp;
  } catch {
    return null;
  }
}

// ─── Image Format Detection ───────────────────────────────────────────────────

const IMAGE_SIGNATURES: ReadonlyArray<{ offset: number; bytes: number[]; mimeType: string }> = [
  { offset: 0, bytes: [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a], mimeType: 'image/png' },
  { offset: 0, bytes: [0xff, 0xd8, 0xff], mimeType: 'image/jpeg' },
  { offset: 0, bytes: [0x47, 0x49, 0x46, 0x38], mimeType: 'image/gif' },
  { offset: 0, bytes: [0x42, 0x4d], mimeType: 'image/bmp' },
  { offset: 8, bytes: [0x57, 0x45, 0x42, 0x50], mimeType: 'image/webp' },
  { offset: 0, bytes: [0x52, 0x49, 0x46, 0x46], mimeType: 'image/webp' },
];

const VIDEO_SIGNATURES: ReadonlyArray<{ offset: number; bytes: number[]; mimeType: string }> = [
  { offset: 0, bytes: [0x00, 0x00, 0x00, 0x18, 0x66, 0x74, 0x79, 0x70], mimeType: 'video/mp4' },
  { offset: 0, bytes: [0x00, 0x00, 0x00, 0x1c, 0x66, 0x74, 0x79, 0x70], mimeType: 'video/mp4' },
  { offset: 0, bytes: [0x00, 0x00, 0x00, 0x20, 0x66, 0x74, 0x79, 0x70], mimeType: 'video/mp4' },
  { offset: 0, bytes: [0x1a, 0x45, 0xdf, 0xa3], mimeType: 'video/webm' },
  { offset: 0, bytes: [0x46, 0x4c, 0x56], mimeType: 'video/x-flv' },
];

// ─── Default Allowed Types ────────────────────────────────────────────────────

const DEFAULT_ALLOWED_IMAGE_TYPES = [
  'image/jpeg',
  'image/png',
  'image/gif',
  'image/webp',
  'image/bmp',
  'image/svg+xml',
];

const MAX_IMAGE_SIZE = 50 * 1024 * 1024; // 50 MB
const MAX_VIDEO_SIZE = 500 * 1024 * 1024; // 500 MB

// ─── MediaProcessor ───────────────────────────────────────────────────────────

export class MediaProcessor {
  /**
   * Detect the MIME type of a buffer from magic bytes.
   */
  detectImageType(buffer: Buffer): string | null {
    for (const sig of IMAGE_SIGNATURES) {
      if (buffer.length > sig.offset + sig.bytes.length) {
        let match = true;
        for (let i = 0; i < sig.bytes.length; i++) {
          if (buffer[sig.offset + i] !== sig.bytes[i]) {
            match = false;
            break;
          }
        }
        if (match) return sig.mimeType;
      }
    }
    return null;
  }

  /**
   * Detect the MIME type of a video buffer from magic bytes.
   */
  detectVideoType(buffer: Buffer): string | null {
    for (const sig of VIDEO_SIGNATURES) {
      if (buffer.length > sig.offset + sig.bytes.length) {
        let match = true;
        for (let i = 0; i < sig.bytes.length; i++) {
          if (buffer[sig.offset + i] !== sig.bytes[i]) {
            match = false;
            break;
          }
        }
        if (match) return sig.mimeType;
      }
    }
    return null;
  }

  /**
   * Process an image: resize, compress, and optionally convert format.
   */
  async processImage(buffer: Buffer, options: ImageProcessOptions = {}): Promise<Buffer> {
    const Sharp = await getSharp();

    if (Sharp) {
      return this.processWithSharp(buffer, options, Sharp);
    }

    return this.processBasic(buffer, options);
  }

  /**
   * Generate a thumbnail from an image buffer.
   */
  async generateThumbnail(buffer: Buffer, width: number, height: number): Promise<Buffer> {
    return this.processImage(buffer, {
      maxWidth: width,
      maxHeight: height,
      quality: 80,
      format: 'jpeg',
    });
  }

  /**
   * Extract metadata (dimensions, type, size) from an image buffer.
   */
  async getMetadata(buffer: Buffer): Promise<ImageMetadata> {
    const Sharp = await getSharp();

    if (Sharp) {
      try {
        const sharpInstance = new (Sharp as SharpConstructor)(buffer);
        const meta = await sharpInstance.metadata();
        return {
          width: meta.width || 0,
          height: meta.height || 0,
          mimeType: `image/${meta.format || 'unknown'}`,
          size: meta.size || buffer.length,
        };
      } catch {
        // Fall through to basic
      }
    }

    return this.getBasicMetadata(buffer);
  }

  /**
   * Compress an image buffer to the specified quality.
   */
  async compressImage(buffer: Buffer, quality: number = 80): Promise<Buffer> {
    return this.processImage(buffer, { quality });
  }

  /**
   * Validate an image buffer.
   */
  validateImage(
    buffer: Buffer,
    maxSize: number = MAX_IMAGE_SIZE,
    allowedTypes: string[] = DEFAULT_ALLOWED_IMAGE_TYPES
  ): ValidationResult {
    if (buffer.length === 0) {
      return { valid: false, error: 'File is empty' };
    }

    if (buffer.length > maxSize) {
      const maxMB = (maxSize / (1024 * 1024)).toFixed(0);
      return { valid: false, error: `Image exceeds maximum size of ${maxMB} MB` };
    }

    const detectedType = this.detectImageType(buffer);
    if (!detectedType) {
      return { valid: false, error: 'File is not a recognized image format' };
    }

    if (allowedTypes.length > 0 && !allowedTypes.includes(detectedType)) {
      return { valid: false, error: `Image type "${detectedType}" is not allowed. Allowed: ${allowedTypes.join(', ')}` };
    }

    return { valid: true };
  }

  /**
   * Validate a video buffer.
   */
  validateVideo(buffer: Buffer, maxSize: number = MAX_VIDEO_SIZE): ValidationResult {
    if (buffer.length === 0) {
      return { valid: false, error: 'File is empty' };
    }

    if (buffer.length > maxSize) {
      const maxMB = (maxSize / (1024 * 1024)).toFixed(0);
      return { valid: false, error: `Video exceeds maximum size of ${maxMB} MB` };
    }

    const detectedType = this.detectVideoType(buffer);
    if (!detectedType) {
      return { valid: false, error: 'File is not a recognized video format' };
    }

    return { valid: true };
  }

  // ─── Sharp-based Processing ──────────────────────────────────────────────

  private async processWithSharp(
    buffer: Buffer,
    options: ImageProcessOptions,
    Sharp: SharpConstructor
  ): Promise<Buffer> {
    let pipeline = new Sharp(buffer);

    const needsResize = options.maxWidth || options.maxHeight;
    if (needsResize) {
      pipeline = pipeline.resize({
        width: options.maxWidth,
        height: options.maxHeight,
        fit: 'inside',
        withoutEnlargement: true,
      });
    }

    const format = options.format || 'jpeg';
    const quality = options.quality ?? 85;

    switch (format) {
      case 'jpeg':
        pipeline = pipeline.jpeg({ quality });
        break;
      case 'png':
        pipeline = pipeline.png({ quality: Math.round(quality / 10) });
        break;
      case 'webp':
        pipeline = pipeline.webp({ quality });
        break;
    }

    return pipeline.toBuffer();
  }

  // ─── Basic (fallback) Processing ─────────────────────────────────────────

  private async processBasic(buffer: Buffer, options: ImageProcessOptions): Promise<Buffer> {
    // Without sharp, we can only do basic passthrough.
    // If no transformation is needed, return the original.
    if (!options.maxWidth && !options.maxHeight && !options.format && !options.quality) {
      return buffer;
    }

    // If the target format matches the source format and no resize is needed,
    // return the original. We cannot resize without sharp.
    const detectedType = this.detectImageType(buffer);
    const targetFormat = options.format || (detectedType?.replace('image/', '') as 'jpeg' | 'png' | 'webp') || 'jpeg';
    const sourceFormat = detectedType?.replace('image/', '');

    if (sourceFormat === targetFormat && !options.maxWidth && !options.maxHeight) {
      return buffer;
    }

    // Format conversion without sharp: only JPEG→PNG simple header rewrite for uncompressed
    // In practice, return the original buffer since we cannot transform without sharp
    return buffer;
  }

  private getBasicMetadata(buffer: Buffer): ImageMetadata {
    const mimeType = this.detectImageType(buffer) || 'image/unknown';

    // Extract dimensions from known formats
    let width = 0;
    let height = 0;

    if (mimeType === 'image/png' && buffer.length >= 24) {
      width = buffer.readUInt32BE(16);
      height = buffer.readUInt32BE(20);
    } else if (mimeType === 'image/jpeg' && buffer.length > 4) {
      // Find SOF marker (0xFFC0, 0xFFC1, 0xFFC2)
      let offset = 2;
      while (offset < buffer.length - 9) {
        if (buffer[offset] === 0xff) {
          const marker = buffer[offset + 1];
          if (marker === 0xc0 || marker === 0xc1 || marker === 0xc2) {
            height = buffer.readUInt16BE(offset + 5);
            width = buffer.readUInt16BE(offset + 7);
            break;
          }
          if (marker === 0xd9 || marker === 0xda) break; // End of image or SOS
          const segLen = buffer.readUInt16BE(offset + 2);
          offset += 2 + segLen;
        } else {
          offset++;
        }
      }
    } else if (mimeType === 'image/gif' && buffer.length >= 10) {
      width = buffer.readUInt16LE(6);
      height = buffer.readUInt16LE(8);
    } else if (mimeType === 'image/bmp' && buffer.length >= 26) {
      width = Math.abs(buffer.readInt32LE(18));
      height = Math.abs(buffer.readInt32LE(22));
    } else if (mimeType === 'image/webp' && buffer.length >= 30) {
      // RIFF header + WEBP
      // For VP8: find VP8 bitstream
      let offset = 12;
      while (offset < buffer.length - 8) {
        const chunkId = buffer.toString('ascii', offset, offset + 4);
        const chunkSize = buffer.readUInt32LE(offset + 4);
        if (chunkId === 'VP8 ' && offset + 10 < buffer.length) {
          width = buffer.readUInt16LE(offset + 14) & 0x3fff;
          height = buffer.readUInt16LE(offset + 16) & 0x3fff;
          break;
        } else if (chunkId === 'VP8X' && offset + 10 < buffer.length) {
          const flags = buffer.readUInt32LE(offset + 8);
          width = (buffer.readUInt8(offset + 12) | ((buffer.readUInt8(offset + 13) & 0x3f) << 8)) + 1;
          height = (buffer.readUInt8(offset + 14) | ((buffer.readUInt8(offset + 15) & 0x3f) << 8)) + 1;
          break;
        }
        offset += 8 + chunkSize;
        // Align to even
        if (chunkSize % 2 !== 0) offset++;
      }
    }

    return {
      width,
      height,
      mimeType,
      size: buffer.length,
    };
  }
}