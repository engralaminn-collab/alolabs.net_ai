/**
 * Storage Module — Public API & Factory
 *
 * Provides a unified interface for file storage operations
 * across local filesystem, S3, and MinIO backends.
 */

export type { StorageProvider, StorageConfig, UploadedFile, UploadOptions, StorageStats } from './types';
export type { ImageMetadata, ImageProcessOptions, ValidationResult } from './types';
export type { IStorageProvider, MultipartUploadState, MultipartUploadPart } from './types';

export { LocalStorageProvider } from './local-storage';
export { S3StorageProvider } from './s3-storage';
export { MediaProcessor } from './media-processor';

import type { StorageConfig, IStorageProvider } from './types';
import { LocalStorageProvider } from './local-storage';
import { S3StorageProvider } from './s3-storage';

// ─── Storage Factory ──────────────────────────────────────────────────────────

export class StorageFactory {
  private static instances: Map<string, IStorageProvider> = new Map();

  static createStorage(config: StorageConfig): IStorageProvider {
    const cacheKey = `${config.provider}:${config.endpoint || config.basePath || 'local'}:${config.bucket || ''}`;

    const cached = StorageFactory.instances.get(cacheKey);
    if (cached) return cached;

    let provider: IStorageProvider;

    switch (config.provider) {
      case 's3':
      case 'minio':
        provider = new S3StorageProvider(config);
        break;
      case 'local':
        provider = new LocalStorageProvider({ basePath: config.basePath || './storage' });
        break;
      default:
        throw new Error(`Unknown storage provider: ${config.provider}`);
    }

    StorageFactory.instances.set(cacheKey, provider);
    return provider;
  }

  static clearCache(): void {
    StorageFactory.instances.clear();
  }
}

// ─── Singleton Convenience ────────────────────────────────────────────────────

let defaultStorage: IStorageProvider | null = null;

export function getStorage(config?: StorageConfig): IStorageProvider {
  if (defaultStorage) return defaultStorage;

  const resolvedConfig = config || resolveDefaultConfig();
  defaultStorage = StorageFactory.createStorage(resolvedConfig);
  return defaultStorage;
}

export function setStorage(provider: IStorageProvider): void {
  defaultStorage = provider;
}

export function resetStorage(): void {
  defaultStorage = null;
  StorageFactory.clearCache();
}

// ─── Environment Config Resolution ────────────────────────────────────────────

function resolveDefaultConfig(): StorageConfig {
  // S3/MinIO environment variables take priority
  if (process.env.S3_ENDPOINT || process.env.MINIO_URL || process.env.MINIO_HOST) {
    let endpoint = process.env.S3_ENDPOINT || '';
    let port: number | undefined;
    let useSSL = false;

    if (!endpoint && process.env.MINIO_URL) {
      try {
        const url = new URL(process.env.MINIO_URL);
        endpoint = url.hostname;
        port = parseInt(url.port || (url.protocol === 'https:' ? '443' : '80'), 10);
        useSSL = url.protocol === 'https:';
      } catch {
        endpoint = process.env.MINIO_URL;
      }
    }

    if (!endpoint) {
      endpoint = process.env.MINIO_HOST || 'localhost';
    }

    if (!port) {
      port = process.env.S3_PORT || process.env.MINIO_PORT
        ? parseInt(process.env.S3_PORT || process.env.MINIO_PORT!, 10)
        : (useSSL ? 443 : 9000);
    }

    if (!useSSL && !process.env.MINIO_URL) {
      useSSL = process.env.S3_SSL === 'true' || process.env.MINIO_SSL === 'true';
    }

    const provider: 's3' | 'minio' = process.env.S3_ENDPOINT ? 's3' : 'minio';

    return {
      provider,
      endpoint,
      port,
      useSSL,
      bucket: process.env.S3_BUCKET || process.env.MINIO_BUCKET || 'agent-hub',
      accessKey: process.env.S3_ACCESS_KEY || process.env.MINIO_ACCESS_KEY || '',
      secretKey: process.env.S3_SECRET_KEY || process.env.MINIO_SECRET_KEY || '',
      region: process.env.S3_REGION || process.env.MINIO_REGION || 'us-east-1',
      cdnUrl: process.env.S3_CDN_URL || process.env.MINIO_CDN_URL || undefined,
    };
  }

  // Default to local storage
  return {
    provider: 'local',
    basePath: process.env.STORAGE_PATH || './storage',
  };
}