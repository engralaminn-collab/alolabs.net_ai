/**
 * Local Filesystem Storage Provider
 *
 * Implements IStorageProvider for local disk-based file storage.
 * Files are stored under a configurable basePath with metadata
 * tracked in a JSON manifest file.
 */

import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import type {
  IStorageProvider,
  UploadedFile,
  UploadOptions,
  StorageStats,
} from './types';

// ─── Manifest Types ─────────────────────────────────────────────────────────

interface FileManifest {
  files: Record<string, ManifestEntry>;
}

interface ManifestEntry {
  id: string;
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  folder?: string;
  metadata?: Record<string, string>;
  uploadedBy: string;
  companyId: string;
  createdAt: string;
}

// ─── LocalStorageProvider ─────────────────────────────────────────────────────

export class LocalStorageProvider implements IStorageProvider {
  private basePath: string;
  private manifestPath: string;
  private manifest: FileManifest;
  private signingKey: string;

  constructor(config: { basePath: string }) {
    this.basePath = path.resolve(config.basePath || './storage');
    this.manifestPath = path.join(this.basePath, '_manifest.json');
    this.signingKey = process.env.ENCRYPTION_KEY || 'local-storage-signing-key';

    // Ensure directories exist
    fs.mkdirSync(this.basePath, { recursive: true });

    // Load or create manifest
    this.manifest = this.loadManifest();
  }

  // ─── Manifest Management ─────────────────────────────────────────────────

  private loadManifest(): FileManifest {
    try {
      if (fs.existsSync(this.manifestPath)) {
        const raw = fs.readFileSync(this.manifestPath, 'utf-8');
        return JSON.parse(raw);
      }
    } catch {
      // Corrupt manifest — start fresh
    }
    return { files: {} };
  }

  private saveManifest(): void {
    fs.writeFileSync(this.manifestPath, JSON.stringify(this.manifest, null, 2), 'utf-8');
  }

  // ─── Core IStorageProvider Methods ───────────────────────────────────────

  async upload(
    file: Buffer,
    filename: string,
    options?: UploadOptions
  ): Promise<UploadedFile> {
    const id = `local_${Date.now()}_${crypto.randomBytes(8).toString('hex')}`;
    const folder = options?.folder || 'uploads';
    const relativePath = `${folder}/${id}_${filename}`;
    const fullPath = path.join(this.basePath, relativePath);

    // Ensure folder exists
    fs.mkdirSync(path.dirname(fullPath), { recursive: true });

    // Write file
    fs.writeFileSync(fullPath, file);

    const now = new Date();
    const entry: ManifestEntry = {
      id,
      filename: relativePath,
      originalName: filename,
      mimeType: options?.allowedTypes?.[0] || this.detectMimeType(filename),
      size: file.length,
      folder,
      metadata: options?.allowedTypes ? { allowedTypes: options.allowedTypes.join(',') } : undefined,
      uploadedBy: 'system',
      companyId: 'default',
      createdAt: now.toISOString(),
    };

    this.manifest.files[id] = entry;
    this.saveManifest();

    return {
      id,
      filename: relativePath,
      originalName: filename,
      mimeType: entry.mimeType,
      size: file.length,
      url: `/api/storage/files?key=${encodeURIComponent(relativePath)}`,
      uploadedBy: entry.uploadedBy,
      companyId: entry.companyId,
      createdAt: now,
    };
  }

  async download(fileId: string): Promise<Buffer> {
    const entry = this.manifest.files[fileId];
    if (!entry) {
      throw new Error(`File not found: ${fileId}`);
    }
    const fullPath = path.join(this.basePath, entry.filename);
    if (!fs.existsSync(fullPath)) {
      throw new Error(`File data not found on disk: ${fullPath}`);
    }
    return fs.readFileSync(fullPath);
  }

  async delete(fileId: string): Promise<void> {
    const entry = this.manifest.files[fileId];
    if (!entry) return;

    const fullPath = path.join(this.basePath, entry.filename);
    if (fs.existsSync(fullPath)) {
      fs.unlinkSync(fullPath);
    }

    delete this.manifest.files[fileId];
    this.saveManifest();
  }

  async list(prefix?: string): Promise<UploadedFile[]> {
    const results: UploadedFile[] = [];
    const now = new Date();

    for (const [id, entry] of Object.entries(this.manifest.files)) {
      if (prefix && !entry.folder?.startsWith(prefix) && !entry.filename.startsWith(prefix)) {
        continue;
      }
      results.push({
        id,
        filename: entry.filename,
        originalName: entry.originalName,
        mimeType: entry.mimeType,
        size: entry.size,
        url: `/api/storage/files?key=${encodeURIComponent(entry.filename)}`,
        uploadedBy: entry.uploadedBy,
        companyId: entry.companyId,
        createdAt: new Date(entry.createdAt),
      });
    }

    return results;
  }

  async getStats(): Promise<StorageStats> {
    const byType = new Map<string, number>();
    const byMonth = new Map<string, number>();
    let totalSize = 0;

    for (const entry of Object.values(this.manifest.files)) {
      totalSize += entry.size;
      const ext = entry.mimeType || 'unknown';
      byType.set(ext, (byType.get(ext) || 0) + 1);
      const month = entry.createdAt.slice(0, 7);
      byMonth.set(month, (byMonth.get(month) || 0) + 1);
    }

    return {
      totalFiles: Object.keys(this.manifest.files).length,
      totalSize,
      byType,
      byMonth,
    };
  }

  async generateThumbnail(_fileId: string, _width: number, _height: number): Promise<string> {
    // Local storage thumbnail generation would require sharp/jimp.
    // Return the file URL as fallback.
    return this.getPublicUrl(_fileId);
  }

  getPublicUrl(fileId: string): string {
    const entry = this.manifest.files[fileId];
    if (!entry) return '';
    return `/api/storage/files?key=${encodeURIComponent(entry.filename)}`;
  }

  // ─── Signed URL Support ──────────────────────────────────────────────────

  getSignedUrl(fileId: string, expiresInSec: number = 3600): string {
    const entry = this.manifest.files[fileId];
    if (!entry) return '';

    const expires = Math.floor(Date.now() / 1000) + expiresInSec;
    const payload = `${fileId}:${expires}`;
    const sig = crypto
      .createHmac('sha256', this.signingKey)
      .update(payload)
      .digest('hex');

    return `/api/storage/files?key=${encodeURIComponent(entry.filename)}&expires=${expires}&sig=${sig}`;
  }

  verifySignedUrl(fileId: string, expires: number, sig: string): boolean {
    // Check expiry
    if (Date.now() / 1000 > expires) return false;

    // Verify HMAC signature
    const payload = `${fileId}:${expires}`;
    const expected = crypto
      .createHmac('sha256', this.signingKey)
      .update(payload)
      .digest('hex');

    // Constant-time comparison
    if (sig.length !== expected.length) return false;
    let result = 0;
    for (let i = 0; i < sig.length; i++) {
      result |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
    }
    return result === 0;
  }

  // ─── Utility ────────────────────────────────────────────────────────────

  async exists(fileId: string): Promise<boolean> {
    const entry = this.manifest.files[fileId];
    if (!entry) return false;
    return fs.existsSync(path.join(this.basePath, entry.filename));
  }

  async copy(fileId: string, destFolder: string): Promise<UploadedFile> {
    const entry = this.manifest.files[fileId];
    if (!entry) throw new Error(`File not found: ${fileId}`);

    const srcPath = path.join(this.basePath, entry.filename);
    if (!fs.existsSync(srcPath)) throw new Error(`File data not found: ${srcPath}`);

    const buffer = fs.readFileSync(srcPath);
    return this.upload(buffer, entry.originalName, { folder: destFolder });
  }

  private detectMimeType(filename: string): string {
    const ext = path.extname(filename).toLowerCase();
    const mimeMap: Record<string, string> = {
      '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
      '.gif': 'image/gif', '.webp': 'image/webp', '.svg': 'image/svg+xml',
      '.pdf': 'application/pdf', '.json': 'application/json',
      '.txt': 'text/plain', '.csv': 'text/csv', '.html': 'text/html',
      '.css': 'text/css', '.js': 'application/javascript', '.ts': 'application/typescript',
      '.mp4': 'video/mp4', '.mp3': 'audio/mpeg', '.wav': 'audio/wav',
      '.zip': 'application/zip', '.tar': 'application/x-tar', '.gz': 'application/gzip',
      '.doc': 'application/msword', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      '.xls': 'application/vnd.ms-excel', '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    };
    return mimeMap[ext] || 'application/octet-stream';
  }
}
