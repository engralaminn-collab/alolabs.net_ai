/**
 * S3-Compatible Storage Provider
 * Uses native fetch for S3 REST API with AWS Signature V4 signing.
 * Supports AWS S3, MinIO, and other S3-compatible services.
 * Includes multipart upload for large files and presigned URL generation.
 */

import crypto from 'crypto';
import type {
  StorageConfig,
  UploadedFile,
  UploadOptions,
  StorageStats,
  MultipartUploadState,
  MultipartUploadPart,
  IStorageProvider,
  ValidationResult,
} from './types';

// ─── Constants ────────────────────────────────────────────────────────────────

const MULTIPART_THRESHOLD = 5 * 1024 * 1024; // 5 MB
const MULTIPART_PART_SIZE = 5 * 1024 * 1024; // 5 MB per part
const MAX_FILE_SIZE = 5 * 1024 * 1024 * 1024; // 5 GB
const DEFAULT_REGION = 'us-east-1';
const HMAC_SHA256 = 'sha256';

// ─── S3StorageProvider ────────────────────────────────────────────────────────

export class S3StorageProvider implements IStorageProvider {
  private config: Required<Pick<StorageConfig, 'endpoint' | 'bucket' | 'accessKey' | 'secretKey' | 'region'>> & {
    useSSL: boolean;
    port: number;
    cdnUrl?: string;
  };
  private activeMultipartUploads: Map<string, MultipartUploadState> = new Map();

  constructor(config: StorageConfig) {
    if (!config.endpoint || !config.bucket || !config.accessKey || !config.secretKey) {
      throw new Error('S3StorageProvider requires endpoint, bucket, accessKey, and secretKey');
    }

    this.config = {
      endpoint: config.endpoint,
      bucket: config.bucket,
      accessKey: config.accessKey,
      secretKey: config.secretKey,
      region: config.region || DEFAULT_REGION,
      useSSL: config.useSSL ?? config.endpoint.startsWith('https'),
      port: config.port || (config.useSSL ?? config.endpoint.startsWith('https') ? 443 : 80),
      cdnUrl: config.cdnUrl,
    };
  }

  // ─── AWS Signature V4 ────────────────────────────────────────────────────

  private getBaseUrl(): string {
    const protocol = this.config.useSSL ? 'https' : 'http';
    // Strip protocol from endpoint if present
    let host = this.config.endpoint.replace(/^https?:\/\//, '');
    const defaultPort = this.config.useSSL ? 443 : 80;
    if (this.config.port !== defaultPort) {
      host = `${host}:${this.config.port}`;
    }
    return `${protocol}://${host}`;
  }

  private async sha256(data: Buffer | string): Promise<string> {
    const hash = crypto.createHash(HMAC_SHA256);
    hash.update(data);
    return hash.digest('hex');
  }

  private async hmacSha256(key: Buffer | string, data: string): Promise<Buffer> {
    return crypto.createHmac(HMAC_SHA256, key).update(data).digest();
  }

  private getSigningKey(dateStamp: string, region: string): Buffer {
    const kDate = crypto.createHmac(HMAC_SHA256, `AWS4${this.config.secretKey}`)
      .update(dateStamp)
      .digest();
    const kRegion = crypto.createHmac(HMAC_SHA256, kDate)
      .update(region)
      .digest();
    const kService = crypto.createHmac(HMAC_SHA256, kRegion)
      .update('s3')
      .digest();
    return crypto.createHmac(HMAC_SHA256, kService)
      .update('aws4_request')
      .digest();
  }

  private async signRequest(
    method: string,
    objectKey: string,
    headers: Record<string, string>,
    query: string = '',
    bodyHash?: string
  ): Promise<Record<string, string>> {
    const now = new Date();
    const amzDate = now.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
    const dateStamp = amzDate.slice(0, 8);

    const payloadHash = bodyHash || (await this.sha256(''));

    headers['host'] = headers['host'] || this.getHostHeader();
    headers['x-amz-date'] = amzDate;
    headers['x-amz-content-sha256'] = payloadHash;

    // Canonical headers
    const sortedHeaderKeys = Object.keys(headers).map(k => k.toLowerCase()).sort();
    const canonicalHeaders = sortedHeaderKeys
      .map(k => `${k}:${headers[k] || (Object.keys(headers).find(h => h.toLowerCase() === k) ? headers[Object.keys(headers).find(h => h.toLowerCase() === k)!] : '')}`)
      .join('\n') + '\n';

    const signedHeaders = sortedHeaderKeys.join(';');
    const canonicalUri = objectKey ? `/${objectKey}` : '/';
    const canonicalQueryString = query || '';

    const canonicalRequest = [
      method,
      canonicalUri,
      canonicalQueryString,
      canonicalHeaders,
      signedHeaders,
      payloadHash,
    ].join('\n');

    const credentialScope = `${dateStamp}/${this.config.region}/s3/aws4_request`;
    const stringToSign = [
      'AWS4-HMAC-SHA256',
      amzDate,
      credentialScope,
      await this.sha256(canonicalRequest),
    ].join('\n');

    const signingKey = this.getSigningKey(dateStamp, this.config.region);
    const signature = crypto.createHmac(HMAC_SHA256, signingKey)
      .update(stringToSign)
      .digest('hex');

    headers['Authorization'] = `AWS4-HMAC-SHA256 Credential=${this.config.accessKey}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;

    return headers;
  }

  private getHostHeader(): string {
    let host = this.config.endpoint.replace(/^https?:\/\//, '');
    const defaultPort = this.config.useSSL ? 443 : 80;
    if (this.config.port !== defaultPort) {
      host = `${host}:${this.config.port}`;
    }
    return host;
  }

  // ─── S3 Request Helpers ──────────────────────────────────────────────────

  private async s3Request(
    method: string,
    objectKey: string = '',
    body?: Buffer | null,
    contentType?: string,
    query: string = '',
    customHeaders: Record<string, string> = {}
  ): Promise<{ status: number; headers: Headers; body: Buffer | null; error?: string }> {
    const headers: Record<string, string> = {};
    if (contentType) headers['Content-Type'] = contentType;
    Object.assign(headers, customHeaders);

    let bodyHash: string | undefined;
    if (body) {
      bodyHash = await this.sha256(body);
      headers['Content-Length'] = String(body.length);
    }

    const signedHeaders = await this.signRequest(method, objectKey, headers, query, bodyHash);

    let host = this.config.endpoint.replace(/^https?:\/\//, '');
    const defaultPort = this.config.useSSL ? 443 : 80;
    if (this.config.port !== defaultPort) {
      host = `${host}:${this.config.port}`;
    }

    const url = `${this.getBaseUrl()}/${this.config.bucket}/${objectKey}${query ? `?${query}` : ''}`;

    try {
      const response = await fetch(url, {
        method,
        headers: signedHeaders,
        body: body ? (body as unknown as BodyInit) : undefined,
        signal: AbortSignal.timeout(60000),
      });

      const responseBody = response.status !== 204 && response.status !== 200
        ? null
        : await response.arrayBuffer().then(buf => Buffer.from(buf)).catch(() => null);

      if (!response.ok && response.status >= 400) {
        const errorText = responseBody ? responseBody.toString('utf-8') : `HTTP ${response.status}`;
        return { status: response.status, headers: response.headers, body: null, error: errorText };
      }

      return { status: response.status, headers: response.headers, body: responseBody };
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      return { status: 0, headers: new Headers(), body: null, error: message };
    }
  }

  // ─── IStorageProvider Implementation ──────────────────────────────────────

  async upload(
    file: Buffer,
    filename: string,
    options?: UploadOptions
  ): Promise<UploadedFile> {
    const validation = this.validateFile(file, filename, options);
    if (!validation.valid) {
      throw new Error(validation.error);
    }

    const objectKey = this.buildObjectKey(filename, options?.folder);
    const contentType = this.guessContentType(filename);

    if (file.length > MULTIPART_THRESHOLD) {
      return this.multipartUpload(file, objectKey, contentType, filename, options);
    }

    const result = await this.s3Request('PUT', objectKey, file, contentType);
    if (result.error) {
      throw new Error(`S3 upload failed: ${result.error}`);
    }

    const etag = result.headers.get('etag')?.replace(/"/g, '') || '';

    return this.buildUploadedFile(objectKey, filename, file.length, contentType, etag, options);
  }

  async download(fileId: string): Promise<Buffer> {
    const result = await this.s3Request('GET', fileId);
    if (result.error || !result.body) {
      throw new Error(`S3 download failed: ${result.error || 'Empty response'}`);
    }
    return result.body;
  }

  async delete(fileId: string): Promise<void> {
    const result = await this.s3Request('DELETE', fileId);
    if (result.error && result.status !== 204) {
      throw new Error(`S3 delete failed: ${result.error}`);
    }
  }

  async list(prefix?: string): Promise<UploadedFile[]> {
    const query = prefix
      ? `list-type=2&prefix=${encodeURIComponent(prefix)}&max-keys=1000`
      : 'list-type=2&max-keys=1000';

    const result = await this.s3Request('GET', '', null, undefined, query);
    if (result.error || !result.body) {
      throw new Error(`S3 list failed: ${result.error || 'Empty response'}`);
    }

    return this.parseListResponse(result.body.toString('utf-8'));
  }

  async getStats(): Promise<StorageStats> {
    const stats: StorageStats = {
      totalFiles: 0,
      totalSize: 0,
      byType: new Map<string, number>(),
      byMonth: new Map<string, number>(),
    };

    let continuationToken = '';
    let hasMore = true;

    while (hasMore) {
      let query = 'list-type=2&max-keys=1000';
      if (continuationToken) {
        query += `&continuation-token=${encodeURIComponent(continuationToken)}`;
      }

      const result = await this.s3Request('GET', '', null, undefined, query);
      if (result.error || !result.body) break;

      const xml = result.body.toString('utf-8');
      const objects = this.parseListObjects(xml);

      for (const obj of objects) {
        stats.totalFiles++;
        stats.totalSize += obj.size;

        const ext = this.getExtension(obj.key);
        if (ext) {
          const current = stats.byType.get(ext) || 0;
          stats.byType.set(ext, current + obj.size);
        }

        if (obj.lastModified) {
          const monthKey = obj.lastModified.slice(0, 7);
          const current = stats.byMonth.get(monthKey) || 0;
          stats.byMonth.set(monthKey, current + obj.size);
        }
      }

      const isTruncatedMatch = /<IsTruncated>(true|false)<\/IsTruncated>/.exec(xml);
      const nextTokenMatch = /<NextContinuationToken>([^<]+)<\/NextContinuationToken>/.exec(xml);

      hasMore = isTruncatedMatch?.[1] === 'true' && !!nextTokenMatch;
      continuationToken = nextTokenMatch?.[1] || '';
    }

    return stats;
  }

  async generateThumbnail(
    fileId: string,
    width: number,
    height: number
  ): Promise<string> {
    // Thumbnails on S3 are stored as separate objects with a _thumbnails prefix
    const thumbKey = `_thumbnails/${fileId}/${width}x${height}`;
    return this.getPublicUrl(thumbKey);
  }

  getPublicUrl(fileId: string): string {
    if (this.config.cdnUrl) {
      return `${this.config.cdnUrl}/${this.config.bucket}/${fileId}`;
    }
    return `${this.getBaseUrl()}/${this.config.bucket}/${fileId}`;
  }

  // ─── Presigned URLs ──────────────────────────────────────────────────────

  async getPresignedGetUrl(objectKey: string, expiresIn: number = 3600): Promise<string> {
    const now = new Date();
    const amzDate = now.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
    const dateStamp = amzDate.slice(0, 8);
    const credentialScope = `${dateStamp}/${this.config.region}/s3/aws4_request`;

    const host = this.getHostHeader();

    const canonicalHeaders = `host:${host}\nx-amz-content-sha256:UNSIGNED-PAYLOAD\nx-amz-date:${amzDate}\n`;
    const signedHeaders = 'host;x-amz-content-sha256;x-amz-date';

    const canonicalRequest = [
      'GET',
      `/${this.config.bucket}/${objectKey}`,
      `X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=${encodeURIComponent(this.config.accessKey)}%2F${credentialScope}&X-Amz-Date=${amzDate}&X-Amz-Expires=${expiresIn}&X-Amz-SignedHeaders=${signedHeaders}`,
      canonicalHeaders,
      signedHeaders,
      'UNSIGNED-PAYLOAD',
    ].join('\n');

    const stringToSign = [
      'AWS4-HMAC-SHA256',
      amzDate,
      credentialScope,
      await this.sha256(canonicalRequest),
    ].join('\n');

    const signingKey = this.getSigningKey(dateStamp, this.config.region);
    const signature = crypto.createHmac(HMAC_SHA256, signingKey)
      .update(stringToSign)
      .digest('hex');

    const queryParams = [
      `X-Amz-Algorithm=AWS4-HMAC-SHA256`,
      `X-Amz-Credential=${encodeURIComponent(this.config.accessKey)}/${credentialScope}`,
      `X-Amz-Date=${amzDate}`,
      `X-Amz-Expires=${expiresIn}`,
      `X-Amz-SignedHeaders=${signedHeaders}`,
      `X-Amz-Signature=${signature}`,
    ].join('&');

    return `${this.getBaseUrl()}/${this.config.bucket}/${objectKey}?${queryParams}`;
  }

  async getPresignedPutUrl(
    objectKey: string,
    contentType: string,
    expiresIn: number = 3600
  ): Promise<string> {
    const now = new Date();
    const amzDate = now.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
    const dateStamp = amzDate.slice(0, 8);
    const credentialScope = `${dateStamp}/${this.config.region}/s3/aws4_request`;

    const host = this.getHostHeader();

    const canonicalHeaders = `host:${host}\nx-amz-content-sha256:UNSIGNED-PAYLOAD\nx-amz-date:${amzDate}\n`;
    const signedHeaders = 'host;x-amz-content-sha256;x-amz-date';

    const canonicalRequest = [
      'PUT',
      `/${this.config.bucket}/${objectKey}`,
      `X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=${encodeURIComponent(this.config.accessKey)}%2F${credentialScope}&X-Amz-Date=${amzDate}&X-Amz-Expires=${expiresIn}&X-Amz-SignedHeaders=${signedHeaders}&x-amz-content-sha256=UNSIGNED-PAYLOAD`,
      canonicalHeaders,
      signedHeaders,
      'UNSIGNED-PAYLOAD',
    ].join('\n');

    const stringToSign = [
      'AWS4-HMAC-SHA256',
      amzDate,
      credentialScope,
      await this.sha256(canonicalRequest),
    ].join('\n');

    const signingKey = this.getSigningKey(dateStamp, this.config.region);
    const signature = crypto.createHmac(HMAC_SHA256, signingKey)
      .update(stringToSign)
      .digest('hex');

    const queryParams = [
      `X-Amz-Algorithm=AWS4-HMAC-SHA256`,
      `X-Amz-Credential=${encodeURIComponent(this.config.accessKey)}/${credentialScope}`,
      `X-Amz-Date=${amzDate}`,
      `X-Amz-Expires=${expiresIn}`,
      `X-Amz-SignedHeaders=${signedHeaders}`,
      `X-Amz-Signature=${signature}`,
      `x-amz-content-sha256=UNSIGNED-PAYLOAD`,
    ].join('&');

    return `${this.getBaseUrl()}/${this.config.bucket}/${objectKey}?${queryParams}`;
  }

  // ─── Multipart Upload ────────────────────────────────────────────────────

  async initiateMultipartUpload(objectKey: string, contentType?: string): Promise<string> {
    const query = 'uploads=';
    const result = await this.s3Request('POST', objectKey, null, contentType, query);

    if (result.error || !result.body) {
      throw new Error(`Failed to initiate multipart upload: ${result.error}`);
    }

    const uploadIdMatch = /<UploadId>([^<]+)<\/UploadId>/.exec(result.body.toString('utf-8'));
    if (!uploadIdMatch) {
      throw new Error('Failed to parse UploadId from S3 response');
    }

    const uploadId = uploadIdMatch[1];
    this.activeMultipartUploads.set(uploadId, {
      uploadId,
      key: objectKey,
      bucket: this.config.bucket,
      parts: [],
    });

    return uploadId;
  }

  async uploadPart(
    uploadId: string,
    partNumber: number,
    data: Buffer
  ): Promise<string> {
    const state = this.activeMultipartUploads.get(uploadId);
    if (!state) {
      throw new Error(`Multipart upload not found: ${uploadId}`);
    }

    const query = `partNumber=${partNumber}&uploadId=${encodeURIComponent(uploadId)}`;
    const result = await this.s3Request('PUT', state.key, data, 'application/octet-stream', query);

    if (result.error) {
      throw new Error(`Failed to upload part ${partNumber}: ${result.error}`);
    }

    const etag = result.headers.get('etag')?.replace(/"/g, '') || '';
    state.parts.push({ partNumber, etag });

    return etag;
  }

  async completeMultipartUpload(uploadId: string): Promise<void> {
    const state = this.activeMultipartUploads.get(uploadId);
    if (!state) {
      throw new Error(`Multipart upload not found: ${uploadId}`);
    }

    // Sort parts by part number
    const sortedParts = [...state.parts].sort((a, b) => a.partNumber - b.partNumber);

    const xmlParts = sortedParts
      .map(p => `<Part><PartNumber>${p.partNumber}</PartNumber><ETag>"${p.etag}"</ETag></Part>`)
      .join('');
    const body = Buffer.from(`<CompleteMultipartUpload>${xmlParts}</CompleteMultipartUpload>`);

    const query = `uploadId=${encodeURIComponent(uploadId)}`;
    const result = await this.s3Request('POST', state.key, body, 'application/xml', query);

    if (result.error) {
      throw new Error(`Failed to complete multipart upload: ${result.error}`);
    }

    this.activeMultipartUploads.delete(uploadId);
  }

  async abortMultipartUpload(uploadId: string): Promise<void> {
    const state = this.activeMultipartUploads.get(uploadId);
    if (!state) {
      throw new Error(`Multipart upload not found: ${uploadId}`);
    }

    const query = `uploadId=${encodeURIComponent(uploadId)}`;
    await this.s3Request('DELETE', state.key, null, undefined, query);
    this.activeMultipartUploads.delete(uploadId);
  }

  // ─── Bucket Operations ───────────────────────────────────────────────────

  async createBucket(bucketName: string, region?: string): Promise<void> {
    const location = region || this.config.region;
    const body = Buffer.from(`<CreateBucketConfiguration xmlns="http://s3.amazonaws.com/doc/2006-03-01/"><LocationConstraint>${location}</LocationConstraint></CreateBucketConfiguration>`);

    const result = await this.s3Request(
      'PUT',
      '',
      location === 'us-east-1' ? null : body,
      'application/xml'
    );

    if (result.error && result.status !== 409) {
      throw new Error(`Failed to create bucket: ${result.error}`);
    }
  }

  async listBuckets(): Promise<Array<{ name: string; creationDate: string }>> {
    // Direct request to endpoint (no bucket in path)
    const now = new Date();
    const amzDate = now.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
    const dateStamp = amzDate.slice(0, 8);
    const host = this.getHostHeader();
    const payloadHash = await this.sha256('');

    const headers: Record<string, string> = {
      'host': host,
      'x-amz-date': amzDate,
      'x-amz-content-sha256': payloadHash,
    };

    const sortedHeaderKeys = Object.keys(headers).map(k => k.toLowerCase()).sort();
    const canonicalHeaders = sortedHeaderKeys.map(k => `${k}:${headers[k]}`).join('\n') + '\n';
    const signedHeaders = sortedHeaderKeys.join(';');

    const canonicalRequest = `GET\n/\n\n${canonicalHeaders}\n${signedHeaders}\n${payloadHash}`;
    const credentialScope = `${dateStamp}/${this.config.region}/s3/aws4_request`;
    const stringToSign = [
      'AWS4-HMAC-SHA256',
      amzDate,
      credentialScope,
      await this.sha256(canonicalRequest),
    ].join('\n');

    const signingKey = this.getSigningKey(dateStamp, this.config.region);
    const signature = crypto.createHmac(HMAC_SHA256, signingKey).update(stringToSign).digest('hex');

    headers['Authorization'] = `AWS4-HMAC-SHA256 Credential=${this.config.accessKey}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;

    try {
      const response = await fetch(this.getBaseUrl(), {
        method: 'GET',
        headers,
        signal: AbortSignal.timeout(30000),
      });

      if (!response.ok) {
        throw new Error(`List buckets failed: HTTP ${response.status}`);
      }

      const xml = await response.text();
      const buckets: Array<{ name: string; creationDate: string }> = [];
      const bucketRegex = /<Bucket>([\s\S]*?)<\/Bucket>/g;
      let match: RegExpExecArray | null;

      while ((match = bucketRegex.exec(xml)) !== null) {
        const nameMatch = /<Name>([^<]+)<\/Name>/.exec(match[1]);
        const dateMatch = /<CreationDate>([^<]+)<\/CreationDate>/.exec(match[1]);
        if (nameMatch) {
          buckets.push({
            name: nameMatch[1],
            creationDate: dateMatch?.[1] || '',
          });
        }
      }

      return buckets;
    } catch (err: unknown) {
      throw new Error(`Failed to list buckets: ${err instanceof Error ? err.message : String(err)}`);
    }
  }

  async deleteBucket(bucketName: string): Promise<void> {
    const url = `${this.getBaseUrl()}/${bucketName}`;
    const now = new Date();
    const amzDate = now.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
    const dateStamp = amzDate.slice(0, 8);

    let host = this.config.endpoint.replace(/^https?:\/\//, '');
    const defaultPort = this.config.useSSL ? 443 : 80;
    if (this.config.port !== defaultPort) {
      host = `${host}:${this.config.port}`;
    }

    const headers: Record<string, string> = {
      'host': host,
      'x-amz-date': amzDate,
      'x-amz-content-sha256': await this.sha256(''),
    };

    const sortedHeaderKeys = Object.keys(headers).map(k => k.toLowerCase()).sort();
    const canonicalHeaders = sortedHeaderKeys.map(k => `${k}:${headers[k]}`).join('\n') + '\n';
    const signedHeaders = sortedHeaderKeys.join(';');
    const canonicalRequest = `DELETE\n/${bucketName}\n\n${canonicalHeaders}\n${signedHeaders}\n${(await this.sha256(''))}`;
    const credentialScope = `${dateStamp}/${this.config.region}/s3/aws4_request`;
    const stringToSign = ['AWS4-HMAC-SHA256', amzDate, credentialScope, await this.sha256(canonicalRequest)].join('\n');
    const signingKey = this.getSigningKey(dateStamp, this.config.region);
    const signature = crypto.createHmac(HMAC_SHA256, signingKey).update(stringToSign).digest('hex');

    headers['Authorization'] = `AWS4-HMAC-SHA256 Credential=${this.config.accessKey}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;

    const response = await fetch(url, { method: 'DELETE', headers, signal: AbortSignal.timeout(30000) });
    if (response.status !== 204) {
      throw new Error(`Failed to delete bucket: HTTP ${response.status}`);
    }
  }

  // ─── Private Helpers ─────────────────────────────────────────────────────

  private validateFile(buffer: Buffer, filename: string, options?: UploadOptions): ValidationResult {
    if (buffer.length > MAX_FILE_SIZE) {
      return { valid: false, error: `File exceeds maximum size of ${MAX_FILE_SIZE / (1024 * 1024 * 1024)} GB` };
    }
    if (buffer.length === 0) {
      return { valid: false, error: 'File is empty' };
    }
    if (options?.allowedTypes && options.allowedTypes.length > 0) {
      const detected = this.guessContentType(filename);
      if (!options.allowedTypes.includes(detected)) {
        return { valid: false, error: `File type "${detected}" is not allowed. Allowed: ${options.allowedTypes.join(', ')}` };
      }
    }
    return { valid: true };
  }

  private buildObjectKey(filename: string, folder?: string): string {
    const uuid = crypto.randomUUID();
    const sanitized = filename.replace(/[^a-zA-Z0-9._-]/g, '_');
    return folder ? `${folder}/${uuid}-${sanitized}` : `${uuid}-${sanitized}`;
  }

  private guessContentType(filename: string): string {
    const ext = filename.split('.').pop()?.toLowerCase() || '';
    const contentTypes: Record<string, string> = {
      'png': 'image/png',
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg',
      'gif': 'image/gif',
      'webp': 'image/webp',
      'svg': 'image/svg+xml',
      'pdf': 'application/pdf',
      'json': 'application/json',
      'zip': 'application/zip',
      'mp4': 'video/mp4',
      'webm': 'video/webm',
      'mp3': 'audio/mpeg',
      'wav': 'audio/wav',
      'txt': 'text/plain',
      'csv': 'text/csv',
    };
    return contentTypes[ext] || 'application/octet-stream';
  }

  private getExtension(key: string): string {
    const ext = key.split('.').pop()?.toLowerCase() || '';
    return ext ? `.${ext}` : '';
  }

  private buildUploadedFile(
    objectKey: string,
    originalName: string,
    size: number,
    mimeType: string,
    etag: string,
    options?: UploadOptions
  ): UploadedFile {
    return {
      id: objectKey,
      filename: objectKey.split('/').pop() || objectKey,
      originalName,
      mimeType,
      size,
      url: this.getPublicUrl(objectKey),
      metadata: etag ? { etag } : undefined,
      uploadedBy: options?.folder ? 'system' : 'unknown',
      companyId: '',
      createdAt: new Date(),
    };
  }

  private async multipartUpload(
    file: Buffer,
    objectKey: string,
    contentType: string,
    originalName: string,
    options?: UploadOptions
  ): Promise<UploadedFile> {
    const uploadId = await this.initiateMultipartUpload(objectKey, contentType);

    try {
      const partCount = Math.ceil(file.length / MULTIPART_PART_SIZE);
      const etags: string[] = [];

      for (let i = 0; i < partCount; i++) {
        const start = i * MULTIPART_PART_SIZE;
        const end = Math.min(start + MULTIPART_PART_SIZE, file.length);
        const partData = file.subarray(start, end);
        const etag = await this.uploadPart(uploadId, i + 1, partData);
        etags.push(etag);
      }

      await this.completeMultipartUpload(uploadId);

      const etag = etags.join('');
      return this.buildUploadedFile(objectKey, originalName, file.length, contentType, etag, options);
    } catch (err: unknown) {
      await this.abortMultipartUpload(uploadId).catch(() => {});
      throw new Error(`Multipart upload failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  }

  private parseListResponse(xml: string): UploadedFile[] {
    const objects: UploadedFile[] = [];
    const contentRegex = /<Contents>([\s\S]*?)<\/Contents>/g;
    let match: RegExpExecArray | null;

    while ((match = contentRegex.exec(xml)) !== null) {
      const keyMatch = /<Key>([^<]+)<\/Key>/.exec(match[1]);
      const sizeMatch = /<Size>(\d+)<\/Size>/.exec(match[1]);
      const dateMatch = /<LastModified>([^<]+)<\/LastModified>/.exec(match[1]);

      if (keyMatch) {
        objects.push({
          id: keyMatch[1],
          filename: keyMatch[1].split('/').pop() || keyMatch[1],
          originalName: keyMatch[1].split('/').pop() || keyMatch[1],
          mimeType: this.guessContentType(keyMatch[1]),
          size: sizeMatch ? parseInt(sizeMatch[1], 10) : 0,
          url: this.getPublicUrl(keyMatch[1]),
          uploadedBy: 'system',
          companyId: '',
          createdAt: dateMatch ? new Date(dateMatch[1]) : new Date(),
        });
      }
    }

    return objects;
  }

  private parseListObjects(xml: string): Array<{ key: string; size: number; lastModified: string }> {
    const objects: Array<{ key: string; size: number; lastModified: string }> = [];
    const contentRegex = /<Contents>([\s\S]*?)<\/Contents>/g;
    let match: RegExpExecArray | null;

    while ((match = contentRegex.exec(xml)) !== null) {
      const keyMatch = /<Key>([^<]+)<\/Key>/.exec(match[1]);
      const sizeMatch = /<Size>(\d+)<\/Size>/.exec(match[1]);
      const dateMatch = /<LastModified>([^<]+)<\/LastModified>/.exec(match[1]);

      if (keyMatch) {
        objects.push({
          key: keyMatch[1],
          size: sizeMatch ? parseInt(sizeMatch[1], 10) : 0,
          lastModified: dateMatch?.[1] || '',
        });
      }
    }

    return objects;
  }
}