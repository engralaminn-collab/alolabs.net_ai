// ─── Storage Provider Types ──────────────────────────────────────────────────

export type StorageProvider = 'local' | 's3' | 'minio';

export interface StorageConfig {
  provider: StorageProvider;
  bucket?: string;
  basePath?: string;
  endpoint?: string;
  accessKey?: string;
  secretKey?: string;
  region?: string;
  cdnUrl?: string;
  port?: number;
  useSSL?: boolean;
}

// ─── File Types ──────────────────────────────────────────────────────────────

export interface UploadedFile {
  id: string;
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  url: string;
  thumbnailUrl?: string;
  metadata?: Record<string, string>;
  uploadedBy: string;
  companyId: string;
  createdAt: Date;
}

export interface UploadOptions {
  folder?: string;
  publicAccess?: boolean;
  generateThumbnail?: boolean;
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  allowedTypes?: string[];
}

// ─── Stats Types ─────────────────────────────────────────────────────────────

export interface StorageStats {
  totalFiles: number;
  totalSize: number;
  byType: Map<string, number>;
  byMonth: Map<string, number>;
}

// ─── Image Metadata ──────────────────────────────────────────────────────────

export interface ImageMetadata {
  width: number;
  height: number;
  mimeType: string;
  size: number;
}

// ─── Validation Result ───────────────────────────────────────────────────────

export interface ValidationResult {
  valid: boolean;
  error?: string;
}

// ─── Processing Options ──────────────────────────────────────────────────────

export interface ImageProcessOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  format?: 'jpeg' | 'png' | 'webp';
}

// ─── S3 Multipart Upload Types ───────────────────────────────────────────────

export interface MultipartUploadPart {
  partNumber: number;
  etag: string;
}

export interface MultipartUploadState {
  uploadId: string;
  key: string;
  bucket: string;
  parts: MultipartUploadPart[];
}

// ─── Storage Provider Interface ──────────────────────────────────────────────

export interface IStorageProvider {
  upload(file: Buffer, filename: string, options?: UploadOptions): Promise<UploadedFile>;
  download(fileId: string): Promise<Buffer>;
  delete(fileId: string): Promise<void>;
  list(prefix?: string): Promise<UploadedFile[]>;
  getStats(): Promise<StorageStats>;
  generateThumbnail(fileId: string, width: number, height: number): Promise<string>;
  getPublicUrl(fileId: string): string;
  getSignedUrl?(fileId: string, expiresInSec?: number): string;
  verifySignedUrl?(fileId: string, expires: number, sig: string): boolean;
}