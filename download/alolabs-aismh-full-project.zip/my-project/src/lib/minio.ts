/**
 * MinIO / S3-Compatible File Storage Adapter
 * Uses S3 REST API via fetch (no native dependency).
 * Falls back to local filesystem when MinIO/S3 is not available.
 */

import { db } from './db';
import { writeFile, mkdir, readFile, unlink, stat, readdir } from 'fs/promises';
import path from 'path';

export interface MinioConfig {
  endPoint: string;
  port: number;
  accessKey: string;
  secretKey: string;
  useSSL: boolean;
  region: string;
  bucket: string;
}

let config: MinioConfig | null = null;
let connected = false;
let connectionError: string | null = null;

const LOCAL_STORAGE_DIR = path.join(process.cwd(), 'storage', 'minio-fallback');

function getBaseUrl(): string {
  if (!config) throw new Error('MinIO not configured');
  const protocol = config.useSSL ? 'https' : 'http';
  return `${protocol}://${config.endPoint}:${config.port}`;
}

async function getAuthHeaders(method: string, bucketPath: string, dateStr: string): Promise<Record<string, string>> {
  if (!config) throw new Error('MinIO not configured');

  const stringToSign = `${method}\n\n\n${dateStr}\n/${config.bucket}${bucketPath}`;
  // For simplicity, we use the secret key directly (AWS Signature V4 would be more complex)
  // In production, use @aws-sdk/client-s3 or minio npm package
  const signature = Buffer.from(stringToSign).toString('base64');

  return {
    'Host': `${config.endPoint}:${config.port}`,
    'Date': dateStr,
    'Authorization': `AWS ${config.accessKey}:${signature}`,
  };
}

async function minioRequest(
  method: string,
  objectKey: string,
  body?: ArrayBuffer | null,
  contentType?: string
): Promise<{ ok: boolean; status: number; data?: unknown; error?: string }> {
  const dateStr = new Date().toUTCString();
  const url = `${getBaseUrl()}/${config!.bucket}/${objectKey}`;
  const headers: Record<string, string> = {
    ...await getAuthHeaders(method, `/${objectKey}`, dateStr),
  };
  if (contentType) headers['Content-Type'] = contentType;

  try {
    const response = await fetch(url, {
      method,
      headers,
      body: body || undefined,
      signal: AbortSignal.timeout(30000),
    });

    if (!response.ok) {
      return { ok: false, status: response.status, error: await response.text() };
    }

    let data: unknown = null;
    const ct = response.headers.get('content-type') || '';
    if (ct.includes('json')) {
      data = await response.json();
    } else if (ct.includes('xml')) {
      data = await response.text();
    }

    return { ok: true, status: response.status, data };
  } catch (err: unknown) {
    return { ok: false, status: 0, error: err instanceof Error ? err.message : String(err) };
  }
}

export async function connectMinio(cfg?: MinioConfig): Promise<{ success: boolean; error?: string; latencyMs?: number; version?: string }> {
  const startTime = Date.now();

  try {
    config = cfg || getDefaultConfig();

    if (!config) {
      connectionError = 'MinIO: No configuration provided. Set MINIO_URL or MINIO_* env vars.';
      connected = false;
      return { success: false, error: connectionError };
    }

    // Test by listing bucket
    const dateStr = new Date().toUTCString();
    const url = `${getBaseUrl()}/${config.bucket}?location`;
    const headers = await getAuthHeaders('GET', '/?location', dateStr);

    const response = await fetch(url, {
      method: 'GET',
      headers,
      signal: AbortSignal.timeout(10000),
    });

    if (!response.ok && response.status !== 200) {
      throw new Error(`MinIO returned ${response.status}`);
    }

    const latencyMs = Date.now() - startTime;
    connected = true;
    connectionError = null;

    // Ensure local fallback dir exists
    await mkdir(LOCAL_STORAGE_DIR, { recursive: true });

    await db.infraService.upsert({
      where: { type: 'minio' },
      create: {
        name: 'MinIO',
        type: 'minio',
        host: config.endPoint,
        port: config.port,
        status: 'connected',
        connectedAt: new Date(),
        lastPingAt: new Date(),
        latencyMs,
        version: 'S3 Compatible',
        configJson: JSON.stringify({ bucket: config.bucket, region: config.region, ssl: config.useSSL }),
      },
      update: {
        host: config.endPoint,
        port: config.port,
        status: 'connected',
        connectedAt: new Date(),
        lastPingAt: new Date(),
        latencyMs,
        version: 'S3 Compatible',
        configJson: JSON.stringify({ bucket: config.bucket, region: config.region, ssl: config.useSSL }),
        errorCount: 0,
        lastError: null,
      },
    }).catch(() => {});

    return { success: true, latencyMs, version: 'S3 Compatible' };
  } catch (err: unknown) {
    const error = err instanceof Error ? err.message : String(err);
    connected = false;
    connectionError = error;

    // Set up local fallback
    await mkdir(LOCAL_STORAGE_DIR, { recursive: true });

    await db.infraService.upsert({
      where: { type: 'minio' },
      create: { name: 'MinIO', type: 'minio', status: 'fallback', lastError: error, errorCount: 1 },
      update: { status: 'fallback', lastError: error, errorCount: { increment: 1 } },
    }).catch(() => {});

    return { success: false, error, latencyMs: Date.now() - startTime };
  }
}

export function isMinioConnected(): boolean {
  return connected;
}

export function getMinioError(): string | null {
  return connectionError;
}

export function getMinioStatus(): 'connected' | 'fallback' | 'disconnected' {
  if (connected) return 'connected';
  if (connectionError) return 'fallback';
  return 'disconnected';
}

// ─── Object Operations ────────────────────────────────────────────────────────

export async function putObject(key: string, data: ArrayBuffer, contentType: string, metadata?: Record<string, string>): Promise<{ success: boolean; key: string; size: number; storageType: string }> {
  if (connected && config) {
    const result = await minioRequest('PUT', key, data, contentType);
    if (result.ok) {
      return { success: true, key, size: data.byteLength, storageType: 'minio' };
    }
    console.error('[MinIO] putObject failed:', result.error, '- falling back to local');
  }

  // Fallback to local filesystem
  const localPath = path.join(LOCAL_STORAGE_DIR, key);
  await mkdir(path.dirname(localPath), { recursive: true });
  await writeFile(localPath, Buffer.from(data));

  return { success: true, key, size: data.byteLength, storageType: 'local' };
}

export async function getObject(key: string): Promise<{ data: ArrayBuffer; contentType?: string; storageType: string } | null> {
  if (connected && config) {
    const result = await minioRequest('GET', key);
    if (result.ok && result.data instanceof ArrayBuffer) {
      return { data: result.data, storageType: 'minio' };
    }
    // If MinIO returns XML (object not found), fall through to local
  }

  // Fallback to local filesystem
  const localPath = path.join(LOCAL_STORAGE_DIR, key);
  try {
    const data = await readFile(localPath);
    return { data: data.buffer, storageType: 'local' };
  } catch {
    return null;
  }
}

export async function deleteObject(key: string): Promise<{ success: boolean; storageType: string }> {
  if (connected && config) {
    const result = await minioRequest('DELETE', key);
    if (result.ok || result.status === 204) {
      return { success: true, storageType: 'minio' };
    }
  }

  // Fallback: delete local
  const localPath = path.join(LOCAL_STORAGE_DIR, key);
  try {
    await unlink(localPath);
    return { success: true, storageType: 'local' };
  } catch {
    return { success: false, storageType: 'none' };
  }
}

export async function listObjects(prefix?: string, maxKeys: number = 100): Promise<{ key: string; size: number; lastModified: string; storageType: string }[]> {
  if (connected && config) {
    const listPrefix = prefix || '';
    const result = await minioRequest('GET', `?list-type=2&prefix=${encodeURIComponent(listPrefix)}&max-keys=${maxKeys}`);
    if (result.ok && result.data) {
      // Parse S3 XML response (simplified)
      const text = typeof result.data === 'string' ? result.data : JSON.stringify(result.data);
      const objects: { key: string; size: number; lastModified: string }[] = [];
      const keyRegex = /<Key>([^<]+)<\/Key>/g;
      const sizeRegex = /<Size>(\d+)<\/Size>/g;
      const dateRegex = /<LastModified>([^<]+)<\/LastModified>/g;

      let keyMatch: RegExpExecArray | null;
      let sizeMatch: RegExpExecArray | null;
      let dateMatch: RegExpExecArray | null;
      const keys: string[] = [];
      const sizes: number[] = [];
      const dates: string[] = [];

      while ((keyMatch = keyRegex.exec(text)) !== null) keys.push(keyMatch[1]);
      while ((sizeMatch = sizeRegex.exec(text)) !== null) sizes.push(parseInt(sizeMatch[1], 10));
      while ((dateMatch = dateRegex.exec(text)) !== null) dates.push(dateMatch[1]);

      for (let i = 0; i < keys.length; i++) {
        objects.push({ key: keys[i], size: sizes[i] || 0, lastModified: dates[i] || '' });
      }

      return objects.map((o) => ({ ...o, storageType: 'minio' }));
    }
  }

  // Fallback: list local files
  return listLocalFiles(prefix, maxKeys);
}

async function listLocalFiles(prefix?: string, maxKeys?: number): Promise<{ key: string; size: number; lastModified: string; storageType: string }[]> {
  const files: { key: string; size: number; lastModified: string; storageType: string }[] = [];

  async function walk(dir: string, baseKey: string): Promise<void> {
    try {
      const entries = await readdir(dir, { withFileTypes: true });
      for (const entry of entries) {
        const fullKey = baseKey ? `${baseKey}/${entry.name}` : entry.name;
        if (entry.isDirectory()) {
          if (!prefix || fullKey.startsWith(prefix)) {
            await walk(path.join(dir, entry.name), fullKey);
          }
        } else if (!prefix || fullKey.startsWith(prefix)) {
          try {
            const s = await stat(path.join(dir, entry.name));
            files.push({
              key: fullKey,
              size: s.size,
              lastModified: s.mtime.toISOString(),
              storageType: 'local',
            });
          } catch { /* skip */ }
        }
      }
    } catch { /* directory doesn't exist */ }
  }

  await walk(LOCAL_STORAGE_DIR, '');
  return maxKeys ? files.slice(0, maxKeys) : files;
}

export async function getPresignedUrl(key: string, expiresInSeconds: number = 3600): Promise<{ url: string; storageType: string }> {
  if (connected && config) {
    // Use the API route as a proxy for file access (works with both MinIO and local fallback)
    // For production direct access, install @aws-sdk/client-s3 and use getSignedUrl()
    const protocol = config.useSSL ? 'https' : 'http';
    const directUrl = `${protocol}://${config.endPoint}:${config.port}/${config.bucket}/${key}`;
    const proxyUrl = `/api/infra/minio/objects?key=${encodeURIComponent(key)}`;
    // Return proxy URL for authenticated access, direct URL is available via config
    return { url: proxyUrl, storageType: 'minio' };
  }

  return { url: `/api/infra/minio/objects?key=${encodeURIComponent(key)}`, storageType: 'local' };
}

export async function getObjectSize(key: string): Promise<number> {
  if (connected && config) {
    const result = await minioRequest('HEAD', key);
    if (result.ok) {
      // Parse size from headers (not available in our simplified implementation)
      return 0;
    }
  }

  try {
    const s = await stat(path.join(LOCAL_STORAGE_DIR, key));
    return s.size;
  } catch {
    return 0;
  }
}

// ─── Stats & Health ──────────────────────────────────────────────────────────

export async function getMinioStats(): Promise<{
  connected: boolean;
  status: string;
  bucket?: string;
  objectCount?: number;
  totalSizeBytes?: number;
  storageType: string;
}> {
  if (connected && config) {
    try {
      const objects = await listObjects('', 1000);
      const totalSizeBytes = objects.reduce((sum, o) => sum + o.size, 0);
      return {
        connected: true,
        status: 'connected',
        bucket: config.bucket,
        objectCount: objects.length,
        totalSizeBytes,
        storageType: 'minio',
      };
    } catch {
      return { connected: true, status: 'degraded', storageType: 'minio' };
    }
  }

  try {
    const objects = await listLocalFiles('', 1000);
    return {
      connected: false,
      status: 'fallback',
      bucket: config?.bucket || 'local-storage',
      objectCount: objects.length,
      totalSizeBytes: objects.reduce((sum, o) => sum + o.size, 0),
      storageType: 'local',
    };
  } catch {
    return { connected: false, status: 'disconnected', storageType: 'none' };
  }
}

export async function pingMinio(): Promise<{ success: boolean; latencyMs: number; error?: string; storageType?: string }> {
  if (!connected || !config) {
    return { success: false, latencyMs: 0, error: 'Not connected', storageType: 'none' };
  }

  const startTime = Date.now();
  try {
    const result = await minioRequest('GET', `?max-keys=1`);
    const latencyMs = Date.now() - startTime;

    if (result.ok) {
      await db.infraService.update({
        where: { type: 'minio' },
        data: { lastPingAt: new Date(), latencyMs, status: 'connected' },
      }).catch(() => {});

      return { success: true, latencyMs };
    }
    return { success: false, latencyMs, error: result.error };
  } catch (err: unknown) {
    const error = err instanceof Error ? err.message : String(err);
    await db.infraService.update({
      where: { type: 'minio' },
      data: { status: 'error', lastError: error, errorCount: { increment: 1 } },
    }).catch(() => {});
    return { success: false, latencyMs: Date.now() - startTime, error };
  }
}

function getDefaultConfig(): MinioConfig | null {
  if (process.env.MINIO_URL) {
    try {
      const url = new URL(process.env.MINIO_URL);
      return {
        endPoint: url.hostname || 'localhost',
        port: parseInt(url.port || '9000', 10),
        accessKey: url.username || 'minioadmin',
        secretKey: url.password || 'minioadmin',
        useSSL: url.protocol === 'https:',
        region: process.env.MINIO_REGION || 'us-east-1',
        bucket: process.env.MINIO_BUCKET || 'agent-hub',
      };
    } catch {
      return null;
    }
  }

  if (process.env.MINIO_HOST) {
    return {
      endPoint: process.env.MINIO_HOST,
      port: parseInt(process.env.MINIO_PORT || '9000', 10),
      accessKey: process.env.MINIO_ACCESS_KEY || 'minioadmin',
      secretKey: process.env.MINIO_SECRET_KEY || 'minioadmin',
      useSSL: process.env.MINIO_SSL === 'true',
      region: process.env.MINIO_REGION || 'us-east-1',
      bucket: process.env.MINIO_BUCKET || 'agent-hub',
    };
  }

  return null;
}

export function getMinioConfig(): MinioConfig | null {
  return config || getDefaultConfig();
}