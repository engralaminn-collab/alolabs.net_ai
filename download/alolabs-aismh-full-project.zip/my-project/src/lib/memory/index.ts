/**
 * Memory System
 * Unified memory for AI agents: short-term, long-term, semantic, episodic.
 * In-memory with optional Qdrant/DB persistence.
 */

import type { MemoryEntry, MemoryQuery, MemorySearchResult, MemoryStoreConfig, MemoryType } from './types';
import { DEFAULT_MEMORY_CONFIG } from './types';

class MemoryStore {
  private memories = new Map<string, MemoryEntry>();
  private config: MemoryStoreConfig;

  constructor(config?: Partial<MemoryStoreConfig>) {
    this.config = { ...DEFAULT_MEMORY_CONFIG, ...config };
  }

  // ─── CRUD ─────────────────────────────────────────────────────

  store(entry: MemoryEntry): MemoryEntry {
    this.memories.set(entry.id, entry);
    return entry;
  }

  get(id: string): MemoryEntry | undefined {
    return this.memories.get(id);
  }

  delete(id: string): boolean {
    return this.memories.delete(id);
  }

  update(id: string, updates: Partial<MemoryEntry>): MemoryEntry | undefined {
    const existing = this.memories.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...updates, updatedAt: new Date() };
    this.memories.set(id, updated);
    return updated;
  }

  // ─── Query ─────────────────────────────────────────────────────

  /** Simple text search across all memories */
  search(query: MemoryQuery): MemorySearchResult[] {
    const results: MemorySearchResult[] = [];
    const queryLower = query.text.toLowerCase();
    const now = Date.now();

    for (const entry of this.memories.values()) {
      // Scope filter
      if (query.companyId && entry.companyId !== query.companyId) continue;
      if (query.agentId && entry.agentId !== query.agentId) continue;
      if (query.userId && entry.userId !== query.userId) continue;
      if (query.type && entry.type !== query.type) continue;
      if (query.scope && entry.scope !== query.scope) continue;
      if (query.minRank && entry.rank < query.minRank) continue;

      // Expiry check
      if (entry.expiresAt && entry.expiresAt.getTime() < now) continue;

      // Text matching (simple keyword scoring)
      const contentLower = entry.content.toLowerCase();
      const keyLower = entry.key.toLowerCase();
      const textScore = this.computeTextScore(queryLower, contentLower, keyLower);

      if (textScore > 0) {
        // Boost by rank and recency
        const ageHours = (now - entry.updatedAt.getTime()) / 3_600_000;
        const recencyBoost = Math.max(0, 1 - ageHours / 168); // decay over 1 week
        const finalScore = textScore * (entry.rank / 100) * (0.5 + 0.5 * recencyBoost);

        results.push({
          entry,
          score: Math.round(finalScore * 1000) / 1000,
        });
      }
    }

    // Sort by score descending
    results.sort((a, b) => b.score - a.score);
    return results.slice(0, query.limit ?? 20);
  }

  /** Get memories for a specific agent */
  getByAgent(agentId: string, type?: MemoryType): MemoryEntry[] {
    const results: MemoryEntry[] = [];
    const now = Date.now();
    for (const entry of this.memories.values()) {
      if (entry.agentId !== agentId) continue;
      if (type && entry.type !== type) continue;
      if (entry.expiresAt && entry.expiresAt.getTime() < now) continue;
      results.push(entry);
    }
    return results.sort((a, b) => b.rank - a.rank);
  }

  /** Get short-term memory (conversation context) for an agent */
  getShortTerm(agentId: string): MemoryEntry[] {
    const cutoff = Date.now() - this.config.shortTermMaxAge;
    return this.getByAgent(agentId, 'short_term')
      .filter(m => m.updatedAt.getTime() >= cutoff)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  /** Get long-term memory */
  getLongTerm(agentId?: string, companyId?: string): MemoryEntry[] {
    return Array.from(this.memories.values())
      .filter(m => {
        if (m.type !== 'long_term' && m.type !== 'semantic') return false;
        if (agentId && m.agentId !== agentId) return false;
        if (companyId && m.companyId !== companyId) return false;
        return true;
      })
      .sort((a, b) => b.rank - a.rank);
  }

  // ─── Memory Management ────────────────────────────────────────

  /** Store a short-term memory (auto-expires) */
  addShortTerm(params: {
    agentId: string; companyId: string; userId?: string;
    key: string; content: string;
  }): MemoryEntry {
    const entry: MemoryEntry = {
      id: `mem_st_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      type: 'short_term', scope: 'private',
      agentId: params.agentId, companyId: params.companyId, userId: params.userId,
      key: params.key, content: params.content,
      rank: 70, accessCount: 1, compressed: false,
      expiresAt: new Date(Date.now() + this.config.shortTermMaxAge),
      createdAt: new Date(), updatedAt: new Date(),
    };
    return this.store(entry);
  }

  /** Store a long-term memory */
  addLongTerm(params: {
    agentId?: string; companyId: string; userId?: string;
    key: string; content: string; scope?: 'private' | 'team' | 'company';
    rank?: number;
  }): MemoryEntry {
    const entry: MemoryEntry = {
      id: `mem_lt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      type: 'long_term', scope: params.scope ?? 'private',
      agentId: params.agentId, companyId: params.companyId, userId: params.userId,
      key: params.key, content: params.content,
      rank: params.rank ?? this.config.defaultRank,
      accessCount: 1, compressed: false,
      createdAt: new Date(), updatedAt: new Date(),
    };
    return this.store(entry);
  }

  /** Store an episodic memory (interaction record) */
  addEpisodic(params: {
    agentId: string; companyId: string; userId: string;
    content: string; metadata?: Record<string, unknown>;
  }): MemoryEntry {
    const entry: MemoryEntry = {
      id: `mem_ep_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      type: 'episodic', scope: 'private',
      agentId: params.agentId, companyId: params.companyId, userId: params.userId,
      key: `episodic_${Date.now()}`,
      content: params.content, metadata: params.metadata,
      rank: 40, accessCount: 1, compressed: false,
      createdAt: new Date(), updatedAt: new Date(),
    };
    return this.store(entry);
  }

  /** Decay ranks of old memories */
  decayRanks(): number {
    let decayed = 0;
    const now = Date.now();
    for (const entry of this.memories.values()) {
      if (entry.type === 'short_term') continue;
      const ageDays = (now - entry.updatedAt.getTime()) / 86_400_000;
      if (ageDays > 1) {
        const decay = Math.floor(ageDays * this.config.rankDecayPerDay);
        if (decay > 0) {
          entry.rank = Math.max(0, entry.rank - decay);
          entry.updatedAt = new Date();
          decayed++;
        }
      }
    }
    return decayed;
  }

  /** Expire old short-term memories */
  expireShortTerm(): number {
    let expired = 0;
    const now = Date.now();
    for (const [id, entry] of this.memories) {
      if (entry.type === 'short_term' && entry.expiresAt && entry.expiresAt.getTime() < now) {
        this.memories.delete(id);
        expired++;
      }
    }
    return expired;
  }

  /** Get memory stats */
  getStats(): { total: number; byType: Record<string, number>; oldest: Date | null } {
    const byType: Record<string, number> = {};
    let oldest: Date | null = null;
    for (const entry of this.memories.values()) {
      byType[entry.type] = (byType[entry.type] ?? 0) + 1;
      if (!oldest || entry.createdAt < oldest) oldest = entry.createdAt;
    }
    return { total: this.memories.size, byType, oldest };
  }

  /** Get total count */
  get size(): number {
    return this.memories.size;
  }

  // ─── Internal ────────────────────────────────────────────────

  private computeTextScore(query: string, content: string, key: string): number {
    const queryWords = query.split(/\s+/).filter(w => w.length > 1);
    if (queryWords.length === 0) return 0;

    let matches = 0;
    for (const word of queryWords) {
      if (content.includes(word)) matches += 1;
      if (key.includes(word)) matches += 2; // key matches weighted higher
    }
    return matches / queryWords.length;
  }
}

// Singleton
let _instance: MemoryStore | null = null;
export function getMemoryStore(config?: Partial<MemoryStoreConfig>): MemoryStore {
  if (!_instance) _instance = new MemoryStore(config);
  return _instance;
}

export type { MemoryEntry, MemoryQuery, MemorySearchResult, MemoryType, MemoryScope, MemoryStoreConfig } from './types';
