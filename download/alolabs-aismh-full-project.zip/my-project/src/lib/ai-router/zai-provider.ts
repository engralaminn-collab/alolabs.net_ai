/**
 * Z-AI SDK Provider
 * ALO Labs AIOS — Wraps the z-ai-web-dev-sdk for AI completions.
 * Delegates to the SDK's chat.completions.create method.
 */

import type {
  AIModel,
  AIModelFamily,
  AICapability,
  AIProviderHealth,
  AIRequest,
  AIResponse,
  AIStreamChunk,
} from './types';
import { AIRouterError } from './types';
import { BaseAIProvider } from './provider-base';

// ─── Types for SDK interface ────────────────────────────────────────

interface ZAIChatMessage {
  role: string;
  content: string;
}

interface ZAIChatCompletionOptions {
  model?: string;
  messages: ZAIChatMessage[];
  temperature?: number;
  max_tokens?: number;
  stream?: boolean;
  tools?: unknown[];
  [key: string]: unknown;
}

interface ZAIUsage {
  prompt_tokens?: number;
  completion_tokens?: number;
  total_tokens?: number;
}

interface ZAIChatCompletionResponse {
  id: string;
  model: string;
  content: string;
  finish_reason?: string;
  usage?: ZAIUsage;
}

interface ZAIStreamDelta {
  content?: string;
  finish_reason?: string;
}

interface ZAIChatStreamChunk {
  id: string;
  model: string;
  delta: ZAIStreamDelta;
}

interface ZAIInstance {
  chat: {
    completions: {
      create: (options: ZAIChatCompletionOptions) => Promise<ZAIChatCompletionResponse | AsyncIterable<ZAIChatStreamChunk>>;
    };
  };
  listModels?(): Promise<ZAIModelInfo[]>;
}

interface ZAIModelInfo {
  id: string;
  name: string;
  context_length?: number;
  capabilities?: string[];
}

interface ZAIModule {
  create: (config?: Record<string, unknown>) => ZAIInstance;
}

// ─── Helpers ────────────────────────────────────────────────────────

function mapFinishReason(reason?: string): AIResponse['finishReason'] {
  switch (reason) {
    case 'stop':
      return 'stop';
    case 'length':
    case 'max_tokens':
      return 'length';
    case 'tool_calls':
      return 'tool-calls';
    case 'content_filter':
      return 'content-filter';
    default:
      return 'stop';
  }
}

function inferFamilyFromId(modelId: string): AIModelFamily {
  const id = modelId.toLowerCase();
  if (id.includes('glm')) return 'glm';
  if (id.includes('qwen')) return 'qwen';
  if (id.includes('deepseek')) return 'deepseek';
  if (id.includes('llama')) return 'llama';
  if (id.includes('gemma')) return 'gemma';
  if (id.includes('phi')) return 'phi';
  if (id.includes('mistral') || id.includes('mixtral')) return 'mistral';
  return 'custom';
}

function inferCapabilitiesFromId(modelId: string): AICapability[] {
  const id = modelId.toLowerCase();
  const caps: AICapability[] = ['chat', 'streaming'];
  if (id.includes('vision') || id.includes('vl')) caps.push('vision');
  if (id.includes('tool') || id.includes('func')) caps.push('function-calling');
  if (id.includes('coder') || id.includes('code')) caps.push('code-generation');
  caps.push('json-mode'); // Most modern models support this
  return caps;
}

// ─── Provider ───────────────────────────────────────────────────────

export class ZAIProvider extends BaseAIProvider {
  readonly name = 'zai-sdk' as const;
  supportedModels: AIModel[] = [];

  private client: ZAIInstance | null = null;
  private zaiModule: ZAIModule | null = null;

  constructor() {
    super();
  }

  // ─── Lifecycle ──────────────────────────────────────────────────

  async initialize(): Promise<void> {
    try {
      // Dynamic import so the module is only loaded when this provider is used
      this.zaiModule = (await import('z-ai-web-dev-sdk')) as unknown as ZAIModule;
      this.client = this.zaiModule.create();

      // Verify the client works by listing models
      this.supportedModels = await this.listModels();
      this._initialized = true;
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      throw new AIRouterError(
        `Failed to initialize Z-AI SDK: ${message}`,
        'zai-sdk',
        undefined,
        false,
      );
    }
  }

  async disconnect(): Promise<void> {
    this.client = null;
    this.zaiModule = null;
    await super.disconnect();
  }

  // ─── Models ─────────────────────────────────────────────────────

  async listModels(): Promise<AIModel[]> {
    if (!this.client) return [];

    try {
      if (typeof this.client.listModels === 'function') {
        const models = await this.client.listModels();
        return models.map((m) => ({
          id: m.id,
          name: m.name,
          provider: 'zai-sdk' as const,
          family: inferFamilyFromId(m.id),
          parameters: {},
          contextLength: m.context_length ?? 32_000,
          capabilities: (m.capabilities as AICapability[]) ?? inferCapabilitiesFromId(m.id),
        }));
      }
    } catch {
      // If listModels is not available, return defaults
    }

    // Fallback: return a default set based on known Z-AI models
    return [
      {
        id: 'glm-4',
        name: 'GLM-4',
        provider: 'zai-sdk',
        family: 'glm',
        parameters: {},
        contextLength: 128_000,
        capabilities: ['chat', 'streaming', 'function-calling', 'json-mode', 'code-generation'],
      },
    ];
  }

  // ─── Chat Completion (non-streaming) ────────────────────────────

  async chatCompletion(request: AIRequest): Promise<AIResponse> {
    this.requireInitialized();
    if (!this.client) {
      throw new AIRouterError('Z-AI SDK client not initialized', 'zai-sdk');
    }

    const release = this.trackConnection();
    const startTime = Date.now();

    try {
      const options: ZAIChatCompletionOptions = {
        model: request.model,
        messages: request.messages.map((m) => ({ role: m.role, content: m.content })),
        temperature: request.temperature,
        max_tokens: request.maxTokens,
        stream: false,
      };

      if (request.tools) {
        options.tools = request.tools;
      }

      const result = await this.withRetry(async () => {
        const response = await this.client!.chat.completions.create(options);
        // The SDK may return the response directly (non-streaming)
        return response as ZAIChatCompletionResponse;
      });

      const latencyMs = Date.now() - startTime;

      return {
        id: result.id,
        content: result.content,
        model: result.model ?? request.model,
        usage: {
          promptTokens: result.usage?.prompt_tokens ?? this.estimateRequestTokens(request),
          completionTokens: result.usage?.completion_tokens ?? 0,
          totalTokens: result.usage?.total_tokens ?? 0,
        },
        finishReason: mapFinishReason(result.finish_reason),
        latencyMs,
      };
    } finally {
      release();
    }
  }

  // ─── Chat Completion (streaming) ────────────────────────────────

  async *streamChatCompletion(request: AIRequest): AsyncGenerator<AIStreamChunk> {
    this.requireInitialized();
    if (!this.client) {
      throw new AIRouterError('Z-AI SDK client not initialized', 'zai-sdk');
    }

    const release = this.trackConnection();

    try {
      const options: ZAIChatCompletionOptions = {
        model: request.model,
        messages: request.messages.map((m) => ({ role: m.role, content: m.content })),
        temperature: request.temperature,
        max_tokens: request.maxTokens,
        stream: true,
      };

      const stream = await this.client.chat.completions.create(options);

      // The SDK returns an AsyncIterable when streaming
      if (typeof (stream as AsyncIterable<ZAIChatStreamChunk>)[Symbol.asyncIterator] === 'function') {
        for await (const chunk of stream as AsyncIterable<ZAIChatStreamChunk>) {
          yield {
            id: chunk.id,
            content: chunk.delta?.content ?? '',
            model: chunk.model,
            finishReason: chunk.delta?.finish_reason
              ? mapFinishReason(chunk.delta.finish_reason)
              : undefined,
          };
        }
      }
    } finally {
      release();
    }
  }

  // ─── Health Check ───────────────────────────────────────────────

  async healthCheck(): Promise<AIProviderHealth> {
    const startTime = Date.now();

    try {
      if (!this.client) {
        // Try a quick initialization to verify the SDK is importable
        await this.initialize();
      }

      // Attempt to list models as a connectivity check
      const models = await this.listModels();
      const latencyMs = Date.now() - startTime;

      return {
        provider: 'zai-sdk',
        isHealthy: models.length > 0,
        latencyMs,
        errorRate: 0,
        lastCheck: new Date(),
        consecutiveFailures: 0,
        circuitOpen: false,
      };
    } catch {
      return {
        provider: 'zai-sdk',
        isHealthy: false,
        latencyMs: Date.now() - startTime,
        errorRate: 1,
        lastCheck: new Date(),
        consecutiveFailures: 0,
        circuitOpen: false,
      };
    }
  }
}