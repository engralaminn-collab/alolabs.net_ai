/**
 * AI Router — Public API
 * ALO Labs AIOS
 *
 * Re-exports all types, base classes, providers, and the singleton router.
 */

// ─── Types ──────────────────────────────────────────────────────────
export type {
  AIProvider,
  AIModel,
  AIModelFamily,
  AIModelParameters,
  AICapability,
  AIMessage,
  AITool,
  AIRequest,
  AIResponse,
  AIStreamChunk,
  AITokenUsage,
  AITokenUsageRecord,
  AIRouteDecision,
  AIRouteReason,
  AILoadBalanceStrategy,
  AILoadBalanceConfig,
  AIProviderHealth,
} from './types';

export {
  AIRouterError,
  AIProviderUnavailableError,
  AIModelNotFoundError,
  AICircuitOpenError,
} from './types';

// ─── Base ───────────────────────────────────────────────────────────
export { BaseAIProvider } from './provider-base';

// ─── Providers ──────────────────────────────────────────────────────
export { OllamaProvider } from './ollama-provider';
export { OpenRouterProvider } from './openrouter-provider';
export { ZAIProvider } from './zai-provider';

// ─── Router ─────────────────────────────────────────────────────────
export { AIRouter } from './router';

// ─── Singleton ──────────────────────────────────────────────────────
import { AIRouter } from './router';
import { ZAIProvider } from './zai-provider';

export const aiRouter = new AIRouter();

/**
 * Lazy singleton accessor for the AI Router.
 * Registers built-in providers on first use if none are registered.
 */
export function getRouter(): AIRouter {
  // Auto-register ZAI SDK provider on first access so callers don't crash
  if (aiRouter.getRegisteredProviders().length === 0) {
    try {
      aiRouter.registerProvider(new ZAIProvider());
    } catch {
      // If ZAI provider fails to construct, leave the router empty.
      // Callers will get AIProviderUnavailableError, which is accurate.
    }
  }
  return aiRouter;
}