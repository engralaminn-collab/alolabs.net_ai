import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

// ── Demo / seed data ────────────────────────────────────────────────
const DEMO_PAPERS = [
  { id: 'p-001', title: 'Scaling Laws for Agentic Reasoning in Multi-Step Tasks', authors: ['Dr. A. Chen', 'Dr. M. Zhang', 'Dr. L. Wang'], abstract: 'We investigate scaling behavior of LLM agents performing complex multi-step reasoning tasks across 12 benchmarks. Our findings reveal that agent performance follows a power-law relationship with model size when augmented with structured planning modules.', venue: 'NeurIPS 2025', date: '2025-01-15', status: 'published', citations: 47, domain: 'AI Agents', arxivId: '2501.08742', pdfUrl: '/papers/scaling-agents.pdf' },
  { id: 'p-002', title: 'Efficient MoE Routing with Dynamic Expert Allocation', authors: ['Dr. K. Liu', 'Dr. J. Park'], abstract: 'A novel routing mechanism for Mixture-of-Experts models that dynamically allocates experts based on token complexity, achieving 2.3x throughput improvement with negligible quality loss.', venue: 'ICML 2025', date: '2025-01-10', status: 'under-review', citations: 12, domain: 'Model Architecture', arxivId: '2501.06453', pdfUrl: '/papers/moe-routing.pdf' },
  { id: 'p-003', title: 'Cross-Lingual Knowledge Transfer in Low-Resource Settings', authors: ['Dr. R. Patel', 'Dr. S. Kim', 'Dr. A. Chen'], abstract: 'We propose a framework for transferring knowledge from high-resource to low-resource languages using shared embedding spaces and curriculum learning strategies.', venue: 'ACL 2025', date: '2025-01-08', status: 'draft', citations: 0, domain: 'NLP', arxivId: null, pdfUrl: null },
  { id: 'p-004', title: 'Neural Architecture Search for Efficient Edge Deployment', authors: ['Dr. L. Wang', 'Dr. H. Tanaka'], abstract: 'An automated neural architecture search method that optimizes transformer models for edge device deployment, reducing inference latency by 60% while maintaining 98% of original accuracy.', venue: 'CVPR 2025', date: '2024-12-28', status: 'published', citations: 89, domain: 'Efficiency', arxivId: '2412.19283', pdfUrl: '/papers/nas-edge.pdf' },
  { id: 'p-005', title: 'Multimodal Retrieval Augmented Generation for Enterprise Search', authors: ['Dr. M. Zhang', 'Dr. R. Patel', 'Dr. K. Liu'], abstract: 'A RAG pipeline combining text, image, and structured data retrieval for enterprise knowledge management, demonstrating 34% improvement in answer accuracy over text-only baselines.', venue: 'EMNLP 2025', date: '2024-12-20', status: 'under-review', citations: 23, domain: 'RAG', arxivId: '2412.15420', pdfUrl: '/papers/multimodal-rag.pdf' },
  { id: 'p-006', title: 'Self-Improving Code Generation via Execution Feedback Loops', authors: ['Dr. J. Park', 'Dr. A. Chen'], abstract: 'A framework where code generation models iteratively improve their outputs by executing generated code and incorporating runtime feedback, achieving 28% improvement on SWE-Bench.', venue: 'AAAI 2025', date: '2024-12-15', status: 'published', citations: 156, domain: 'Code Generation', arxivId: '2412.10245', pdfUrl: '/papers/self-improve-code.pdf' },
  { id: 'p-007', title: 'Constitutional AI Alignment with Dynamic Principle Sets', authors: ['Dr. S. Kim', 'Dr. M. Zhang', 'Dr. L. Wang'], abstract: 'We extend constitutional AI with dynamically adaptive principle sets that evolve based on deployment context, reducing harmful outputs by 42% compared to static principle approaches.', venue: 'ICLR 2025', date: '2024-12-10', status: 'under-review', citations: 31, domain: 'AI Safety', arxivId: '2412.08312', pdfUrl: '/papers/constitutional-ai.pdf' },
];

const DEMO_RESEARCH_GAPS = [
  { id: 'gap-1', title: 'Real-time Multi-Agent Coordination', description: 'No established benchmarks or methods for coordinating multiple AI agents in real-time with sub-second latency requirements.', priority: 'high', domain: 'AI Agents', relatedPapers: ['p-001'], potentialImpact: 'high', suggestedApproaches: ['Distributed consensus protocols', 'Hierarchical planning', 'Shared memory architectures'] },
  { id: 'gap-2', title: 'Long-Form Video Understanding', description: 'Current vision-language models struggle with videos longer than 5 minutes. Need temporal reasoning capabilities for hour-long content.', priority: 'high', domain: 'Multimodal', relatedPapers: ['p-005'], potentialImpact: 'high', suggestedApproaches: ['Hierarchical temporal attention', 'Memory-augmented processing', 'Keyframe-guided reasoning'] },
  { id: 'gap-3', title: 'Formal Verification of LLM Reasoning', description: 'Lack of methods to formally verify the correctness of multi-step reasoning chains produced by LLMs.', priority: 'medium', domain: 'AI Safety', relatedPapers: ['p-007'], potentialImpact: 'medium', suggestedApproaches: ['Proof-carrying reasoning', 'Self-consistency with formal checks', 'Neurosymbolic verification'] },
  { id: 'gap-4', title: 'Energy-Efficient Training at Scale', description: 'Training large models requires massive energy. Need methods to reduce carbon footprint by 5-10x without quality degradation.', priority: 'medium', domain: 'Efficiency', relatedPapers: ['p-002', 'p-004'], potentialImpact: 'high', suggestedApproaches: ['Sparse training', 'Mixed-precision with adaptive rates', 'Knowledge distillation pipelines'] },
  { id: 'gap-5', title: 'Cross-Domain Transfer for Scientific Reasoning', description: 'Models trained on general data perform poorly on specialized scientific domains (chemistry, physics, biology).', priority: 'high', domain: 'Domain Adaptation', relatedPapers: ['p-003'], potentialImpact: 'high', suggestedApproaches: ['Domain-specific pre-training', 'Retrieval-augmented fine-tuning', 'Expert-in-the-loop adaptation'] },
];

const DEMO_PROPOSALS = [
  { id: 'prop-1', title: 'ALO Agent Framework v2.0', abstract: 'Next-generation agent framework with native tool-use, memory management, and multi-agent orchestration capabilities.', status: 'approved', budget: '$180,000', duration: '6 months', team: ['Dr. A. Chen', 'Dr. J. Park', 'Eng. T. Nguyen'], startDate: '2025-02-01', priority: 'P0' },
  { id: 'prop-2', title: 'Multimodal Knowledge Graph Construction', abstract: 'Automated construction and maintenance of enterprise knowledge graphs from multimodal data sources.', status: 'under-review', budget: '$95,000', duration: '4 months', team: ['Dr. M. Zhang', 'Dr. R. Patel'], startDate: '2025-03-01', priority: 'P1' },
  { id: 'prop-3', title: 'Low-Latency Code Generation Service', abstract: 'Optimized inference pipeline for real-time code completion and generation with <100ms latency target.', status: 'draft', budget: '$60,000', duration: '3 months', team: ['Dr. K. Liu', 'Eng. S. Brown'], startDate: '2025-04-01', priority: 'P1' },
];

const DEMO_JOURNALS = [
  { id: 'j-1', name: 'Nature Machine Intelligence', issn: '2522-5839', impactFactor: 18.9, submissionDeadline: '2025-02-15', scope: 'AI/ML research', lastPublished: '2025-01-08', acceptanceRate: '8.2%' },
  { id: 'j-2', name: 'Journal of Machine Learning Research', issn: '1533-7928', impactFactor: 6.2, submissionDeadline: 'Rolling', scope: 'ML theory and applications', lastPublished: '2025-01-05', acceptanceRate: '15.4%' },
  { id: 'j-3', name: 'Transactions on Pattern Analysis and Machine Intelligence', issn: '0162-8828', impactFactor: 24.3, submissionDeadline: 'Rolling', scope: 'Computer vision and pattern recognition', lastPublished: '2025-01-02', acceptanceRate: '12.1%' },
  { id: 'j-4', name: 'Computational Linguistics', issn: '0891-2017', impactFactor: 9.8, submissionDeadline: 'Rolling', scope: 'NLP and computational linguistics', lastPublished: '2024-12-28', acceptanceRate: '18.7%' },
];

const DEMO_CONFERENCES = [
  { id: 'c-1', name: 'ICML 2025', location: 'Vancouver, Canada', date: '2025-07-13', deadline: '2025-01-31', status: 'submission-open', ourSubmissions: 3, topics: ['ML Theory', 'Deep Learning', 'RL', 'Generative Models'] },
  { id: 'c-2', name: 'NeurIPS 2025', location: 'Toronto, Canada', date: '2025-12-10', deadline: '2025-05-15', status: 'upcoming', ourSubmissions: 0, topics: ['Neural Networks', 'Optimization', 'AI Safety', 'Applications'] },
  { id: 'c-3', name: 'ACL 2025', location: 'Vienna, Austria', date: '2025-07-27', deadline: '2025-02-15', status: 'submission-open', ourSubmissions: 2, topics: ['NLP', 'Multilingual', 'Dialogue', 'Information Extraction'] },
  { id: 'c-4', name: 'EMNLP 2025', location: 'Lisbon, Portugal', date: '2025-09-15', deadline: '2025-04-15', status: 'upcoming', ourSubmissions: 0, topics: ['NLP Applications', 'Multimodal NLP', 'Efficient NLP'] },
];

const DEMO_PROJECTS = [
  { id: 'proj-1', name: 'Project Atlas', description: 'Unified multi-agent orchestration platform', status: 'active', progress: 68, lead: 'Dr. A. Chen', teamSize: 5, budget: '$180,000', spent: '$112,400', milestones: ['Architecture Design ✓', 'Core Framework ✓', 'Plugin System ✓', 'Benchmark Suite (in progress)', 'Production Deploy (pending)'], startDate: '2024-09-01', endDate: '2025-03-01' },
  { id: 'proj-2', name: 'Project Nova', description: 'Next-gen code generation with execution feedback', status: 'active', progress: 42, lead: 'Dr. J. Park', teamSize: 3, budget: '$120,000', spent: '$48,600', milestones: ['Data Collection ✓', 'Model Training (in progress)', 'Evaluation Suite (pending)', 'API Integration (pending)'], startDate: '2024-11-01', endDate: '2025-05-01' },
  { id: 'proj-3', name: 'Project Prism', description: 'Multimodal RAG for enterprise knowledge', status: 'active', progress: 85, lead: 'Dr. M. Zhang', teamSize: 4, budget: '$95,000', spent: '$78,200', milestones: ['Indexing Pipeline ✓', 'Retrieval System ✓', 'Generation Module ✓', 'Evaluation (in progress)', 'Deployment (pending)'], startDate: '2024-08-15', endDate: '2025-02-15' },
  { id: 'proj-4', name: 'Project Shield', description: 'AI safety and alignment research', status: 'planning', progress: 12, lead: 'Dr. S. Kim', teamSize: 2, budget: '$75,000', spent: '$8,000', milestones: ['Literature Review (in progress)', 'Benchmark Design (pending)', 'Method Development (pending)'], startDate: '2025-01-15', endDate: '2025-07-15' },
];

// ── Helpers ─────────────────────────────────────────────────────────
function filterByDateRange<T extends { date?: string; startDate?: string }>(
  items: T[],
  from?: string | null,
  to?: string | null,
): T[] {
  if (!from && !to) return items;
  return items.filter((item) => {
    const d = item.date || item.startDate || '';
    if (from && d < from) return false;
    if (to && d > to) return false;
    return true;
  });
}

function filterByStatus<T extends { status?: string }>(
  items: T[],
  status?: string | null,
): T[] {
  if (!status) return items;
  return items.filter((item) => item.status === status);
}

function filterByField<T extends Record<string, unknown>>(
  items: T[],
  field: string,
  value: string | null,
): T[] {
  if (!value || !field) return items;
  return items.filter((item) => {
    const v = item[field];
    if (Array.isArray(v)) return v.includes(value);
    if (typeof v === 'string') return v === value;
    return false;
  });
}

// ── GET ─────────────────────────────────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    await requireAuth();

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const domain = searchParams.get('domain');
    const source = searchParams.get('source');
    const type = searchParams.get('type');
    const dateFrom = searchParams.get('dateFrom');
    const dateTo = searchParams.get('dateTo');
    const search = searchParams.get('search');

    // Fetch any user-created records from the database
    const dbRecords = await db.settings.findMany({
      where: { key: { startsWith: 'research_hub:' } },
      orderBy: { createdAt: 'desc' },
    });

    const dbProjects: Record<string, unknown>[] = [];
    const dbGaps: Record<string, unknown>[] = [];
    const dbPaperAnalysis: Record<string, unknown>[] = [];

    for (const rec of dbRecords) {
      try {
        const parsed = JSON.parse(rec.value);
        const recType = parsed._type as string;
        if (recType === 'project') dbProjects.push({ ...parsed, dbId: rec.id });
        else if (recType === 'gap') dbGaps.push({ ...parsed, dbId: rec.id });
        else if (recType === 'paper_analysis') dbPaperAnalysis.push({ ...parsed, dbId: rec.id });
      } catch {
        // skip malformed records
      }
    }

    // Build papers list and apply filters
    let papers = [...DEMO_PAPERS];
    papers = filterByStatus(papers, status);
    if (domain) papers = filterByField(papers, 'domain', domain);
    if (source) papers = filterByField(papers, 'venue', source);
    papers = filterByDateRange(papers, dateFrom, dateTo);
    if (search) {
      const q = search.toLowerCase();
      papers = papers.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.abstract.toLowerCase().includes(q) ||
          p.authors.some((a) => a.toLowerCase().includes(q)),
      );
    }

    // Build research gaps list and apply filters
    let researchGaps = [...DEMO_RESEARCH_GAPS, ...dbGaps];
    if (domain) researchGaps = filterByField(researchGaps, 'domain', domain);
    if (status) researchGaps = filterByField(researchGaps, 'priority', status);
    if (search) {
      const q = search.toLowerCase();
      researchGaps = researchGaps.filter(
        (g) =>
          (g.title as string).toLowerCase().includes(q) ||
          (g.description as string).toLowerCase().includes(q),
      );
    }

    // Build proposals list
    let proposals = [...DEMO_PROPOSALS];
    if (status) proposals = filterByStatus(proposals, status);
    if (search) {
      const q = search.toLowerCase();
      proposals = proposals.filter((p) => p.title.toLowerCase().includes(q));
    }

    // Journals & conferences
    let journals = [...DEMO_JOURNALS];
    let conferences = [...DEMO_CONFERENCES];
    if (status) conferences = filterByStatus(conferences, status);
    conferences = filterByDateRange(conferences, dateFrom, dateTo);

    // Projects (demo + DB-created)
    let projects = [...DEMO_PROJECTS, ...dbProjects] as Array<Record<string, unknown>>;
    if (status) projects = filterByStatus(projects as Array<{ status?: string }>, status);
    if (type) projects = filterByField(projects, 'type', type);
    projects = filterByDateRange(projects as Array<{ date?: string; startDate?: string }>, dateFrom, dateTo);
    if (search) {
      const q = search.toLowerCase();
      projects = projects.filter(
        (p) =>
          (p.name as string).toLowerCase().includes(q) ||
          (p.description as string).toLowerCase().includes(q),
      );
    }

    // Compute stats
    const allPapers = [...DEMO_PAPERS, ...dbPaperAnalysis];
    const allProjects = [...DEMO_PROJECTS, ...dbProjects];
    const stats = {
      totalPapers: allPapers.length,
      publishedPapers: allPapers.filter((p) => p.status === 'published').length,
      underReviewPapers: allPapers.filter((p) => p.status === 'under-review').length,
      draftPapers: allPapers.filter((p) => p.status === 'draft').length,
      totalCitations: DEMO_PAPERS.reduce((sum, p) => sum + (p.citations || 0), 0),
      activeProjects: allProjects.filter((p) => p.status === 'active').length,
      totalBudget: '$470,000',
      avgProjectProgress: Math.round(
        DEMO_PROJECTS.reduce((sum, p) => sum + (p.progress || 0), 0) / DEMO_PROJECTS.length,
      ),
      upcomingDeadlines: conferences.filter((c) => c.status === 'submission-open').length,
    };

    const data = {
      papers,
      researchGaps,
      proposals,
      journals,
      conferences,
      projects,
      stats,
    };

    return NextResponse.json({ success: true, data });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Research Hub GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// ── POST ────────────────────────────────────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    const body = await request.json();
    const { action, ...payload } = body as { action: string; [key: string]: unknown };

    // ── Action: create_project ──────────────────────────────────────
    if (action === 'create_project') {
      const { name, description, lead, teamSize, budget, startDate, endDate, milestones } = payload as {
        name: string;
        description?: string;
        lead?: string;
        teamSize?: number;
        budget?: string;
        startDate?: string;
        endDate?: string;
        milestones?: string[];
      };

      if (!name || typeof name !== 'string' || name.trim().length === 0) {
        return NextResponse.json({ error: 'Project name is required' }, { status: 400 });
      }

      const projectData = {
        _type: 'project' as const,
        id: `proj-${Date.now()}`,
        name: name.trim(),
        description: description || '',
        status: 'planning',
        progress: 0,
        lead: lead || user.name,
        teamSize: teamSize || 1,
        budget: budget || '$0',
        spent: '$0',
        milestones: milestones || [],
        startDate: startDate || new Date().toISOString().split('T')[0],
        endDate: endDate || '',
        createdBy: user.userId,
        createdAt: new Date().toISOString(),
      };

      const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
      const key = `research_hub:project:${slug}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(projectData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(projectData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: projectData });
    }

    // ── Action: submit_paper_analysis ───────────────────────────────
    if (action === 'submit_paper_analysis') {
      const { title, abstract, authors, arxivId, domain } = payload as {
        title: string;
        abstract?: string;
        authors?: string[];
        arxivId?: string;
        domain?: string;
      };

      if (!title || typeof title !== 'string' || title.trim().length === 0) {
        return NextResponse.json({ error: 'Paper title is required' }, { status: 400 });
      }

      const analysisData = {
        _type: 'paper_analysis' as const,
        id: `pa-${Date.now()}`,
        title: title.trim(),
        abstract: abstract || '',
        authors: authors || [],
        arxivId: arxivId || null,
        domain: domain || 'General',
        status: 'pending',
        citations: 0,
        submittedBy: user.userId,
        submittedAt: new Date().toISOString(),
        analysisResult: null,
      };

      const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 60);
      const key = `research_hub:paper_analysis:${slug}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(analysisData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(analysisData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: analysisData });
    }

    // ── Action: create_research_gap ─────────────────────────────────
    if (action === 'create_research_gap') {
      const { title, description, priority, domain, relatedPapers, suggestedApproaches } = payload as {
        title: string;
        description?: string;
        priority?: string;
        domain?: string;
        relatedPapers?: string[];
        suggestedApproaches?: string[];
      };

      if (!title || typeof title !== 'string' || title.trim().length === 0) {
        return NextResponse.json({ error: 'Research gap title is required' }, { status: 400 });
      }

      const validPriorities = ['low', 'medium', 'high', 'critical'];
      const gapPriority = validPriorities.includes(priority || '') ? priority : 'medium';

      const gapData = {
        _type: 'gap' as const,
        id: `gap-${Date.now()}`,
        title: title.trim(),
        description: description || '',
        priority: gapPriority,
        domain: domain || 'General',
        relatedPapers: relatedPapers || [],
        potentialImpact: gapPriority === 'high' || gapPriority === 'critical' ? 'high' : 'medium',
        suggestedApproaches: suggestedApproaches || [],
        createdBy: user.userId,
        createdAt: new Date().toISOString(),
      };

      const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 60);
      const key = `research_hub:gap:${slug}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(gapData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(gapData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: gapData });
    }

    // ── Action: create_proposal ─────────────────────────────────────
    if (action === 'create_proposal') {
      const { title, abstract: proposalAbstract, budget, duration, team, startDate, priority: propPriority } = payload as {
        title: string;
        abstract?: string;
        budget?: string;
        duration?: string;
        team?: string[];
        startDate?: string;
        priority?: string;
      };

      if (!title || typeof title !== 'string' || title.trim().length === 0) {
        return NextResponse.json({ error: 'Proposal title is required' }, { status: 400 });
      }

      const proposalData = {
        _type: 'proposal' as const,
        id: `prop-${Date.now()}`,
        title: title.trim(),
        abstract: proposalAbstract || '',
        status: 'draft',
        budget: budget || '$0',
        duration: duration || '3 months',
        team: team || [user.name],
        startDate: startDate || new Date().toISOString().split('T')[0],
        priority: propPriority || 'P2',
        createdBy: user.userId,
        createdAt: new Date().toISOString(),
      };

      const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 60);
      const key = `research_hub:proposal:${slug}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(proposalData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(proposalData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: proposalData });
    }

    // ── Fallback: unknown action ────────────────────────────────────
    return NextResponse.json(
      { error: `Unknown action: ${action}. Supported: create_project, submit_paper_analysis, create_research_gap, create_proposal` },
      { status: 400 },
    );
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Research Hub POST error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}