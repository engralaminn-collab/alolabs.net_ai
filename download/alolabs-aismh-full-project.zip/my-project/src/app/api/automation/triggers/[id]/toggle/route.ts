import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const trigger = await db.automationTrigger.findUnique({ where: { id } })
    if (!trigger) {
      return NextResponse.json({ error: 'Trigger not found' }, { status: 404 })
    }

    const newEnabled = !trigger.enabled
    await db.automationTrigger.update({
      where: { id },
      data: { enabled: newEnabled },
    })

    return NextResponse.json({
      data: {
        id: trigger.id,
        name: trigger.name,
        enabled: newEnabled,
        previousState: trigger.enabled,
      },
    })
  } catch (error) {
    console.error('[POST /api/automation/triggers/[id]/toggle]', error)
    return NextResponse.json({ error: 'Failed to toggle trigger' }, { status: 500 })
  }
}