import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

function simulateAction(type: string, _config: Record<string, unknown>, eventData: Record<string, unknown>) {
  // Simulated execution - returns a mock result
  const now = new Date().toISOString()
  switch (type) {
    case 'agent_dispatch':
      return {
        success: true,
        message: `Dispatched agent for task`,
        agentId: `agent_${Date.now()}`,
        status: 'dispatched',
        timestamp: now,
      }
    case 'send_notification':
      return {
        success: true,
        message: `Notification sent`,
        recipient: _config.recipient || 'system',
        channel: _config.channel || 'in-app',
        timestamp: now,
      }
    case 'create_task':
      return {
        success: true,
        message: `Task created: ${_config.title || 'Untitled Task'}`,
        taskId: `task_${Date.now()}`,
        priority: _config.priority || 'medium',
        timestamp: now,
      }
    case 'update_record':
      return {
        success: true,
        message: `Record updated in ${_config.table || 'database'}`,
        recordsAffected: 1,
        timestamp: now,
      }
    case 'http_call': {
      const statusCode = (_config.mockStatus as number) || 200
      return {
        success: statusCode >= 200 && statusCode < 300,
        message: `HTTP ${_config.method || 'GET'} ${_config.url || '/api/endpoint'}`,
        statusCode,
        timestamp: now,
      }
    }
    case 'run_workflow':
      return {
        success: true,
        message: `Workflow "${_config.workflowName || 'unnamed'}" executed`,
        workflowRunId: `wr_${Date.now()}`,
        timestamp: now,
      }
    case 'send_email':
      return {
        success: true,
        message: `Email sent to ${_config.to || 'recipient@example.com'}`,
        subject: _config.subject || 'Automation Notification',
        timestamp: now,
      }
    case 'log_message':
      return {
        success: true,
        message: `Logged: ${_config.message || 'Automation log entry'}`,
        level: _config.level || 'info',
        timestamp: now,
      }
    default:
      return {
        success: false,
        message: `Unknown action type: ${type}`,
        timestamp: now,
      }
  }
}

function evaluateCondition(
  conditionType: string,
  conditionConfig: Record<string, unknown>,
  eventData: Record<string, unknown>
): boolean {
  if (conditionType === 'always') return true
  if (conditionType === 'never') return false

  // Simple field comparison
  const field = (conditionConfig.field as string) || ''
  const operator = (conditionConfig.operator as string) || 'eq'
  const value = conditionConfig.value

  // Walk eventData to find field
  const fieldValue = field.split('.').reduce((obj: unknown, key: string) => {
    if (obj && typeof obj === 'object') {
      return (obj as Record<string, unknown>)[key]
    }
    return undefined
  }, eventData)

  switch (operator) {
    case 'eq': return fieldValue === value
    case 'neq': return fieldValue !== value
    case 'gt': return Number(fieldValue) > Number(value)
    case 'gte': return Number(fieldValue) >= Number(value)
    case 'lt': return Number(fieldValue) < Number(value)
    case 'lte': return Number(fieldValue) <= Number(value)
    case 'contains': return String(fieldValue).includes(String(value))
    case 'exists': return fieldValue !== undefined && fieldValue !== null
    default: return true
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { triggerId, eventData: inputEventData } = body

    if (!triggerId) {
      return NextResponse.json({ error: 'triggerId is required' }, { status: 400 })
    }

    const trigger = await db.automationTrigger.findUnique({
      where: { id: triggerId },
      include: {
        actions: { orderBy: { sortOrder: 'asc' } },
      },
    })

    if (!trigger) {
      return NextResponse.json({ error: 'Trigger not found' }, { status: 404 })
    }

    const startTime = Date.now()
    const eventData = inputEventData || { source: 'manual', triggeredAt: new Date().toISOString() }
    const actionResults: Array<{
      actionId: string
      actionName: string
      actionType: string
      status: string
      result: unknown
      durationMs: number
      skipped: boolean
    }> = []

    let hasFailure = false
    let hasSuccess = false
    let executionError: string | null = null

    for (const action of trigger.actions) {
      const actionConfig = JSON.parse(action.config || '{}')
      const conditionConfig = JSON.parse(action.conditionConfig || '{}')

      // Evaluate condition
      const shouldRun = evaluateCondition(action.conditionType, conditionConfig, eventData)

      if (!shouldRun) {
        actionResults.push({
          actionId: action.id,
          actionName: action.name,
          actionType: action.type,
          status: 'skipped',
          result: { message: 'Condition not met, action skipped' },
          durationMs: 0,
          skipped: true,
        })
        continue
      }

      // Simulate delay
      if (action.delaySeconds && action.delaySeconds > 0) {
        // In a real system we'd wait, but we simulate instant
      }

      // Execute action (simulated)
      const actionStart = Date.now()
      let result: Record<string, unknown> = simulateAction(action.type, actionConfig, eventData)
      const actionDuration = Date.now() - actionStart

      // Simulate ~90% success rate
      const succeeded = Math.random() > 0.1

      if (!succeeded) {
        result = {
          success: false,
          message: `Simulated failure for ${action.type}`,
          error: 'Simulated execution error',
          timestamp: new Date().toISOString(),
        }
      }

      const actionStatus = result && typeof result === 'object' && 'success' in result
        ? (result as { success: boolean }).success ? 'success' : 'failed'
        : 'failed'

      if (actionStatus === 'failed') hasFailure = true
      else hasSuccess = true

      actionResults.push({
        actionId: action.id,
        actionName: action.name,
        actionType: action.type,
        status: actionStatus,
        result,
        durationMs: actionDuration + Math.floor(Math.random() * 50) + 10,
        skipped: false,
      })

      // Update action stats
      await db.automationAction.update({
        where: { id: action.id },
        data: {
          lastExecutedAt: new Date(),
          executionCount: { increment: 1 },
          successCount: actionStatus === 'success' ? { increment: 1 } : undefined,
          failCount: actionStatus === 'failed' ? { increment: 1 } : undefined,
        },
      })
    }

    const totalDuration = Date.now() - startTime
    const overallStatus = hasFailure && hasSuccess ? 'partial' : hasFailure ? 'failed' : 'success'

    if (overallStatus === 'failed') {
      executionError = actionResults
        .filter((r) => r.status === 'failed')
        .map((r) => `${r.actionName}: ${r.result && typeof r.result === 'object' && 'message' in r.result ? (r.result as { message: string }).message : 'Unknown error'}`)
        .join('; ')
    }

    // Create execution log
    await db.automationTriggerLog.create({
      data: {
        triggerId: trigger.id,
        eventData: JSON.stringify(eventData),
        actionResults: JSON.stringify(actionResults),
        status: overallStatus,
        durationMs: totalDuration,
        error: executionError,
      },
    })

    // Update trigger stats
    await db.automationTrigger.update({
      where: { id: trigger.id },
      data: {
        lastFiredAt: new Date(),
        fireCount: { increment: 1 },
      },
    })

    return NextResponse.json({
      data: {
        triggerId: trigger.id,
        triggerName: trigger.name,
        status: overallStatus,
        durationMs: totalDuration,
        actionResults,
        eventData,
      },
    })
  } catch (error) {
    console.error('[POST /api/automation/execute]', error)
    return NextResponse.json({ error: 'Failed to execute trigger' }, { status: 500 })
  }
}