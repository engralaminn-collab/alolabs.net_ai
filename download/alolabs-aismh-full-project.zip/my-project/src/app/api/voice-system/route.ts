import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

// ── Demo data ───────────────────────────────────────────────────────
const DEMO_VOICE_MODELS = [
  { id: 'vm-1', name: 'Kokoro v1', type: 'tts', provider: 'Hexgrad', status: 'active', quality: 'high', maxConcurrency: 10, currentUsage: 4, latencyP50: 120, latencyP95: 280, totalCalls: 245678, language: 'multi', parameters: '400M', gpuMemory: '4GB', version: '1.0.0', lastUpdated: '2024-12-22' },
  { id: 'vm-2', name: 'Piper English', type: 'tts', provider: 'Rhasspy', status: 'active', quality: 'medium', maxConcurrency: 20, currentUsage: 7, latencyP50: 35, latencyP95: 85, totalCalls: 892345, language: 'en-US', parameters: '70M', gpuMemory: '1GB', version: '1.2.0', lastUpdated: '2024-12-08' },
  { id: 'vm-3', name: 'Whisper Large v3', type: 'stt', provider: 'OpenAI', status: 'active', quality: 'high', maxConcurrency: 8, currentUsage: 3, latencyP50: 180, latencyP95: 420, totalCalls: 567890, language: 'multi', parameters: '1.5B', gpuMemory: '4GB', version: '3.0.0', lastUpdated: '2025-01-02' },
  { id: 'vm-4', name: 'Bark', type: 'tts', provider: 'Suno', status: 'standby', quality: 'high', maxConcurrency: 4, currentUsage: 0, latencyP50: 650, latencyP95: 1200, totalCalls: 45678, language: 'multi', parameters: '1B', gpuMemory: '6GB', version: '1.0.0', lastUpdated: '2024-11-15' },
  { id: 'vm-5', name: 'Whisper Medium', type: 'stt', provider: 'OpenAI', status: 'active', quality: 'medium', maxConcurrency: 15, currentUsage: 2, latencyP50: 90, latencyP95: 200, totalCalls: 345678, language: 'multi', parameters: '769M', gpuMemory: '3GB', version: '3.0.0', lastUpdated: '2025-01-02' },
];

const DEMO_TTS_CONFIG = {
  defaultModel: 'kokoro-v1',
  defaultVoice: 'alloy',
  defaultSpeed: 1.0,
  defaultPitch: 1.0,
  sampleRate: 24000,
  outputFormat: 'mp3',
  maxTextLength: 5000,
  streamingEnabled: true,
  ssmlSupport: true,
  emotionsEnabled: true,
  voices: [
    { id: 'alloy', name: 'Alloy', gender: 'neutral', accent: 'american', description: 'Balanced and versatile', popularity: 89 },
    { id: 'onyx', name: 'Onyx', gender: 'male', accent: 'american', description: 'Deep and authoritative', popularity: 72 },
    { id: 'nova', name: 'Nova', gender: 'female', accent: 'american', description: 'Warm and engaging', popularity: 95 },
    { id: 'echo', name: 'Echo', gender: 'male', accent: 'american', description: 'Clear and professional', popularity: 68 },
    { id: 'fable', name: 'Fable', gender: 'male', accent: 'british', description: 'Expressive storyteller', popularity: 54 },
    { id: 'shimmer', name: 'Shimmer', gender: 'female', accent: 'american', description: 'Soft and soothing', popularity: 81 },
    { id: 'aria', name: 'Aria', gender: 'female', accent: 'british', description: 'Elegant and refined', popularity: 63 },
    { id: 'coral', name: 'Coral', gender: 'female', accent: 'american', description: 'Upbeat and friendly', popularity: 77 },
  ],
};

const DEMO_STT_CONFIG = {
  defaultModel: 'whisper-large',
  language: 'auto-detect',
  maxAudioLength: 600,
  supportedFormats: ['mp3', 'wav', 'ogg', 'flac', 'webm', 'm4a'],
  diarizationEnabled: true,
  maxSpeakers: 10,
  wordLevelTimestamps: true,
  profanityFilter: false,
  customVocabulary: ['AgentOS', 'ALO Labs', 'DeepSeek', 'GLM-5', 'Qwen'],
  streamingEnabled: true,
  vadEnabled: true,
};

const DEMO_VOICE_LIBRARY = [
  { id: 'vl-1', name: 'ALO Assistant', source: 'cloned', model: 'kokoro-v1', language: 'en-US', gender: 'neutral', style: 'professional', duration: '2h 15m samples', quality: 96, status: 'active', createdAt: '2024-09-15', usageCount: 45678 },
  { id: 'vl-2', name: 'Narrator Pro', source: 'preset', model: 'bark', language: 'en-US', gender: 'male', style: 'narrative', duration: null, quality: 92, status: 'active', createdAt: '2024-08-20', usageCount: 23456 },
  { id: 'vl-3', name: 'Teacher Maria', source: 'cloned', model: 'kokoro-v1', language: 'en-US', gender: 'female', style: 'educational', duration: '1h 45m samples', quality: 94, status: 'active', createdAt: '2024-10-10', usageCount: 34567 },
  { id: 'vl-4', name: 'Business Alex', source: 'cloned', model: 'piper-en', language: 'en-US', gender: 'male', style: 'corporate', duration: '55m samples', quality: 88, status: 'active', createdAt: '2024-11-05', usageCount: 12345 },
  { id: 'vl-5', name: 'Child Storyteller', source: 'preset', model: 'bark', language: 'en-US', gender: 'female', style: 'playful', duration: null, quality: 85, status: 'inactive', createdAt: '2024-10-25', usageCount: 5678 },
  { id: 'vl-6', name: 'Mandarin Pro', source: 'cloned', model: 'kokoro-v1', language: 'zh-CN', gender: 'male', style: 'professional', duration: '3h samples', quality: 91, status: 'active', createdAt: '2024-12-01', usageCount: 18923 },
  { id: 'vl-7', name: 'Japanese Soft', source: 'preset', model: 'piper-en', language: 'ja-JP', gender: 'female', style: 'gentle', duration: null, quality: 82, status: 'active', createdAt: '2024-11-20', usageCount: 8901 },
];

const DEMO_REALTIME_STATS = {
  ttsRequestsToday: 12456,
  sttRequestsToday: 8934,
  totalAudioGenerated: '2.4 TB',
  totalAudioProcessed: '1.8 TB',
  avgTtsLatency: '142ms',
  avgSttLatency: '195ms',
  errorRate: '0.02%',
  peakConcurrency: 28,
  currentConcurrency: 16,
};

// ── Helpers ─────────────────────────────────────────────────────────
function filterByStatus<T extends { status?: string }>(items: T[], status?: string | null): T[] {
  if (!status) return items;
  return items.filter((item) => item.status === status);
}

function filterByType<T extends { type?: string }>(items: T[], type?: string | null): T[] {
  if (!type) return items;
  return items.filter((item) => item.type === type);
}

function filterByQuality<T extends { quality?: string }>(items: T[], quality?: string | null): T[] {
  if (!quality) return items;
  return items.filter((item) => item.quality === quality);
}

function filterByField<T extends Record<string, unknown>>(
  items: T[],
  field: string,
  value: string | null,
): T[] {
  if (!value || !field) return items;
  return items.filter((item) => {
    const v = item[field];
    if (Array.isArray(v)) return v.includes(value);
    if (typeof v === 'string') return v === value;
    return false;
  });
}

// ── GET ─────────────────────────────────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    await requireAuth();

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const type = searchParams.get('type');
    const quality = searchParams.get('quality');
    const language = searchParams.get('language');
    const provider = searchParams.get('provider');
    const source = searchParams.get('source');
    const search = searchParams.get('search');

    // Fetch user-created records from DB
    const dbRecords = await db.settings.findMany({
      where: { key: { startsWith: 'voice_system:' } },
      orderBy: { createdAt: 'desc' },
    });

    const dbVoiceModels: Record<string, unknown>[] = [];
    const dbTtsJobs: Record<string, unknown>[] = [];
    const dbSttJobs: Record<string, unknown>[] = [];
    const dbVoiceLibrary: Record<string, unknown>[] = [];

    for (const rec of dbRecords) {
      try {
        const parsed = JSON.parse(rec.value);
        const recType = parsed._type as string;
        if (recType === 'voice_model') dbVoiceModels.push({ ...parsed, dbId: rec.id });
        else if (recType === 'tts_job') dbTtsJobs.push({ ...parsed, dbId: rec.id });
        else if (recType === 'stt_job') dbSttJobs.push({ ...parsed, dbId: rec.id });
        else if (recType === 'voice_library') dbVoiceLibrary.push({ ...parsed, dbId: rec.id });
      } catch {
        // skip
      }
    }

    // Build voice models list
    let voiceModels = [...DEMO_VOICE_MODELS, ...dbVoiceModels] as Array<Record<string, unknown>>;
    voiceModels = filterByStatus(voiceModels as Array<{ status?: string }>, status);
    if (type) voiceModels = filterByType(voiceModels as Array<{ type?: string }>, type);
    if (quality) voiceModels = filterByQuality(voiceModels as Array<{ quality?: string }>, quality);
    if (provider) voiceModels = filterByField(voiceModels, 'provider', provider);
    if (language) voiceModels = filterByField(voiceModels, 'language', language);
    if (search) {
      const q = search.toLowerCase();
      voiceModels = voiceModels.filter(
        (v) =>
          (v.name as string).toLowerCase().includes(q) ||
          (v.provider as string).toLowerCase().includes(q),
      );
    }

    // TTS config - filter voices if language/gender requested
    let ttsConfig = { ...DEMO_TTS_CONFIG, voices: [...DEMO_TTS_CONFIG.voices] };
    if (language) {
      const langMap: Record<string, string> = {
        'en-US': 'american',
        'en-GB': 'british',
      };
      const accent = langMap[language];
      if (accent) {
        ttsConfig.voices = ttsConfig.voices.filter((v) => v.accent === accent);
      }
    }

    // STT config (mostly static)
    const sttConfig = { ...DEMO_STT_CONFIG };

    // Voice library
    let voiceLibrary = [...DEMO_VOICE_LIBRARY, ...dbVoiceLibrary] as Array<Record<string, unknown>>;
    voiceLibrary = filterByStatus(voiceLibrary as Array<{ status?: string }>, status);
    if (source) voiceLibrary = filterByField(voiceLibrary, 'source', source);
    if (language) voiceLibrary = filterByField(voiceLibrary, 'language', language);
    if (search) {
      const q = search.toLowerCase();
      voiceLibrary = voiceLibrary.filter(
        (v) =>
          (v.name as string).toLowerCase().includes(q) ||
          (v.style as string).toLowerCase().includes(q),
      );
    }

    // TTS jobs (from DB only)
    let ttsJobs = dbTtsJobs;
    if (status) ttsJobs = filterByStatus(ttsJobs as Array<{ status?: string }>, status);

    // STT jobs (from DB only)
    let sttJobs = dbSttJobs;
    if (status) sttJobs = filterByStatus(sttJobs as Array<{ status?: string }>, status);

    // Stats
    const allModels = [...DEMO_VOICE_MODELS, ...dbVoiceModels];
    const stats = {
      ...DEMO_REALTIME_STATS,
      totalModels: allModels.length,
      activeModels: allModels.filter((m) => m.status === 'active').length,
      standbyModels: allModels.filter((m) => m.status === 'standby').length,
      ttsModels: allModels.filter((m) => m.type === 'tts').length,
      sttModels: allModels.filter((m) => m.type === 'stt').length,
      totalVoiceLibrary: voiceLibrary.length,
      activeVoiceLibrary: (voiceLibrary as Array<{ status?: string }>).filter((v) => v.status === 'active').length,
    };

    const data = {
      voiceModels,
      ttsConfig,
      sttConfig,
      voiceLibrary,
      ttsJobs,
      sttJobs,
      stats,
    };

    return NextResponse.json({ success: true, data });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Voice System GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// ── POST ────────────────────────────────────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    const body = await request.json();
    const { action, ...payload } = body as { action: string; [key: string]: unknown };

    // ── Action: create_voice_model_config ───────────────────────────
    if (action === 'create_voice_model_config') {
      const {
        name,
        modelType,
        provider,
        quality,
        maxConcurrency,
        parameters,
        gpuMemory,
        version,
        language: modelLang,
      } = payload as {
        name: string;
        modelType?: string;
        provider?: string;
        quality?: string;
        maxConcurrency?: number;
        parameters?: string;
        gpuMemory?: string;
        version?: string;
        language?: string;
      };

      if (!name || typeof name !== 'string' || name.trim().length === 0) {
        return NextResponse.json({ error: 'Voice model name is required' }, { status: 400 });
      }

      const validTypes = ['tts', 'stt', 'both'];
      const validQualities = ['low', 'medium', 'high', 'ultra'];

      const modelData = {
        _type: 'voice_model' as const,
        id: `vm-${Date.now()}`,
        name: name.trim(),
        type: validTypes.includes(modelType || '') ? modelType : 'tts',
        provider: provider || 'custom',
        status: 'standby',
        quality: validQualities.includes(quality || '') ? quality : 'medium',
        maxConcurrency: maxConcurrency && maxConcurrency > 0 ? maxConcurrency : 5,
        currentUsage: 0,
        latencyP50: 0,
        latencyP95: 0,
        totalCalls: 0,
        language: modelLang || 'en-US',
        parameters: parameters || 'unknown',
        gpuMemory: gpuMemory || '0GB',
        version: version || '1.0.0',
        lastUpdated: new Date().toISOString().split('T')[0],
        createdBy: user.userId,
        createdAt: new Date().toISOString(),
      };

      const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 60);
      const key = `voice_system:model:${slug}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(modelData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(modelData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: modelData });
    }

    // ── Action: start_tts_job ───────────────────────────────────────
    if (action === 'start_tts_job') {
      const {
        text,
        voice,
        model,
        speed,
        pitch,
        outputFormat,
        language: ttsLang,
        ssml,
        emotion,
      } = payload as {
        text: string;
        voice?: string;
        model?: string;
        speed?: number;
        pitch?: number;
        outputFormat?: string;
        language?: string;
        ssml?: string;
        emotion?: string;
      };

      if (!text && !ssml) {
        return NextResponse.json({ error: 'Either text or ssml is required for TTS' }, { status: 400 });
      }

      if (text && text.length > 50000) {
        return NextResponse.json({ error: 'Text exceeds maximum length of 50000 characters' }, { status: 400 });
      }

      const validFormats = ['mp3', 'wav', 'ogg', 'flac', 'aac'];
      const validVoices = DEMO_TTS_CONFIG.voices.map((v) => v.id);
      const validatedVoice = validVoices.includes(voice || '') ? voice : DEMO_TTS_CONFIG.defaultVoice;
      const validatedFormat = validFormats.includes(outputFormat || '') ? outputFormat : 'mp3';

      if (speed !== undefined && (speed < 0.25 || speed > 4.0)) {
        return NextResponse.json({ error: 'Speed must be between 0.25 and 4.0' }, { status: 400 });
      }

      const ttsJobData = {
        _type: 'tts_job' as const,
        id: `tts-${Date.now()}`,
        text: text || '',
        ssml: ssml || null,
        voice: validatedVoice,
        model: model || DEMO_TTS_CONFIG.defaultModel,
        speed: speed ?? 1.0,
        pitch: pitch ?? 1.0,
        outputFormat: validatedFormat,
        language: ttsLang || 'en-US',
        emotion: emotion || null,
        status: 'queued',
        outputUrl: null,
        duration: null,
        charCount: (text || ssml || '').length,
        createdAt: new Date().toISOString(),
        createdBy: user.userId,
      };

      const key = `voice_system:tts:${ttsJobData.id}`;

      await db.settings.create({
        data: { key, value: JSON.stringify(ttsJobData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: ttsJobData });
    }

    // ── Action: start_stt_transcription ─────────────────────────────
    if (action === 'start_stt_transcription') {
      const {
        audioUrl,
        language: sttLang,
        model: sttModel,
        diarization,
        maxSpeakers,
        wordLevelTimestamps,
        profanityFilter,
        customVocabulary,
        vadEnabled,
      } = payload as {
        audioUrl?: string;
        language?: string;
        model?: string;
        diarization?: boolean;
        maxSpeakers?: number;
        wordLevelTimestamps?: boolean;
        profanityFilter?: boolean;
        customVocabulary?: string[];
        vadEnabled?: boolean;
      };

      // Audio URL or audio data reference is needed
      if (!audioUrl) {
        return NextResponse.json({ error: 'audioUrl is required for STT transcription' }, { status: 400 });
      }

      if (maxSpeakers !== undefined && (maxSpeakers < 1 || maxSpeakers > 20)) {
        return NextResponse.json({ error: 'maxSpeakers must be between 1 and 20' }, { status: 400 });
      }

      const validSttModels = ['whisper-large', 'whisper-medium', 'whisper-small', 'whisper-tiny'];
      const validatedModel = validSttModels.includes(sttModel || '')
        ? sttModel
        : DEMO_STT_CONFIG.defaultModel;

      const sttJobData = {
        _type: 'stt_job' as const,
        id: `stt-${Date.now()}`,
        audioUrl,
        language: sttLang || 'auto-detect',
        model: validatedModel,
        diarization: diarization ?? DEMO_STT_CONFIG.diarizationEnabled,
        maxSpeakers: maxSpeakers ?? 2,
        wordLevelTimestamps: wordLevelTimestamps ?? DEMO_STT_CONFIG.wordLevelTimestamps,
        profanityFilter: profanityFilter ?? DEMO_STT_CONFIG.profanityFilter,
        customVocabulary: customVocabulary || DEMO_STT_CONFIG.customVocabulary,
        vadEnabled: vadEnabled ?? DEMO_STT_CONFIG.vadEnabled,
        status: 'queued',
        transcription: null,
        confidence: null,
        duration: null,
        wordCount: 0,
        speakerCount: 0,
        createdAt: new Date().toISOString(),
        createdBy: user.userId,
      };

      const key = `voice_system:stt:${sttJobData.id}`;

      await db.settings.create({
        data: { key, value: JSON.stringify(sttJobData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: sttJobData });
    }

    // ── Action: add_voice_to_library ────────────────────────────────
    if (action === 'add_voice_to_library') {
      const {
        name,
        source: voiceSource,
        model,
        language: voiceLang,
        gender: voiceGender,
        style: voiceStyle,
      } = payload as {
        name: string;
        source?: string;
        model?: string;
        language?: string;
        gender?: string;
        style?: string;
      };

      if (!name || typeof name !== 'string' || name.trim().length === 0) {
        return NextResponse.json({ error: 'Voice library entry name is required' }, { status: 400 });
      }

      const validSources = ['cloned', 'preset', 'uploaded'];
      const validGenders = ['male', 'female', 'neutral'];

      const voiceData = {
        _type: 'voice_library' as const,
        id: `vl-${Date.now()}`,
        name: name.trim(),
        source: validSources.includes(voiceSource || '') ? voiceSource : 'cloned',
        model: model || 'kokoro-v1',
        language: voiceLang || 'en-US',
        gender: validGenders.includes(voiceGender || '') ? voiceGender : 'neutral',
        style: voiceStyle || 'professional',
        duration: null,
        quality: 0,
        status: 'processing',
        createdAt: new Date().toISOString().split('T')[0],
        usageCount: 0,
        createdBy: user.userId,
      };

      const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 60);
      const key = `voice_system:library:${slug}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(voiceData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(voiceData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: voiceData });
    }

    // ── Fallback ────────────────────────────────────────────────────
    return NextResponse.json(
      { error: `Unknown action: ${action}. Supported: create_voice_model_config, start_tts_job, start_stt_transcription, add_voice_to_library` },
      { status: 400 },
    );
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Voice System POST error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}