import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

// ── Multi-language labels ────────────────────────────────────────────
const LABELS: Record<string, Record<string, string>> = {
  en: {
    tutors: 'Tutors',
    courses: 'Courses',
    classrooms: 'Classrooms',
    assignments: 'Assignments',
    exams: 'Exams',
    speakingSessions: 'Speaking Sessions',
    stats: 'Statistics',
  },
  bn: {
    tutors: 'শিক্ষকমণ্ডলী',
    courses: 'কোর্সসমূহ',
    classrooms: 'শ্রেণিকক্ষ',
    assignments: 'এসাইনমেন্ট',
    exams: 'পরীক্ষা',
    speakingSessions: 'কথা বলার সেশন',
    stats: 'পরিসংখ্যান',
  },
};

// ── Demo data ───────────────────────────────────────────────────────
const DEMO_TUTORS = [
  { id: 't-1', name: 'Prof. Sarah Mitchell', subjects: ['Mathematics', 'Statistics'], level: 'PhD', rating: 4.9, totalSessions: 1247, availability: 'available', languages: ['English', 'French'], specializations: ['Calculus', 'Linear Algebra', 'Probability Theory'], hourlyRate: '$85', avatar: null, bio: 'Former MIT professor with 15 years of teaching experience. Specializes in making complex mathematical concepts accessible.' },
  { id: 't-2', name: 'Dr. Rajesh Kumar', subjects: ['Computer Science', 'AI/ML'], level: 'PhD', rating: 4.8, totalSessions: 892, availability: 'busy', languages: ['English', 'Hindi', 'Tamil'], specializations: ['Machine Learning', 'Data Structures', 'Algorithms'], hourlyRate: '$95', avatar: null, bio: 'AI researcher and educator. Published 40+ papers. Passionate about teaching ML from fundamentals to cutting-edge research.' },
  { id: 't-3', name: 'Maria Gonzalez', subjects: ['English', 'Literature'], level: 'MA', rating: 4.7, totalSessions: 2103, availability: 'available', languages: ['English', 'Spanish'], specializations: ['Academic Writing', 'IELTS Prep', 'Creative Writing'], hourlyRate: '$60', avatar: null, bio: 'Certified English language instructor with expertise in academic and creative writing preparation.' },
  { id: 't-4', name: 'Dr. Yuki Tanaka', subjects: ['Physics', 'Engineering'], level: 'PhD', rating: 4.9, totalSessions: 678, availability: 'offline', languages: ['English', 'Japanese'], specializations: ['Quantum Mechanics', 'Thermodynamics', 'Electrical Engineering'], hourlyRate: '$90', avatar: null, bio: 'Research physicist turned educator. Makes physics intuitive through real-world applications and thought experiments.' },
  { id: 't-5', name: "James O'Brien", subjects: ['Business', 'Finance'], level: 'MBA', rating: 4.6, totalSessions: 1567, availability: 'available', languages: ['English'], specializations: ['Financial Modeling', 'Strategy', 'Accounting'], hourlyRate: '$75', avatar: null, bio: 'Former investment banker turned educator. Brings real-world business experience to every session.' },
];

const DEMO_COURSES = [
  { id: 'c-1', title: 'Introduction to Machine Learning', description: 'Comprehensive introduction covering supervised, unsupervised, and reinforcement learning fundamentals.', instructor: 'Dr. Rajesh Kumar', category: 'Computer Science', level: 'intermediate', duration: '12 weeks', enrolled: 234, maxEnrollment: 300, progress: 65, status: 'active', modules: 24, completedModules: 16, rating: 4.8, lastUpdated: '2025-01-12', startDate: '2024-10-15', endDate: '2025-01-15', prerequisites: ['Linear Algebra basics', 'Python programming'] },
  { id: 'c-2', title: 'Advanced Calculus', description: 'Deep dive into multivariable calculus, vector calculus, and differential equations with applications.', instructor: 'Prof. Sarah Mitchell', category: 'Mathematics', level: 'advanced', duration: '16 weeks', enrolled: 156, maxEnrollment: 200, progress: 42, status: 'active', modules: 32, completedModules: 13, rating: 4.9, lastUpdated: '2025-01-11', startDate: '2024-11-01', endDate: '2025-02-28', prerequisites: ['Single-variable calculus', 'Linear Algebra'] },
  { id: 'c-3', title: 'Business English Mastery', description: 'Professional English for business communication, presentations, and academic writing.', instructor: 'Maria Gonzalez', category: 'Languages', level: 'intermediate', duration: '8 weeks', enrolled: 412, maxEnrollment: 500, progress: 88, status: 'active', modules: 16, completedModules: 14, rating: 4.7, lastUpdated: '2025-01-10', startDate: '2024-11-15', endDate: '2025-01-15', prerequisites: ['B1 English level'] },
  { id: 'c-4', title: 'Quantum Physics Fundamentals', description: 'Introduction to quantum mechanics, wave functions, and quantum computing basics.', instructor: 'Dr. Yuki Tanaka', category: 'Physics', level: 'advanced', duration: '14 weeks', enrolled: 89, maxEnrollment: 150, progress: 30, status: 'active', modules: 28, completedModules: 8, rating: 4.9, lastUpdated: '2025-01-09', startDate: '2024-12-01', endDate: '2025-03-15', prerequisites: ['Classical mechanics', 'Linear Algebra', 'Differential equations'] },
  { id: 'c-5', title: 'Financial Modeling with Python', description: 'Build financial models using Python, pandas, and numpy for valuation and risk analysis.', instructor: "James O'Brien", category: 'Finance', level: 'intermediate', duration: '10 weeks', enrolled: 187, maxEnrollment: 250, progress: 55, status: 'active', modules: 20, completedModules: 11, rating: 4.6, lastUpdated: '2025-01-08', startDate: '2024-11-10', endDate: '2025-01-20', prerequisites: ['Basic Python', 'Financial accounting'] },
  { id: 'c-6', title: 'IELTS Preparation Intensive', description: 'Focused preparation for IELTS Academic with practice tests and targeted skill improvement.', instructor: 'Maria Gonzalez', category: 'Languages', level: 'all-levels', duration: '6 weeks', enrolled: 320, maxEnrollment: 400, progress: 100, status: 'completed', modules: 12, completedModules: 12, rating: 4.7, lastUpdated: '2024-12-30', startDate: '2024-11-20', endDate: '2024-12-30', prerequisites: ['B1 English minimum'] },
];

const DEMO_CLASSROOMS = [
  { id: 'cl-1', name: 'Virtual Lab A', course: 'Introduction to Machine Learning', participants: 34, maxParticipants: 40, status: 'active', topic: 'Neural Networks Backpropagation', startedAt: '2025-01-12T14:00:00Z', features: ['whiteboard', 'screen-share', 'code-editor', 'recording'] },
  { id: 'cl-2', name: 'Virtual Lab B', course: 'Advanced Calculus', participants: 28, maxParticipants: 35, status: 'active', topic: "Stokes' Theorem Applications", startedAt: '2025-01-12T15:30:00Z', features: ['whiteboard', 'screen-share', 'recording'] },
  { id: 'cl-3', name: 'Study Room 1', course: null, participants: 5, maxParticipants: 10, status: 'available', topic: null, startedAt: null, features: ['whiteboard', 'screen-share'] },
  { id: 'cl-4', name: 'Study Room 2', course: null, participants: 0, maxParticipants: 10, status: 'available', topic: null, startedAt: null, features: ['whiteboard'] },
];

const DEMO_ASSIGNMENTS = [
  { id: 'a-1', title: 'Neural Network from Scratch', courseId: 'c-1', courseName: 'Introduction to Machine Learning', dueDate: '2025-01-20', submitted: 189, total: 234, avgScore: 82.5, status: 'open', type: 'coding', description: 'Implement a 3-layer neural network with backpropagation in Python (no ML frameworks).', maxScore: 100 },
  { id: 'a-2', title: 'Vector Calculus Problem Set 4', courseId: 'c-2', courseName: 'Advanced Calculus', dueDate: '2025-01-18', submitted: 120, total: 156, avgScore: 76.8, status: 'open', type: 'problem-set', description: '15 problems covering line integrals, surface integrals, and the divergence theorem.', maxScore: 100 },
  { id: 'a-3', title: 'Business Proposal Draft', courseId: 'c-3', courseName: 'Business English Mastery', dueDate: '2025-01-15', submitted: 398, total: 412, avgScore: 85.2, status: 'grading', type: 'essay', description: 'Write a 2000-word business proposal for a startup idea.', maxScore: 100 },
  { id: 'a-4', title: 'Quantum Measurement Lab', courseId: 'c-4', courseName: 'Quantum Physics Fundamentals', dueDate: '2025-01-25', submitted: 45, total: 89, avgScore: 0, status: 'open', type: 'lab', description: 'Simulate quantum measurement experiments using provided Python toolkit.', maxScore: 100 },
  { id: 'a-5', title: 'DCF Valuation Model', courseId: 'c-5', courseName: 'Financial Modeling with Python', dueDate: '2025-01-16', submitted: 178, total: 187, avgScore: 79.1, status: 'closed', type: 'coding', description: 'Build a DCF model for a publicly traded company using real financial data.', maxScore: 100 },
];

const DEMO_EXAMS = [
  { id: 'e-1', title: 'ML Midterm Exam', courseId: 'c-1', courseName: 'Introduction to Machine Learning', date: '2025-01-22', duration: 120, totalMarks: 100, status: 'upcoming', type: 'proctored', registered: 234, passRate: null, avgScore: null, sections: ['Multiple Choice (30)', 'Short Answer (30)', 'Coding Problem (40)'] },
  { id: 'e-2', title: 'Calculus Midterm', courseId: 'c-2', courseName: 'Advanced Calculus', date: '2025-01-19', duration: 90, totalMarks: 100, status: 'upcoming', type: 'proctored', registered: 156, passRate: null, avgScore: null, sections: ['Problem Solving (60)', 'Proof Writing (40)'] },
  { id: 'e-3', title: 'Business English Final', courseId: 'c-3', courseName: 'Business English Mastery', date: '2025-01-15', duration: 60, totalMarks: 100, status: 'completed', type: 'auto-graded', registered: 412, passRate: 91.2, avgScore: 78.4, sections: ['Reading Comprehension (25)', 'Writing (40)', 'Listening (35)'] },
  { id: 'e-4', title: 'IELTS Mock Test', courseId: 'c-6', courseName: 'IELTS Preparation Intensive', date: '2024-12-28', duration: 170, totalMarks: 9, status: 'completed', type: 'standardized', registered: 320, passRate: 72.8, avgScore: 6.8, sections: ['Listening (9)', 'Reading (9)', 'Writing (9)', 'Speaking (9)'] },
];

const DEMO_SPEAKING_SESSIONS = [
  { id: 'sp-1', student: 'Alex Thompson', tutor: 'Maria Gonzalez', topic: 'IELTS Speaking Part 2: Describe a Place', date: '2025-01-12', duration: 30, score: 7.0, bandBreakdown: { fluency: 7, vocabulary: 7, grammar: 7, pronunciation: 7 }, feedback: 'Good fluency and vocabulary range. Work on using more complex grammatical structures.', recordingUrl: null },
  { id: 'sp-2', student: 'Li Wei', tutor: 'Maria Gonzalez', topic: 'Business Presentation Practice', date: '2025-01-12', duration: 45, score: 8.0, bandBreakdown: { fluency: 8, vocabulary: 8, grammar: 8, pronunciation: 8 }, feedback: 'Excellent presentation structure. Very professional tone. Minor pronunciation issues with "th" sounds.', recordingUrl: null },
  { id: 'sp-3', student: 'Priya Sharma', tutor: 'Dr. Rajesh Kumar', topic: 'Technical Interview: ML Concepts', date: '2025-01-11', duration: 60, score: 7.5, bandBreakdown: { fluency: 8, vocabulary: 8, grammar: 7, pronunciation: 7 }, feedback: 'Strong technical knowledge. Could improve explaining complex concepts to non-technical audiences.', recordingUrl: null },
  { id: 'sp-4', student: 'Carlos Mendez', tutor: 'Maria Gonzalez', topic: 'Debate: AI in Education', date: '2025-01-11', duration: 30, score: 6.5, bandBreakdown: { fluency: 7, vocabulary: 6, grammar: 7, pronunciation: 6 }, feedback: 'Good arguments but needs broader vocabulary. Practice linking words and transitions.', recordingUrl: null },
];

// ── Helpers ─────────────────────────────────────────────────────────
function getLabels(lang: string) {
  return LABELS[lang] || LABELS.en;
}

function filterByStatus<T extends { status?: string }>(items: T[], status?: string | null): T[] {
  if (!status) return items;
  return items.filter((item) => item.status === status);
}

function filterByCategory<T extends { category?: string }>(items: T[], category?: string | null): T[] {
  if (!category) return items;
  return items.filter((item) => item.category === category);
}

function filterByLevel<T extends { level?: string }>(items: T[], level?: string | null): T[] {
  if (!level) return items;
  return items.filter((item) => item.level === level);
}

// ── GET ─────────────────────────────────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    await requireAuth();

    const { searchParams } = new URL(request.url);
    const lang = searchParams.get('lang') || 'en';
    const status = searchParams.get('status');
    const category = searchParams.get('category');
    const level = searchParams.get('level');
    const type = searchParams.get('type');
    const courseId = searchParams.get('courseId');
    const search = searchParams.get('search');
    const labels = getLabels(lang);

    // Fetch user-created records from DB
    const dbRecords = await db.settings.findMany({
      where: { key: { startsWith: 'education_hub:' } },
      orderBy: { createdAt: 'desc' },
    });

    const dbCourses: Record<string, unknown>[] = [];
    const dbAssignments: Record<string, unknown>[] = [];
    const dbExams: Record<string, unknown>[] = [];
    const dbSpeaking: Record<string, unknown>[] = [];

    for (const rec of dbRecords) {
      try {
        const parsed = JSON.parse(rec.value);
        const recType = parsed._type as string;
        if (recType === 'course') dbCourses.push({ ...parsed, dbId: rec.id });
        else if (recType === 'assignment') dbAssignments.push({ ...parsed, dbId: rec.id });
        else if (recType === 'exam') dbExams.push({ ...parsed, dbId: rec.id });
        else if (recType === 'speaking_session') dbSpeaking.push({ ...parsed, dbId: rec.id });
      } catch {
        // skip
      }
    }

    // Build tutors list
    let tutors = [...DEMO_TUTORS];
    if (status) {
      const availMap: Record<string, string> = { available: 'available', busy: 'busy', offline: 'offline' };
      tutors = tutors.filter((t) => t.availability === availMap[status]);
    }
    if (search) {
      const q = search.toLowerCase();
      tutors = tutors.filter(
        (t) =>
          t.name.toLowerCase().includes(q) ||
          t.subjects.some((s) => s.toLowerCase().includes(q)) ||
          t.specializations.some((s) => s.toLowerCase().includes(q)),
      );
    }

    // Build courses list
    let courses = [...DEMO_COURSES, ...dbCourses] as Array<Record<string, unknown>>;
    courses = filterByStatus(courses as Array<{ status?: string }>, status);
    if (category) courses = filterByCategory(courses as Array<{ category?: string }>, category);
    if (level) courses = filterByLevel(courses as Array<{ level?: string }>, level);
    if (search) {
      const q = search.toLowerCase();
      courses = courses.filter(
        (c) =>
          (c.title as string).toLowerCase().includes(q) ||
          (c.instructor as string).toLowerCase().includes(q),
      );
    }

    // Build classrooms list
    let classrooms = [...DEMO_CLASSROOMS];
    if (status) classrooms = filterByStatus(classrooms, status);

    // Build assignments list
    let assignments = [...DEMO_ASSIGNMENTS, ...dbAssignments] as Array<Record<string, unknown>>;
    if (status) assignments = filterByStatus(assignments as Array<{ status?: string }>, status);
    if (type) {
      assignments = assignments.filter((a) => a.type === type);
    }
    if (courseId) {
      assignments = assignments.filter((a) => a.courseId === courseId);
    }
    if (search) {
      const q = search.toLowerCase();
      assignments = assignments.filter((a) => (a.title as string).toLowerCase().includes(q));
    }

    // Build exams list
    let exams = [...DEMO_EXAMS, ...dbExams] as Array<Record<string, unknown>>;
    if (status) exams = filterByStatus(exams as Array<{ status?: string }>, status);
    if (type) {
      exams = exams.filter((e) => e.type === type);
    }
    if (courseId) {
      exams = exams.filter((e) => e.courseId === courseId);
    }
    if (search) {
      const q = search.toLowerCase();
      exams = exams.filter((e) => (e.title as string).toLowerCase().includes(q));
    }

    // Build speaking sessions
    let speakingSessions = [...DEMO_SPEAKING_SESSIONS, ...dbSpeaking] as Array<Record<string, unknown>>;
    if (search) {
      const q = search.toLowerCase();
      speakingSessions = speakingSessions.filter(
        (s) =>
          (s.student as string).toLowerCase().includes(q) ||
          (s.topic as string).toLowerCase().includes(q),
      );
    }

    // Stats
    const allCourses = [...DEMO_COURSES, ...dbCourses];
    const stats = {
      totalStudents: 1245,
      activeCourses: allCourses.filter((c) => c.status === 'active').length,
      completedCourses: allCourses.filter((c) => c.status === 'completed').length,
      totalTutors: DEMO_TUTORS.length,
      avgTutorRating: Math.round((DEMO_TUTORS.reduce((s, t) => s + t.rating, 0) / DEMO_TUTORS.length) * 100) / 100,
      totalSessionsThisMonth: 847,
      avgAssignmentScore: 80.9,
      examPassRate: 84.7,
      speakingAvgScore: 7.25,
      activeClassrooms: DEMO_CLASSROOMS.filter((c) => c.status === 'active').length,
    };

    const data = {
      _labels: labels,
      tutors,
      courses,
      classrooms,
      assignments,
      exams,
      speakingSessions,
      stats,
    };

    return NextResponse.json({ success: true, data });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Education Hub GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// ── POST ────────────────────────────────────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    const body = await request.json();
    const { action, ...payload } = body as { action: string; [key: string]: unknown };

    // ── Action: create_course ───────────────────────────────────────
    if (action === 'create_course') {
      const { title, description, instructor, category, level, duration, maxEnrollment, prerequisites, modules } = payload as {
        title: string;
        description?: string;
        instructor?: string;
        category?: string;
        level?: string;
        duration?: string;
        maxEnrollment?: number;
        prerequisites?: string[];
        modules?: number;
      };

      if (!title || typeof title !== 'string' || title.trim().length === 0) {
        return NextResponse.json({ error: 'Course title is required' }, { status: 400 });
      }

      const validLevels = ['beginner', 'intermediate', 'advanced', 'all-levels'];
      const courseLevel = validLevels.includes(level || '') ? level : 'intermediate';

      const courseData = {
        _type: 'course' as const,
        id: `c-${Date.now()}`,
        title: title.trim(),
        description: description || '',
        instructor: instructor || user.name,
        category: category || 'General',
        level: courseLevel,
        duration: duration || '8 weeks',
        enrolled: 0,
        maxEnrollment: maxEnrollment || 100,
        progress: 0,
        status: 'draft',
        modules: modules || 10,
        completedModules: 0,
        rating: 0,
        lastUpdated: new Date().toISOString(),
        startDate: new Date().toISOString().split('T')[0],
        endDate: '',
        prerequisites: prerequisites || [],
        createdBy: user.userId,
        createdAt: new Date().toISOString(),
      };

      const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 60);
      const key = `education_hub:course:${slug}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(courseData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(courseData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: courseData });
    }

    // ── Action: create_assignment ───────────────────────────────────
    if (action === 'create_assignment') {
      const { title, courseId, courseName, dueDate, type, description, maxScore } = payload as {
        title: string;
        courseId?: string;
        courseName?: string;
        dueDate?: string;
        type?: string;
        description?: string;
        maxScore?: number;
      };

      if (!title || typeof title !== 'string' || title.trim().length === 0) {
        return NextResponse.json({ error: 'Assignment title is required' }, { status: 400 });
      }

      const validTypes = ['coding', 'problem-set', 'essay', 'lab', 'project', 'quiz'];
      const assignmentType = validTypes.includes(type || '') ? type : 'essay';

      const assignmentData = {
        _type: 'assignment' as const,
        id: `a-${Date.now()}`,
        title: title.trim(),
        courseId: courseId || null,
        courseName: courseName || 'General',
        dueDate: dueDate || new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
        submitted: 0,
        total: 0,
        avgScore: 0,
        status: 'open',
        type: assignmentType,
        description: description || '',
        maxScore: maxScore || 100,
        createdBy: user.userId,
        createdAt: new Date().toISOString(),
      };

      const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 60);
      const key = `education_hub:assignment:${slug}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(assignmentData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(assignmentData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: assignmentData });
    }

    // ── Action: create_exam ─────────────────────────────────────────
    if (action === 'create_exam') {
      const { title, courseId, courseName, date, duration, totalMarks, type, sections } = payload as {
        title: string;
        courseId?: string;
        courseName?: string;
        date?: string;
        duration?: number;
        totalMarks?: number;
        type?: string;
        sections?: string[];
      };

      if (!title || typeof title !== 'string' || title.trim().length === 0) {
        return NextResponse.json({ error: 'Exam title is required' }, { status: 400 });
      }

      const validExamTypes = ['proctored', 'auto-graded', 'standardized', 'open-book', 'take-home'];
      const examType = validExamTypes.includes(type || '') ? type : 'auto-graded';

      const examData = {
        _type: 'exam' as const,
        id: `e-${Date.now()}`,
        title: title.trim(),
        courseId: courseId || null,
        courseName: courseName || 'General',
        date: date || new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
        duration: duration || 60,
        totalMarks: totalMarks || 100,
        status: 'upcoming',
        type: examType,
        registered: 0,
        passRate: null,
        avgScore: null,
        sections: sections || [],
        createdBy: user.userId,
        createdAt: new Date().toISOString(),
      };

      const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 60);
      const key = `education_hub:exam:${slug}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(examData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(examData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: examData });
    }

    // ── Action: start_speaking_session ──────────────────────────────
    if (action === 'start_speaking_session') {
      const { student, tutor, topic, duration, language } = payload as {
        student?: string;
        tutor?: string;
        topic?: string;
        duration?: number;
        language?: string;
      };

      if (!topic || typeof topic !== 'string' || topic.trim().length === 0) {
        return NextResponse.json({ error: 'Speaking session topic is required' }, { status: 400 });
      }

      const sessionData = {
        _type: 'speaking_session' as const,
        id: `sp-${Date.now()}`,
        student: student || user.name,
        tutor: tutor || 'AI Tutor',
        topic: topic.trim(),
        language: language || 'en',
        date: new Date().toISOString().split('T')[0],
        duration: duration || 30,
        score: 0,
        bandBreakdown: { fluency: 0, vocabulary: 0, grammar: 0, pronunciation: 0 },
        feedback: '',
        recordingUrl: null,
        status: 'in-progress',
        createdBy: user.userId,
        startedAt: new Date().toISOString(),
      };

      const slug = topic.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 60);
      const key = `education_hub:speaking:${slug}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(sessionData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(sessionData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: sessionData });
    }

    // ── Fallback ────────────────────────────────────────────────────
    return NextResponse.json(
      { error: `Unknown action: ${action}. Supported: create_course, create_assignment, create_exam, start_speaking_session` },
      { status: 400 },
    );
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Education Hub POST error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}