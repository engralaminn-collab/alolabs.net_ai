import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

export async function GET(request: NextRequest) {
  try {
    await requireAuth();
    const { searchParams } = new URL(request.url);
    const tab = searchParams.get('tab') || '';

    const where: Record<string, unknown> = {};
    if (tab === 'unread') {
      where.read = false;
    } else if (tab === 'alerts') {
      where.type = { in: ['security_alert', 'usage_warning', 'agent_alert'] };
    } else if (tab === 'system') {
      where.type = 'system_update';
    }

    const [data, unreadCount] = await Promise.all([
      db.notification.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: 100,
      }),
      db.notification.count({ where: { read: false } }),
    ]);

    return NextResponse.json({ data, unreadCount });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Notifications GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    await requireAuth();
    const body = await request.json();
    const { type, title, message, priority } = body;

    if (!title || !message) {
      return NextResponse.json({ error: 'title and message are required' }, { status: 400 });
    }

    const notification = await db.notification.create({
      data: {
        type: type || 'info',
        title,
        message,
        priority: priority || 'info',
      },
    });

    return NextResponse.json({ data: notification }, { status: 201 });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Notifications POST error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}