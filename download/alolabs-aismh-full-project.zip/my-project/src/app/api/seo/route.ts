// ALO Labs AIOS — SEO Management API
// Create SEO audits, list audits and keywords, update SEO data

import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { db } from '@/lib/db';
import { verifySessionToken } from '@/lib/auth';

// ─── Types ────────────────────────────────────────────────────────────────────

type AuditType = 'full' | 'technical' | 'content';

interface SeoAudit {
  id: string;
  url: string;
  type: AuditType;
  score: number; // 0-100
  status: 'pending' | 'running' | 'completed' | 'failed';
  results: {
    performance: number;
    accessibility: number;
    seo: number;
    bestPractices: number;
    issues: Array<{ category: string; severity: 'info' | 'warning' | 'error'; message: string }>;
  };
  errorMessage?: string;
  userId: string;
  createdAt: string;
  updatedAt: string;
}

interface SeoKeyword {
  id: string;
  keyword: string;
  url?: string;
  position: number;
  previousPosition: number;
  searchVolume: number;
  difficulty: number; // 0-100
  clickThroughRate: number; // 0-100 percentage
  userId: string;
  createdAt: string;
  updatedAt: string;
}

interface CreateAuditRequest {
  url: string;
  type: AuditType;
}

interface UpdateSeoRequest {
  id: string;
  data: Partial<SeoAudit> | Partial<SeoKeyword>;
  kind: 'audit' | 'keyword';
}

// ─── Storage Helpers ──────────────────────────────────────────────────────────

const AUDIT_KEY_PREFIX = 'seo:audit:';
const KEYWORD_KEY_PREFIX = 'seo:keyword:';

async function saveAudit(audit: SeoAudit): Promise<void> {
  await db.settings.upsert({
    where: { key: `${AUDIT_KEY_PREFIX}${audit.id}` },
    update: {
      value: JSON.stringify(audit),
      type: 'json',
      updatedAt: new Date(),
    },
    create: {
      key: `${AUDIT_KEY_PREFIX}${audit.id}`,
      value: JSON.stringify(audit),
      type: 'json',
    },
  });
}

async function saveKeyword(keyword: SeoKeyword): Promise<void> {
  await db.settings.upsert({
    where: { key: `${KEYWORD_KEY_PREFIX}${keyword.id}` },
    update: {
      value: JSON.stringify(keyword),
      type: 'json',
      updatedAt: new Date(),
    },
    create: {
      key: `${KEYWORD_KEY_PREFIX}${keyword.id}`,
      value: JSON.stringify(keyword),
      type: 'json',
    },
  });
}

async function listAudits(limit: number, offset: number): Promise<SeoAudit[]> {
  const allSettings = await db.settings.findMany({
    where: { key: { startsWith: AUDIT_KEY_PREFIX } },
    orderBy: { createdAt: 'desc' },
  });
  const audits: SeoAudit[] = [];
  for (const setting of allSettings) {
    try { audits.push(JSON.parse(setting.value) as SeoAudit); } catch { /* skip */ }
  }
  return audits.slice(offset, offset + limit);
}

async function listKeywords(limit: number, offset: number): Promise<SeoKeyword[]> {
  const allSettings = await db.settings.findMany({
    where: { key: { startsWith: KEYWORD_KEY_PREFIX } },
    orderBy: { createdAt: 'desc' },
  });
  const keywords: SeoKeyword[] = [];
  for (const setting of allSettings) {
    try { keywords.push(JSON.parse(setting.value) as SeoKeyword); } catch { /* skip */ }
  }
  return keywords.slice(offset, offset + limit);
}

// ─── Simulated Audit Runner ────────────────────────────────────────────────────
// In production, integrate with Lighthouse API, Screaming Frog, or similar tools.

function simulateAudit(url: string, type: AuditType): SeoAudit['results'] {
  const base = Math.floor(Math.random() * 30) + 60;
  const variance = () => Math.floor(Math.random() * 15) - 7;
  const performance = Math.max(0, Math.min(100, base + variance()));
  const accessibility = Math.max(0, Math.min(100, base + variance()));
  const seo = Math.max(0, Math.min(100, base + variance()));
  const bestPractices = Math.max(0, Math.min(100, base + variance()));
  const overallScore = Math.round((performance + accessibility + seo + bestPractices) / 4);

  const issues: Array<{ category: string; severity: 'info' | 'warning' | 'error'; message: string }> = [];

  if (type === 'full' || type === 'technical') {
    if (performance < 85) issues.push({ category: 'Performance', severity: 'warning', message: 'Consider optimizing images and caching for faster load times.' })
    if (accessibility < 90) issues.push({ category: 'Accessibility', severity: 'warning', message: 'Some images are missing alt text attributes.' })
    if (seo < 90) issues.push({ category: 'SEO', severity: 'error', message: 'Missing meta description on key pages.' })
  }
  if (type === 'full' || type === 'content') {
    if (seo < 85) issues.push({ category: 'Content', severity: 'info', message: 'Consider adding structured data markup (JSON-LD).' })
    if (bestPractices < 85) issues.push({ category: 'Best Practices', severity: 'info', message: 'Ensure all external links use rel="noopener".' })
  }
  if (issues.length === 0) {
    issues.push({ category: 'General', severity: 'info', message: 'No major issues found. Great job!' })
  }

  return { performance, accessibility, seo, bestPractices, issues, _overallScore: overallScore } as unknown as SeoAudit['results'];
}

// ─── Auth Helper ──────────────────────────────────────────────────────────────

async function authenticate(request: NextRequest): Promise<{ userId: string } | NextResponse> {
  const authHeader = await (await import('next/headers')).headers();
  const authorization = authHeader.get('authorization');
  if (!authorization?.startsWith('Bearer ')) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const token = authorization.substring(7);
  const session = await verifySessionToken(token);
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  return session;
}

// ─── GET: List Audits and Keywords ─────────────────────────────────────────────

export async function GET(request: NextRequest) {
  try {
    const authResult = await authenticate(request);
    if (authResult instanceof NextResponse) return authResult;

    const { searchParams } = new URL(request.url);
    const resource = searchParams.get('resource') || 'audits'; // 'audits' or 'keywords'
    const limit = Math.min(Math.max(parseInt(searchParams.get('limit') || '50', 10), 1), 100);
    const offset = Math.max(parseInt(searchParams.get('offset') || '0', 10), 0);

    if (resource === 'keywords') {
      const keywords = await listKeywords(limit, offset);
      return NextResponse.json({ data: keywords, total: keywords.length });
    }

    const audits = await listAudits(limit, offset);
    return NextResponse.json({ data: audits, total: audits.length });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('SEO GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// ─── POST: Create SEO Audit ────────────────────────────────────────────────────

export async function POST(request: NextRequest) {
  try {
    const authResult = await authenticate(request);
    if (authResult instanceof NextResponse) return authResult;

    const body = (await request.json()) as CreateAuditRequest;

    if (!body.url) {
      return NextResponse.json({ error: 'url is required' }, { status: 400 });
    }

    // Basic URL validation
    try {
      new URL(body.url);
    } catch {
      return NextResponse.json({ error: 'Invalid URL format' }, { status: 400 });
    }

    const validTypes: AuditType[] = ['full', 'technical', 'content'];
    if (!body.type || !validTypes.includes(body.type)) {
      return NextResponse.json({ error: 'type must be one of: full, technical, content' }, { status: 400 });
    }

    const now = new Date().toISOString();
    const auditId = crypto.randomUUID();

    // Run simulated audit
    const results = simulateAudit(body.url, body.type);
    const overallScore = (results as unknown as Record<string, number>)._overallScore ?? Math.round(
      (results.performance + results.accessibility + results.seo + results.bestPractices) / 4
    );

    const audit: SeoAudit = {
      id: auditId,
      url: body.url,
      type: body.type,
      score: overallScore,
      status: 'completed',
      results,
      userId: authResult.userId,
      createdAt: now,
      updatedAt: now,
    };

    await saveAudit(audit);

    // Auto-generate keyword entries from the audit
    const sampleKeywords = [
      { keyword: body.url.split('//')[1]?.split('/')[0] || body.url, position: Math.floor(Math.random() * 20) + 1 },
      { keyword: `${body.url.split('//')[1]?.split('/')[0] || 'site'} services`, position: Math.floor(Math.random() * 30) + 1 },
      { keyword: `${body.url.split('//')[1]?.split('/')[0] || 'site'} pricing`, position: Math.floor(Math.random() * 50) + 1 },
    ];

    for (const kw of sampleKeywords) {
      const keyword: SeoKeyword = {
        id: crypto.randomUUID(),
        keyword: kw.keyword,
        url: body.url,
        position: kw.position,
        previousPosition: kw.position + Math.floor(Math.random() * 6) - 3,
        searchVolume: Math.floor(Math.random() * 5000) + 100,
        difficulty: Math.floor(Math.random() * 60) + 20,
        clickThroughRate: Math.round((100 / (kw.position + 5)) * 100) / 100,
        userId: authResult.userId,
        createdAt: now,
        updatedAt: now,
      };
      await saveKeyword(keyword);
    }

    // Audit log
    await db.auditLog.create({
      data: {
        userId: authResult.userId,
        action: 'seo_audit_create',
        resource: `${AUDIT_KEY_PREFIX}${auditId}`,
        details: JSON.stringify({ url: body.url, type: body.type, score: overallScore }),
      },
    });

    return NextResponse.json({
      success: true,
      audit: {
        id: audit.id,
        url: audit.url,
        type: audit.type,
        score: audit.score,
        status: audit.status,
        results: audit.results,
        createdAt: audit.createdAt,
      },
    });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('SEO POST error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// ─── PUT: Update SEO Data ──────────────────────────────────────────────────────

export async function PUT(request: NextRequest) {
  try {
    const authResult = await authenticate(request);
    if (authResult instanceof NextResponse) return authResult;

    const body = (await request.json()) as UpdateSeoRequest;

    if (!body.id) {
      return NextResponse.json({ error: 'id is required' }, { status: 400 });
    }

    if (body.kind !== 'audit' && body.kind !== 'keyword') {
      return NextResponse.json({ error: 'kind must be "audit" or "keyword"' }, { status: 400 });
    }

    const prefix = body.kind === 'audit' ? AUDIT_KEY_PREFIX : KEYWORD_KEY_PREFIX;

    const existing = await db.settings.findUnique({
      where: { key: `${prefix}${body.id}` },
    });

    if (!existing) {
      return NextResponse.json({ error: `${body.kind} not found` }, { status: 404 });
    }

    const existingData = JSON.parse(existing.value);
    const updatedData = { ...existingData, ...body.data, updatedAt: new Date().toISOString() };

    await db.settings.update({
      where: { key: `${prefix}${body.id}` },
      data: {
        value: JSON.stringify(updatedData),
        updatedAt: new Date(),
      },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        userId: authResult.userId,
        action: `seo_${body.kind}_update`,
        resource: `${prefix}${body.id}`,
        details: JSON.stringify({ updatedFields: Object.keys(body.data) }),
      },
    });

    return NextResponse.json({ success: true, data: updatedData });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('SEO PUT error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}