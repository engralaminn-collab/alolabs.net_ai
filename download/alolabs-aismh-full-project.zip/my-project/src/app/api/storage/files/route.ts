/**
 * Storage Files API
 * GET:  List files with pagination and search
 * DELETE: Delete a file by key
 * Also serves file content when ?key is provided (for local storage).
 */

import { NextRequest, NextResponse } from 'next/server';
import { verifySessionToken } from '@/lib/auth';
import { getStorage, StorageFactory, LocalStorageProvider } from '@/lib/storage';
import type { StorageConfig } from '@/lib/storage';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function resolveStorage() {
  const provider = process.env.STORAGE_PROVIDER || 'local';
  const config: StorageConfig = { provider } as StorageConfig;

  if (provider === 's3' || provider === 'minio') {
    config.endpoint = process.env.S3_ENDPOINT || process.env.MINIO_HOST || '';
    config.bucket = process.env.S3_BUCKET || process.env.MINIO_BUCKET || 'agent-hub';
    config.accessKey = process.env.S3_ACCESS_KEY || process.env.MINIO_ACCESS_KEY || '';
    config.secretKey = process.env.S3_SECRET_KEY || process.env.MINIO_SECRET_KEY || '';
    config.region = process.env.S3_REGION || process.env.MINIO_REGION || 'us-east-1';
    config.cdnUrl = process.env.S3_CDN_URL || process.env.MINIO_CDN_URL || undefined;
    config.port = process.env.S3_PORT || process.env.MINIO_PORT
      ? parseInt(process.env.S3_PORT || process.env.MINIO_PORT!, 10)
      : undefined;
    config.useSSL = process.env.S3_SSL === 'true' || process.env.MINIO_SSL === 'true';
  }

  return StorageFactory.createStorage(config);
}

// ─── GET: List Files / Serve File Content ─────────────────────────────────────

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url);

    // If ?key is present, serve the file directly (local storage file serving)
    const fileKey = url.searchParams.get('key');
    if (fileKey) {
      // Verify signed URL if params present
      const expires = url.searchParams.get('expires');
      const sig = url.searchParams.get('sig');

      if (expires && sig) {
        const provider = process.env.STORAGE_PROVIDER || 'local';
        if (provider === 'local') {
          const storage = resolveStorage();
          if (storage instanceof LocalStorageProvider) {
            if (storage.verifySignedUrl && !storage.verifySignedUrl(fileKey, parseInt(expires, 10), sig)) {
              return NextResponse.json({ error: 'Invalid or expired URL' }, { status: 403 });
            }
          }
        }
      }

      const storage = resolveStorage();
      const buffer = await storage.download(fileKey);

      // Detect content type from the file or use a default
      const ext = fileKey.split('.').pop()?.toLowerCase() || '';
      const contentTypes: Record<string, string> = {
        png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg',
        gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml',
        pdf: 'application/pdf', json: 'application/json',
        mp4: 'video/mp4', webm: 'video/webm',
        mp3: 'audio/mpeg', wav: 'audio/wav',
        txt: 'text/plain', csv: 'text/csv', html: 'text/html',
      };
      const contentType = contentTypes[ext] || 'application/octet-stream';

      return new NextResponse(new Uint8Array(buffer), {
        headers: {
          'Content-Type': contentType,
          'Content-Length': String(buffer.length),
          'Cache-Control': 'private, max-age=3600',
          'Content-Disposition': `inline; filename="${fileKey.split('/').pop() || 'file'}"`,
        },
      });
    }

    // ── Auth for list endpoint ───────────────────────────────────────────
    const authHeader = request.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const session = await verifySessionToken(token);
    if (!session) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    // ── Pagination & search ──────────────────────────────────────────────
    const page = Math.max(1, parseInt(url.searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(url.searchParams.get('limit') || '20', 10)));
    const search = url.searchParams.get('search') || '';
    const prefix = url.searchParams.get('prefix') || '';

    const storage = resolveStorage();
    let files = await storage.list(prefix || undefined);

    // Apply search filter
    if (search) {
      const searchLower = search.toLowerCase();
      files = files.filter(
        (f) =>
          f.originalName.toLowerCase().includes(searchLower) ||
          f.mimeType.toLowerCase().includes(searchLower) ||
          f.id.toLowerCase().includes(searchLower)
      );
    }

    // Sort by newest first
    files.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

    // Paginate
    const total = files.length;
    const totalPages = Math.ceil(total / limit);
    const start = (page - 1) * limit;
    const paginatedFiles = files.slice(start, start + limit);

    return NextResponse.json({
      files: paginatedFiles,
      pagination: {
        page,
        limit,
        total,
        totalPages,
        hasNext: page < totalPages,
        hasPrev: page > 1,
      },
    });
  } catch (err: unknown) {
    console.error('[Storage Files] GET error:', err);
    const message = err instanceof Error ? err.message : 'Internal server error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

// ─── DELETE: Remove a File ────────────────────────────────────────────────────

export async function DELETE(request: NextRequest) {
  try {
    // ── Auth ─────────────────────────────────────────────────────────────
    const authHeader = request.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const session = await verifySessionToken(token);
    if (!session) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    // ── Parse body ───────────────────────────────────────────────────────
    const body = await request.json();
    const { key } = body;

    if (!key || typeof key !== 'string') {
      return NextResponse.json({ error: 'File key is required' }, { status: 400 });
    }

    const storage = resolveStorage();
    await storage.delete(key);

    return NextResponse.json({ success: true, deleted: key });
  } catch (err: unknown) {
    console.error('[Storage Files] DELETE error:', err);
    const message = err instanceof Error ? err.message : 'Internal server error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}