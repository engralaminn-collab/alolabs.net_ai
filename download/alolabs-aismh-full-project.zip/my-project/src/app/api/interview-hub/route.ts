import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

// ── Demo data ───────────────────────────────────────────────────────
const DEMO_INTERVIEW_TYPES = [
  { id: 'it-1', name: 'Technical Interview', description: 'In-depth technical assessment covering algorithms, system design, and coding.', duration: 60, difficulty: 'advanced', questions: 25, categories: ['algorithms', 'system-design', 'data-structures', 'coding'], usageCount: 1247 },
  { id: 'it-2', name: 'Behavioral Interview', description: 'STAR-method based behavioral assessment for soft skills evaluation.', duration: 45, difficulty: 'intermediate', questions: 15, categories: ['leadership', 'teamwork', 'conflict-resolution', 'communication'], usageCount: 892 },
  { id: 'it-3', name: 'Case Study Interview', description: 'Business case analysis and strategic thinking assessment.', duration: 50, difficulty: 'advanced', questions: 8, categories: ['strategy', 'analytics', 'problem-solving', 'business-acumen'], usageCount: 456 },
  { id: 'it-4', name: 'English Proficiency', description: 'Comprehensive English language assessment for non-native speakers.', duration: 30, difficulty: 'adaptive', questions: 40, categories: ['reading', 'writing', 'listening', 'speaking', 'grammar', 'vocabulary'], usageCount: 2341 },
  { id: 'it-5', name: 'Domain Knowledge', description: 'Subject-matter expert assessment for specialized roles.', duration: 40, difficulty: 'expert', questions: 20, categories: ['ai-ml', 'finance', 'marketing', 'engineering'], usageCount: 678 },
  { id: 'it-6', name: 'Quick Screen', description: 'Rapid initial screening for high-volume recruiting.', duration: 15, difficulty: 'beginner', questions: 10, categories: ['general', 'culture-fit', 'basic-technical'], usageCount: 3421 },
];

const DEMO_SESSIONS = [
  { id: 'is-1', candidate: 'Alice Johnson', interviewType: 'Technical Interview', type: 'it-1', status: 'completed', score: 82, duration: '58:30', date: '2025-01-12', interviewer: 'AI Proctor', difficulty: 'advanced', questionsAttempted: 25, questionsCorrect: 21, strengths: ['System Design', 'Algorithms'], weaknesses: ['Optimization', 'Edge Cases'] },
  { id: 'is-2', candidate: 'Bob Williams', interviewType: 'Behavioral Interview', type: 'it-2', status: 'in-progress', score: null, duration: '22:15', date: '2025-01-12', interviewer: 'AI Proctor', difficulty: 'intermediate', questionsAttempted: 8, questionsCorrect: null, strengths: null, weaknesses: null },
  { id: 'is-3', candidate: 'Carol Chen', interviewType: 'English Proficiency', type: 'it-4', status: 'completed', score: 91, duration: '28:45', date: '2025-01-11', interviewer: 'AI Proctor', difficulty: 'adaptive', questionsAttempted: 40, questionsCorrect: 37, strengths: ['Writing', 'Grammar', 'Vocabulary'], weaknesses: ['Speaking', 'Idiomatic Expressions'] },
  { id: 'is-4', candidate: 'David Park', interviewType: 'Case Study Interview', type: 'it-3', status: 'completed', score: 76, duration: '48:20', date: '2025-01-11', interviewer: 'AI Proctor', difficulty: 'advanced', questionsAttempted: 8, questionsCorrect: 6, strengths: ['Analytics', 'Structured Thinking'], weaknesses: ['Time Management', 'Recommendations'] },
  { id: 'is-5', candidate: 'Eva Martinez', interviewType: 'Quick Screen', type: 'it-6', status: 'completed', score: 68, duration: '14:50', date: '2025-01-10', interviewer: 'AI Proctor', difficulty: 'beginner', questionsAttempted: 10, questionsCorrect: 7, strengths: ['Communication', 'Culture Fit'], weaknesses: ['Basic Technical'] },
  { id: 'is-6', candidate: 'Frank Liu', interviewType: 'Domain Knowledge (AI/ML)', type: 'it-5', status: 'scheduled', score: null, duration: null, date: '2025-01-15', interviewer: 'AI Proctor', difficulty: 'expert', questionsAttempted: 0, questionsCorrect: null, strengths: null, weaknesses: null },
  { id: 'is-7', candidate: 'Grace Kim', interviewType: 'Technical Interview', type: 'it-1', status: 'completed', score: 95, duration: '59:10', date: '2025-01-09', interviewer: 'AI Proctor', difficulty: 'advanced', questionsAttempted: 25, questionsCorrect: 24, strengths: ['Algorithms', 'System Design', 'Coding', 'Optimization'], weaknesses: [] },
];

const DEMO_SCORING_CRITERIA = [
  { id: 'sc-1', name: 'Technical Accuracy', weight: 30, description: 'Correctness of technical answers and code solutions.', maxScore: 100, categories: ['Technical Interview', 'Domain Knowledge'] },
  { id: 'sc-2', name: 'Problem Solving', weight: 25, description: 'Ability to analyze and solve complex problems systematically.', maxScore: 100, categories: ['Technical Interview', 'Case Study Interview'] },
  { id: 'sc-3', name: 'Communication', weight: 20, description: 'Clarity, structure, and effectiveness of verbal and written communication.', maxScore: 100, categories: ['Behavioral Interview', 'Case Study Interview', 'English Proficiency'] },
  { id: 'sc-4', name: 'Domain Knowledge', weight: 15, description: 'Depth of knowledge in the relevant subject area.', maxScore: 100, categories: ['Domain Knowledge', 'Technical Interview'] },
  { id: 'sc-5', name: 'Cultural Fit', weight: 10, description: 'Alignment with company values and team dynamics.', maxScore: 100, categories: ['Behavioral Interview', 'Quick Screen'] },
  { id: 'sc-6', name: 'Language Proficiency', weight: 25, description: 'Grammar, vocabulary, fluency, and comprehension in target language.', maxScore: 100, categories: ['English Proficiency'] },
];

const DEMO_FEEDBACK_REPORTS = [
  { id: 'fb-1', sessionId: 'is-1', candidate: 'Alice Johnson', overallScore: 82, recommendation: 'hire', summary: 'Strong candidate with solid technical fundamentals. Excellent in system design but needs improvement in optimization techniques.', strengths: ['Demonstrated clear thinking in system design questions', 'Clean code with good naming conventions', 'Good communication of complex ideas'], improvements: ['Optimization patterns need strengthening', 'Should consider more edge cases in coding solutions', 'Time management could be improved'], createdAt: '2025-01-12T16:30:00Z' },
  { id: 'fb-2', sessionId: 'is-3', candidate: 'Carol Chen', overallScore: 91, recommendation: 'strong-hire', summary: 'Exceptional English proficiency. Near-native writing ability with strong grammar. Speaking needs slight improvement in natural flow.', strengths: ['Outstanding written English with varied vocabulary', 'Excellent grammatical accuracy', 'Strong reading comprehension'], improvements: ['Speaking could be more fluid and natural', 'Some idiomatic expressions need practice', 'Listening speed could improve for fast speech'], createdAt: '2025-01-11T15:45:00Z' },
  { id: 'fb-3', sessionId: 'is-7', candidate: 'Grace Kim', overallScore: 95, recommendation: 'strong-hire', summary: 'Top-performing candidate. Demonstrated mastery across all technical areas. Exceptional problem-solving ability and clean code.', strengths: ['Perfect score on algorithm questions', 'Innovative system design solutions', 'Excellent code quality and efficiency', 'Strong communication skills'], improvements: ['Could elaborate more on trade-off decisions'], createdAt: '2025-01-09T17:00:00Z' },
];

const DEMO_PRACTICE_HISTORY = [
  { id: 'ph-1', userId: 'self', date: '2025-01-12', type: 'Technical Interview', score: 78, duration: '55:20', questionsAttempted: 25, questionsCorrect: 20, improvement: '+5 from last session' },
  { id: 'ph-2', userId: 'self', date: '2025-01-10', type: 'Behavioral Interview', score: 85, duration: '42:15', questionsAttempted: 15, questionsCorrect: 13, improvement: '+3 from last session' },
  { id: 'ph-3', userId: 'self', date: '2025-01-08', type: 'English Proficiency', score: 88, duration: '29:30', questionsAttempted: 40, questionsCorrect: 35, improvement: '+2 from last session' },
  { id: 'ph-4', userId: 'self', date: '2025-01-05', type: 'Technical Interview', score: 73, duration: '58:45', questionsAttempted: 25, questionsCorrect: 18, improvement: '+8 from last session' },
  { id: 'ph-5', userId: 'self', date: '2025-01-03', type: 'Case Study Interview', score: 70, duration: '47:50', questionsAttempted: 8, questionsCorrect: 6, improvement: 'First attempt' },
];

// ── Helpers ─────────────────────────────────────────────────────────
function filterByStatus<T extends { status?: string }>(items: T[], status?: string | null): T[] {
  if (!status) return items;
  return items.filter((item) => item.status === status);
}

function filterByDifficulty<T extends { difficulty?: string }>(items: T[], difficulty?: string | null): T[] {
  if (!difficulty) return items;
  return items.filter((item) => item.difficulty === difficulty);
}

function filterByField<T extends Record<string, unknown>>(
  items: T[],
  field: string,
  value: string | null,
): T[] {
  if (!value || !field) return items;
  return items.filter((item) => {
    const v = item[field];
    if (Array.isArray(v)) return v.includes(value);
    if (typeof v === 'string') return v === value;
    return false;
  });
}

// ── GET ─────────────────────────────────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    await requireAuth();

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const type = searchParams.get('type');
    const difficulty = searchParams.get('difficulty');
    const candidate = searchParams.get('candidate');
    const category = searchParams.get('category');
    const minScore = searchParams.get('minScore');
    const maxScore = searchParams.get('maxScore');
    const search = searchParams.get('search');

    // Fetch user-created records from DB
    const dbRecords = await db.settings.findMany({
      where: { key: { startsWith: 'interview_hub:' } },
      orderBy: { createdAt: 'desc' },
    });

    const dbSessions: Record<string, unknown>[] = [];
    const dbFeedback: Record<string, unknown>[] = [];
    const dbPractice: Record<string, unknown>[] = [];

    for (const rec of dbRecords) {
      try {
        const parsed = JSON.parse(rec.value);
        const recType = parsed._type as string;
        if (recType === 'session') dbSessions.push({ ...parsed, dbId: rec.id });
        else if (recType === 'feedback') dbFeedback.push({ ...parsed, dbId: rec.id });
        else if (recType === 'practice') dbPractice.push({ ...parsed, dbId: rec.id });
      } catch {
        // skip
      }
    }

    // Build interview types list
    let interviewTypes = [...DEMO_INTERVIEW_TYPES];
    if (difficulty) interviewTypes = filterByDifficulty(interviewTypes, difficulty);
    if (category) {
      interviewTypes = interviewTypes.filter((t) => t.categories.includes(category));
    }
    if (search) {
      const q = search.toLowerCase();
      interviewTypes = interviewTypes.filter(
        (t) =>
          t.name.toLowerCase().includes(q) ||
          t.description.toLowerCase().includes(q),
      );
    }

    // Build sessions list
    let sessions = [...DEMO_SESSIONS, ...dbSessions] as Array<Record<string, unknown>>;
    sessions = filterByStatus(sessions as Array<{ status?: string }>, status);
    if (type) sessions = filterByField(sessions, 'type', type);
    if (difficulty) sessions = filterByDifficulty(sessions as Array<{ difficulty?: string }>, difficulty);
    if (candidate) {
      const q = candidate.toLowerCase();
      sessions = sessions.filter(
        (s) => (s.candidate as string).toLowerCase().includes(q),
      );
    }
    if (minScore) {
      const min = parseFloat(minScore);
      if (!isNaN(min)) sessions = sessions.filter((s) => typeof s.score === 'number' && s.score >= min);
    }
    if (maxScore) {
      const max = parseFloat(maxScore);
      if (!isNaN(max)) sessions = sessions.filter((s) => typeof s.score === 'number' && s.score <= max);
    }
    if (search) {
      const q = search.toLowerCase();
      sessions = sessions.filter(
        (s) =>
          (s.candidate as string).toLowerCase().includes(q) ||
          (s.interviewType as string).toLowerCase().includes(q),
      );
    }

    // Scoring criteria (static reference data)
    let scoringCriteria = [...DEMO_SCORING_CRITERIA];
    if (category) {
      scoringCriteria = scoringCriteria.filter((c) => c.categories.includes(category));
    }

    // Feedback reports
    let feedbackReports = [...DEMO_FEEDBACK_REPORTS, ...dbFeedback] as Array<Record<string, unknown>>;
    if (search) {
      const q = search.toLowerCase();
      feedbackReports = feedbackReports.filter(
        (f) =>
          (f.candidate as string).toLowerCase().includes(q) ||
          (f.summary as string).toLowerCase().includes(q),
      );
    }
    if (minScore) {
      const min = parseFloat(minScore);
      if (!isNaN(min)) feedbackReports = feedbackReports.filter((f) => typeof f.overallScore === 'number' && f.overallScore >= min);
    }

    // Practice history
    let practiceHistory = [...DEMO_PRACTICE_HISTORY, ...dbPractice] as Array<Record<string, unknown>>;
    if (type) practiceHistory = filterByField(practiceHistory, 'type', type);
    if (search) {
      const q = search.toLowerCase();
      practiceHistory = practiceHistory.filter(
        (p) => (p.type as string).toLowerCase().includes(q),
      );
    }

    // Stats
    const allSessions = [...DEMO_SESSIONS, ...dbSessions];
    const completedSessions = allSessions.filter((s) => s.status === 'completed');
    const scores = completedSessions.filter((s) => typeof s.score === 'number').map((s) => s.score as number);
    const stats = {
      totalInterviews: 9035,
      completedInterviews: 8421,
      inProgressInterviews: 12,
      scheduledInterviews: 602,
      avgScore: scores.length > 0 ? Math.round((scores.reduce((a, b) => a + b, 0) / scores.length) * 10) / 10 : 74.8,
      passRate: 62.3,
      avgDuration: '38 min',
      mostPopularType: 'Quick Screen',
      topScorer: 'Grace Kim',
      topScore: 95,
      practiceSessionsThisMonth: 5 + dbPractice.length,
      practiceAvgImprovement: '+4.5 per session',
    };

    const data = {
      interviewTypes,
      sessions,
      scoringCriteria,
      feedbackReports,
      practiceHistory,
      stats,
    };

    return NextResponse.json({ success: true, data });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Interview Hub GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// ── POST ────────────────────────────────────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    const body = await request.json();
    const { action, ...payload } = body as { action: string; [key: string]: unknown };

    // ── Action: create_session ──────────────────────────────────────
    if (action === 'create_session') {
      const { candidate, typeId, interviewType, scheduledDate, difficulty: sessDifficulty, note } = payload as {
        candidate?: string;
        typeId?: string;
        interviewType?: string;
        scheduledDate?: string;
        difficulty?: string;
        note?: string;
      };

      if (!typeId && !interviewType) {
        return NextResponse.json({ error: 'Either typeId or interviewType is required' }, { status: 400 });
      }

      // Look up the interview type for metadata
      const matchedType = DEMO_INTERVIEW_TYPES.find(
        (t) => t.id === typeId || t.name === interviewType,
      );

      const validDifficulties = ['beginner', 'intermediate', 'advanced', 'expert', 'adaptive'];
      const sessionDifficulty = validDifficulties.includes(sessDifficulty || '')
        ? sessDifficulty
        : matchedType?.difficulty || 'intermediate';

      const sessionData = {
        _type: 'session' as const,
        id: `is-${Date.now()}`,
        candidate: candidate || user.name,
        interviewType: matchedType?.name || interviewType || 'Custom Interview',
        type: matchedType?.id || typeId || 'custom',
        status: 'scheduled',
        score: null,
        duration: null,
        date: scheduledDate || new Date().toISOString().split('T')[0],
        interviewer: 'AI Proctor',
        difficulty: sessionDifficulty,
        questionsAttempted: 0,
        questionsCorrect: null,
        strengths: null,
        weaknesses: null,
        note: note || '',
        createdBy: user.userId,
        createdAt: new Date().toISOString(),
      };

      const key = `interview_hub:session:${sessionData.id}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(sessionData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(sessionData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: sessionData });
    }

    // ── Action: submit_feedback ─────────────────────────────────────
    if (action === 'submit_feedback') {
      const { sessionId, overallScore, recommendation, summary, strengths, improvements } = payload as {
        sessionId: string;
        overallScore?: number;
        recommendation?: string;
        summary?: string;
        strengths?: string[];
        improvements?: string[];
      };

      if (!sessionId || typeof sessionId !== 'string') {
        return NextResponse.json({ error: 'sessionId is required' }, { status: 400 });
      }

      // Verify session exists
      const demoSession = DEMO_SESSIONS.find((s) => s.id === sessionId);
      if (!demoSession) {
        const dbSession = await db.settings.findUnique({
          where: { key: `interview_hub:session:${sessionId}` },
        });
        if (!dbSession) {
          return NextResponse.json({ error: `Session ${sessionId} not found` }, { status: 404 });
        }
      }

      const validRecommendations = ['strong-hire', 'hire', 'no-hire', 'maybe'];
      const validatedRec = validRecommendations.includes(recommendation || '')
        ? recommendation
        : 'maybe';

      if (overallScore !== undefined && (overallScore < 0 || overallScore > 100)) {
        return NextResponse.json({ error: 'overallScore must be between 0 and 100' }, { status: 400 });
      }

      const candidateName = demoSession?.candidate || 'Unknown Candidate';

      const feedbackData = {
        _type: 'feedback' as const,
        id: `fb-${Date.now()}`,
        sessionId,
        candidate: candidateName,
        overallScore: overallScore ?? null,
        recommendation: validatedRec,
        summary: summary || '',
        strengths: strengths || [],
        improvements: improvements || [],
        createdAt: new Date().toISOString(),
        createdBy: user.userId,
      };

      const key = `interview_hub:feedback:${sessionId}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(feedbackData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(feedbackData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: feedbackData });
    }

    // ── Action: start_practice_session ──────────────────────────────
    if (action === 'start_practice_session') {
      const { interviewType, difficulty: pracDifficulty, questionCount } = payload as {
        interviewType?: string;
        difficulty?: string;
        questionCount?: number;
      };

      // Look up the interview type for metadata
      const matchedType = interviewType
        ? DEMO_INTERVIEW_TYPES.find(
            (t) => t.id === interviewType || t.name === interviewType,
          )
        : null;

      const validDifficulties = ['beginner', 'intermediate', 'advanced', 'expert', 'adaptive'];
      const practiceDifficulty = validDifficulties.includes(pracDifficulty || '')
        ? pracDifficulty
        : matchedType?.difficulty || 'intermediate';

      const practiceData = {
        _type: 'practice' as const,
        id: `ph-${Date.now()}`,
        userId: user.userId,
        date: new Date().toISOString().split('T')[0],
        type: matchedType?.name || interviewType || 'Technical Interview',
        score: 0,
        duration: '0:00',
        questionsAttempted: 0,
        questionsCorrect: 0,
        improvement: 'In progress',
        status: 'in-progress',
        difficulty: practiceDifficulty,
        questionCount: questionCount || matchedType?.questions || 10,
        startedAt: new Date().toISOString(),
        createdBy: user.userId,
      };

      const key = `interview_hub:practice:${practiceData.id}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(practiceData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(practiceData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: practiceData });
    }

    // ── Fallback ────────────────────────────────────────────────────
    return NextResponse.json(
      { error: `Unknown action: ${action}. Supported: create_session, submit_feedback, start_practice_session` },
      { status: 400 },
    );
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Interview Hub POST error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}