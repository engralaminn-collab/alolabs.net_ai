import { NextRequest, NextResponse } from 'next/server'
import { isRedisConnected, redisSet, redisDel } from '@/lib/redis'

// GET: List Redis keys — since there's no KEYS scan in our adapter, return connection/memory info
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const pattern = searchParams.get('pattern') || '*'

    if (!isRedisConnected()) {
      return NextResponse.json({
        connected: false,
        message: 'Redis is not connected. Connect first via /api/infra/connect.',
        keys: [],
        pattern,
        fallback: true,
        fallbackInfo: 'In-memory cache is active but KEY scanning is not supported. Set/get keys via POST/DELETE.',
      })
    }

    // Redis is connected — we can't do SCAN with our simplified adapter
    // Return status info instead
    return NextResponse.json({
      connected: true,
      message: 'Redis connected. Use POST to set keys, DELETE to remove keys.',
      keys: [],
      pattern,
      note: 'Key scanning not available via adapter. Use POST/DELETE for key operations.',
    })
  } catch (error) {
    console.error('[Infra Redis Keys GET] Error:', error)
    return NextResponse.json({ error: 'Failed to list keys' }, { status: 500 })
  }
}

// POST: Set a key
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { key, value, ttl } = body as { key: string; value: string; ttl?: number }

    if (!key || value === undefined) {
      return NextResponse.json({ error: 'key and value are required' }, { status: 400 })
    }

    if (typeof key !== 'string' || key.length === 0) {
      return NextResponse.json({ error: 'key must be a non-empty string' }, { status: 400 })
    }

    await redisSet(key, String(value), ttl)

    return NextResponse.json({
      success: true,
      key,
      ttl: ttl || null,
      message: ttl ? `Key set with ${ttl}s TTL` : 'Key set',
    })
  } catch (error) {
    console.error('[Infra Redis Keys POST] Error:', error)
    return NextResponse.json({ error: 'Failed to set key' }, { status: 500 })
  }
}

// DELETE: Delete keys
export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json()
    const { keys } = body as { keys: string[] }

    if (!keys || !Array.isArray(keys) || keys.length === 0) {
      return NextResponse.json({ error: 'keys array is required' }, { status: 400 })
    }

    const deleted = await redisDel(keys)

    return NextResponse.json({
      success: true,
      deleted,
      message: `${deleted} key(s) deleted`,
    })
  } catch (error) {
    console.error('[Infra Redis Keys DELETE] Error:', error)
    return NextResponse.json({ error: 'Failed to delete keys' }, { status: 500 })
  }
}