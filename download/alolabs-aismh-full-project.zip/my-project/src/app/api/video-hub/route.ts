import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

// ── Demo data ───────────────────────────────────────────────────────
const DEMO_PRESENTERS = [
  { id: 'pr-1', name: 'ALO Default Avatar', type: 'ai-avatar', style: 'professional', gender: 'neutral', language: 'en-US', status: 'active', thumbnailUrl: null, createdAt: '2024-08-15T08:00:00Z' },
  { id: 'pr-2', name: 'Dr. Chen Persona', type: 'ai-avatar', style: 'academic', gender: 'male', language: 'en-US', status: 'active', thumbnailUrl: null, createdAt: '2024-09-01T10:00:00Z' },
  { id: 'pr-3', name: 'Maria Presenter', type: 'ai-avatar', style: 'friendly', gender: 'female', language: 'en-US', status: 'active', thumbnailUrl: null, createdAt: '2024-09-15T12:00:00Z' },
  { id: 'pr-4', name: 'Custom Face Upload', type: 'custom', style: 'corporate', gender: 'male', language: 'en-US', status: 'active', thumbnailUrl: null, createdAt: '2024-10-20T14:00:00Z' },
  { id: 'pr-5', name: 'Anime Style', type: 'ai-avatar', style: 'casual', gender: 'female', language: 'ja-JP', status: 'inactive', thumbnailUrl: null, createdAt: '2024-11-05T09:00:00Z' },
];

const DEMO_AVATARS = [
  { id: 'av-1', name: 'Professional Suit', type: 'upper-body', resolution: '1080p', fps: 30, presenterId: 'pr-1', status: 'ready', style: 'business-casual', backgroundColor: '#f5f5f5', expressions: ['neutral', 'smile', 'thinking', 'serious'], createdAt: '2024-08-15T08:00:00Z' },
  { id: 'av-2', name: 'Academic', type: 'upper-body', resolution: '1080p', fps: 30, presenterId: 'pr-2', status: 'ready', style: 'formal', backgroundColor: '#1a1a2e', expressions: ['neutral', 'explaining', 'nodding', 'enthusiastic'], createdAt: '2024-09-01T10:00:00Z' },
  { id: 'av-3', name: 'Friendly', type: 'full-body', resolution: '1080p', fps: 30, presenterId: 'pr-3', status: 'ready', style: 'casual', backgroundColor: '#e8f4f8', expressions: ['smile', 'excited', 'calm', 'curious'], createdAt: '2024-09-15T12:00:00Z' },
  { id: 'av-4', name: 'Corporate Blue', type: 'upper-body', resolution: '4K', fps: 60, presenterId: 'pr-4', status: 'training', style: 'corporate', backgroundColor: '#0f172a', expressions: ['neutral', 'confident', 'welcoming'], createdAt: '2024-10-20T14:00:00Z', estimatedReady: '2025-01-20' },
];

const DEMO_VIDEO_PROJECTS = [
  { id: 'vp-1', title: 'ALO Labs Product Demo', presenterId: 'pr-1', avatarId: 'av-1', script: 'Welcome to ALO Labs AgentOS, the next-generation AI agent management platform...', duration: '3:45', status: 'completed', resolution: '1080p', createdAt: '2025-01-10T08:00:00Z', thumbnailUrl: null, views: 1247, language: 'en-US', subtitles: ['en', 'zh', 'ja'] },
  { id: 'vp-2', title: 'Machine Learning Course - Lecture 1', presenterId: 'pr-2', avatarId: 'av-2', script: 'Today we begin our journey into machine learning fundamentals...', duration: '45:20', status: 'completed', resolution: '1080p', createdAt: '2025-01-08T10:00:00Z', thumbnailUrl: null, views: 3892, language: 'en-US', subtitles: ['en', 'zh'] },
  { id: 'vp-3', title: 'Weekly Team Update', presenterId: 'pr-3', avatarId: 'av-3', script: 'Good morning team! Here are our highlights for this week...', duration: '5:12', status: 'rendering', resolution: '1080p', createdAt: '2025-01-12T09:00:00Z', thumbnailUrl: null, views: 0, language: 'en-US', subtitles: ['en'], renderProgress: 67 },
  { id: 'vp-4', title: 'Investor Pitch Deck', presenterId: 'pr-4', avatarId: 'av-4', script: 'Dear investors, thank you for your interest in ALO Labs...', duration: '8:30', status: 'draft', resolution: '4K', createdAt: '2025-01-11T14:00:00Z', thumbnailUrl: null, views: 0, language: 'en-US', subtitles: [] },
  { id: 'vp-5', title: 'Customer Onboarding Tutorial', presenterId: 'pr-1', avatarId: 'av-1', script: 'Welcome aboard! In this tutorial, we will walk you through...', duration: '12:15', status: 'script-review', resolution: '1080p', createdAt: '2025-01-12T11:00:00Z', thumbnailUrl: null, views: 0, language: 'en-US', subtitles: [] },
  { id: 'vp-6', title: 'Q4 Results Summary', presenterId: 'pr-2', avatarId: 'av-2', script: 'Let me walk you through our Q4 2024 financial results...', duration: '6:45', status: 'completed', resolution: '1080p', createdAt: '2025-01-05T08:00:00Z', thumbnailUrl: null, views: 856, language: 'en-US', subtitles: ['en', 'zh', 'ja', 'ko'] },
];

const DEMO_SUBTITLES = [
  { id: 'sub-1', projectId: 'vp-1', language: 'en', type: 'auto-generated', accuracy: 98.5, wordCount: 842, duration: '3:45', status: 'completed', createdAt: '2025-01-10T08:30:00Z' },
  { id: 'sub-2', projectId: 'vp-1', language: 'zh', type: 'translated', accuracy: 95.2, wordCount: 723, duration: '3:45', status: 'completed', createdAt: '2025-01-10T09:00:00Z' },
  { id: 'sub-3', projectId: 'vp-1', language: 'ja', type: 'translated', accuracy: 94.8, wordCount: 698, duration: '3:45', status: 'completed', createdAt: '2025-01-10T09:30:00Z' },
  { id: 'sub-4', projectId: 'vp-2', language: 'en', type: 'auto-generated', accuracy: 97.1, wordCount: 6823, duration: '45:20', status: 'completed', createdAt: '2025-01-08T11:00:00Z' },
  { id: 'sub-5', projectId: 'vp-2', language: 'zh', type: 'translated', accuracy: 93.5, wordCount: 5921, duration: '45:20', status: 'completed', createdAt: '2025-01-08T12:00:00Z' },
  { id: 'sub-6', projectId: 'vp-3', language: 'en', type: 'auto-generated', accuracy: 0, wordCount: 0, duration: '5:12', status: 'pending', createdAt: null },
];

const DEMO_VOICE_SYNC = {
  currentModel: 'kokoro-v1',
  availableModels: [
    { id: 'kokoro-v1', name: 'Kokoro v1', quality: 'high', latency: '150ms', languages: ['en-US', 'en-GB'], voices: 25 },
    { id: 'piper-en', name: 'Piper English', quality: 'medium', latency: '50ms', languages: ['en-US'], voices: 12 },
    { id: 'bark', name: 'Bark', quality: 'high', latency: '800ms', languages: ['en', 'zh', 'ja', 'de', 'fr'], voices: 8 },
  ],
  syncAccuracy: 96.2,
  avgProcessingTime: '45s per minute of video',
  supportedLanguages: ['en-US', 'en-GB', 'zh-CN', 'ja-JP', 'ko-KR', 'de-DE', 'fr-FR', 'es-ES'],
  recentSyncs: [
    { id: 'vs-1', projectId: 'vp-1', model: 'kokoro-v1', voice: 'alloy', syncScore: 97.8, processedAt: '2025-01-10T08:30:00Z' },
    { id: 'vs-2', projectId: 'vp-2', model: 'kokoro-v1', voice: 'onyx', syncScore: 95.4, processedAt: '2025-01-08T11:00:00Z' },
    { id: 'vs-3', projectId: 'vp-6', model: 'piper-en', voice: 'default', syncScore: 93.1, processedAt: '2025-01-05T09:00:00Z' },
  ],
};

// ── Helpers ─────────────────────────────────────────────────────────
function filterByStatus<T extends { status?: string }>(items: T[], status?: string | null): T[] {
  if (!status) return items;
  return items.filter((item) => item.status === status);
}

function filterByField<T extends Record<string, unknown>>(
  items: T[],
  field: string,
  value: string | null,
): T[] {
  if (!value || !field) return items;
  return items.filter((item) => {
    const v = item[field];
    if (Array.isArray(v)) return v.includes(value);
    if (typeof v === 'string') return v === value;
    return false;
  });
}

// ── GET ─────────────────────────────────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    await requireAuth();

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const type = searchParams.get('type');
    const language = searchParams.get('language');
    const resolution = searchParams.get('resolution');
    const style = searchParams.get('style');
    const search = searchParams.get('search');

    // Fetch user-created records from DB
    const dbRecords = await db.settings.findMany({
      where: { key: { startsWith: 'video_hub:' } },
      orderBy: { createdAt: 'desc' },
    });

    const dbProjects: Record<string, unknown>[] = [];
    const dbAvatars: Record<string, unknown>[] = [];
    const dbSubtitles: Record<string, unknown>[] = [];
    const dbPresenters: Record<string, unknown>[] = [];

    for (const rec of dbRecords) {
      try {
        const parsed = JSON.parse(rec.value);
        const recType = parsed._type as string;
        if (recType === 'video_project') dbProjects.push({ ...parsed, dbId: rec.id });
        else if (recType === 'avatar') dbAvatars.push({ ...parsed, dbId: rec.id });
        else if (recType === 'subtitle') dbSubtitles.push({ ...parsed, dbId: rec.id });
        else if (recType === 'presenter') dbPresenters.push({ ...parsed, dbId: rec.id });
      } catch {
        // skip
      }
    }

    // Build presenters list
    let presenters = [...DEMO_PRESENTERS, ...dbPresenters] as Array<Record<string, unknown>>;
    presenters = filterByStatus(presenters as Array<{ status?: string }>, status);
    if (type) presenters = filterByField(presenters, 'type', type);
    if (style) presenters = filterByField(presenters, 'style', style);
    if (language) presenters = filterByField(presenters, 'language', language);
    if (search) {
      const q = search.toLowerCase();
      presenters = presenters.filter((p) => (p.name as string).toLowerCase().includes(q));
    }

    // Build avatars list
    let avatars = [...DEMO_AVATARS, ...dbAvatars] as Array<Record<string, unknown>>;
    avatars = filterByStatus(avatars as Array<{ status?: string }>, status);
    if (type) avatars = filterByField(avatars, 'type', type);
    if (resolution) avatars = filterByField(avatars, 'resolution', resolution);
    if (search) {
      const q = search.toLowerCase();
      avatars = avatars.filter((a) => (a.name as string).toLowerCase().includes(q));
    }

    // Build video projects list
    let videoProjects = [...DEMO_VIDEO_PROJECTS, ...dbProjects] as Array<Record<string, unknown>>;
    videoProjects = filterByStatus(videoProjects as Array<{ status?: string }>, status);
    if (resolution) videoProjects = filterByField(videoProjects, 'resolution', resolution);
    if (language) videoProjects = filterByField(videoProjects, 'language', language);
    if (search) {
      const q = search.toLowerCase();
      videoProjects = videoProjects.filter(
        (v) =>
          (v.title as string).toLowerCase().includes(q) ||
          (v.script as string)?.toLowerCase().includes(q),
      );
    }

    // Build subtitles list
    let subtitles = [...DEMO_SUBTITLES, ...dbSubtitles] as Array<Record<string, unknown>>;
    if (status) subtitles = filterByStatus(subtitles as Array<{ status?: string }>, status);
    if (language) subtitles = filterByField(subtitles, 'language', language);
    if (type) subtitles = filterByField(subtitles, 'type', type);

    // Stats
    const allProjects = [...DEMO_VIDEO_PROJECTS, ...dbProjects];
    const stats = {
      totalProjects: allProjects.length,
      completedVideos: allProjects.filter((p) => p.status === 'completed').length,
      renderingVideos: allProjects.filter((p) => p.status === 'rendering').length,
      draftVideos: allProjects.filter((p) => p.status === 'draft').length,
      totalViews: DEMO_VIDEO_PROJECTS.reduce((sum, p) => sum + (p.views || 0), 0),
      totalDuration: '1h 22m',
      avgRenderTime: '8 min',
      subtitleLanguages: 4,
      totalSubtitles: subtitles.length,
    };

    const data = {
      presenters,
      avatars,
      videoProjects,
      subtitles,
      voiceSync: DEMO_VOICE_SYNC,
      stats,
    };

    return NextResponse.json({ success: true, data });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Video Hub GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// ── POST ────────────────────────────────────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    const body = await request.json();
    const { action, ...payload } = body as { action: string; [key: string]: unknown };

    // ── Action: create_video_project ────────────────────────────────
    if (action === 'create_video_project') {
      const { title, script, presenterId, avatarId, resolution, language } = payload as {
        title: string;
        script?: string;
        presenterId?: string;
        avatarId?: string;
        resolution?: string;
        language?: string;
      };

      if (!title || typeof title !== 'string' || title.trim().length === 0) {
        return NextResponse.json({ error: 'Video project title is required' }, { status: 400 });
      }

      const validResolutions = ['720p', '1080p', '2K', '4K'];
      const projectResolution = validResolutions.includes(resolution || '') ? resolution : '1080p';

      const projectData = {
        _type: 'video_project' as const,
        id: `vp-${Date.now()}`,
        title: title.trim(),
        script: script || '',
        presenterId: presenterId || 'pr-1',
        avatarId: avatarId || 'av-1',
        duration: '0:00',
        status: 'draft',
        resolution: projectResolution,
        createdAt: new Date().toISOString(),
        thumbnailUrl: null,
        views: 0,
        language: language || 'en-US',
        subtitles: [] as string[],
        createdBy: user.userId,
      };

      const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 60);
      const key = `video_hub:project:${slug}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(projectData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(projectData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: projectData });
    }

    // ── Action: generate_avatar ─────────────────────────────────────
    if (action === 'generate_avatar') {
      const { name, type: avatarType, resolution, fps, style, backgroundColor, expressions, presenterId, gender } = payload as {
        name: string;
        type?: string;
        resolution?: string;
        fps?: number;
        style?: string;
        backgroundColor?: string;
        expressions?: string[];
        presenterId?: string;
        gender?: string;
      };

      if (!name || typeof name !== 'string' || name.trim().length === 0) {
        return NextResponse.json({ error: 'Avatar name is required' }, { status: 400 });
      }

      const validTypes = ['upper-body', 'full-body', 'portrait'];
      const validResolutions = ['720p', '1080p', '2K', '4K'];
      const defaultExpressions = ['neutral', 'smile', 'thinking', 'serious'];

      const avatarData = {
        _type: 'avatar' as const,
        id: `av-${Date.now()}`,
        name: name.trim(),
        type: validTypes.includes(avatarType || '') ? avatarType : 'upper-body',
        resolution: validResolutions.includes(resolution || '') ? resolution : '1080p',
        fps: fps && fps > 0 && fps <= 120 ? fps : 30,
        presenterId: presenterId || 'pr-1',
        status: 'training',
        style: style || 'professional',
        backgroundColor: backgroundColor || '#f5f5f5',
        expressions: expressions && expressions.length > 0 ? expressions : defaultExpressions,
        gender: gender || 'neutral',
        createdAt: new Date().toISOString(),
        estimatedReady: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
        createdBy: user.userId,
      };

      const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 60);
      const key = `video_hub:avatar:${slug}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(avatarData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(avatarData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: avatarData });
    }

    // ── Action: start_subtitle_generation ───────────────────────────
    if (action === 'start_subtitle_generation') {
      const { projectId, language: subLanguage, subType } = payload as {
        projectId: string;
        language?: string;
        subType?: string;
      };

      if (!projectId || typeof projectId !== 'string') {
        return NextResponse.json({ error: 'projectId is required' }, { status: 400 });
      }

      const validSubTypes = ['auto-generated', 'translated', 'manual'];
      const subtitleType = validSubTypes.includes(subType || '') ? subType : 'auto-generated';

      // Verify project exists (check demo or DB)
      const demoProject = DEMO_VIDEO_PROJECTS.find((p) => p.id === projectId);
      if (!demoProject) {
        const dbRecord = await db.settings.findFirst({
          where: { key: { startsWith: 'video_hub:project:' } },
        });
        if (!dbRecord) {
          return NextResponse.json({ error: `Project ${projectId} not found` }, { status: 404 });
        }
      }

      const subtitleData = {
        _type: 'subtitle' as const,
        id: `sub-${Date.now()}`,
        projectId,
        language: subLanguage || 'en',
        type: subtitleType,
        accuracy: 0,
        wordCount: 0,
        duration: '0:00',
        status: 'pending',
        createdAt: null,
        requestedBy: user.userId,
        requestedAt: new Date().toISOString(),
      };

      const key = `video_hub:subtitle:${projectId}:${subLanguage || 'en'}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(subtitleData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(subtitleData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: subtitleData });
    }

    // ── Action: create_presenter ────────────────────────────────────
    if (action === 'create_presenter') {
      const { name, type: presType, style: presStyle, gender: presGender, language: presLanguage } = payload as {
        name: string;
        type?: string;
        style?: string;
        gender?: string;
        language?: string;
      };

      if (!name || typeof name !== 'string' || name.trim().length === 0) {
        return NextResponse.json({ error: 'Presenter name is required' }, { status: 400 });
      }

      const presenterData = {
        _type: 'presenter' as const,
        id: `pr-${Date.now()}`,
        name: name.trim(),
        type: presType || 'ai-avatar',
        style: presStyle || 'professional',
        gender: presGender || 'neutral',
        language: presLanguage || 'en-US',
        status: 'active',
        thumbnailUrl: null,
        createdAt: new Date().toISOString(),
        createdBy: user.userId,
      };

      const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 60);
      const key = `video_hub:presenter:${slug}`;

      await db.settings.upsert({
        where: { key },
        update: { value: JSON.stringify(presenterData), type: 'json', updatedAt: new Date() },
        create: { key, value: JSON.stringify(presenterData), type: 'json' },
      });

      return NextResponse.json({ success: true, data: presenterData });
    }

    // ── Fallback ────────────────────────────────────────────────────
    return NextResponse.json(
      { error: `Unknown action: ${action}. Supported: create_video_project, generate_avatar, start_subtitle_generation, create_presenter` },
      { status: 400 },
    );
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Video Hub POST error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}