'use client'

import { useState, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
// Slider replaced with native range input (slider component was unused elsewhere)
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  ImageIcon, Video, Music, Wand2, Download, Loader2, AlertCircle,
  Play, Pause, Volume2, Sparkles, RefreshCw, Clock, CheckCircle2,
} from 'lucide-react'
import { fetchApi } from '@/lib/api'

// ─── Types ────────────────────────────────────────────────────────────────────

type GenerationStatus = 'idle' | 'generating' | 'completed' | 'failed'

interface GeneratedImage {
  id: string
  prompt: string
  style: string
  size: string
  status: GenerationStatus
  url?: string
  error?: string
}

interface GeneratedVideo {
  id: string
  prompt: string
  duration: string
  format: string
  status: GenerationStatus
  url?: string
  error?: string
}

interface GeneratedAudio {
  id: string
  text: string
  voice: string
  speed: number
  status: GenerationStatus
  url?: string
  error?: string
}

// ─── Style Presets ─────────────────────────────────────────────────────────────

const IMAGE_STYLES = [
  { value: 'photorealistic', label: 'Photorealistic', gradient: 'from-slate-700 to-slate-900' },
  { value: 'digital-art', label: 'Digital Art', gradient: 'from-violet-600 to-fuchsia-500' },
  { value: 'watercolor', label: 'Watercolor', gradient: 'from-sky-300 to-cyan-200' },
  { value: 'oil-painting', label: 'Oil Painting', gradient: 'from-amber-700 to-orange-600' },
  { value: 'anime', label: 'Anime', gradient: 'from-pink-400 to-rose-500' },
  { value: '3d-render', label: '3D Render', gradient: 'from-emerald-500 to-teal-600' },
  { value: 'minimalist', label: 'Minimalist', gradient: 'from-gray-200 to-gray-400' },
  { value: 'fantasy', label: 'Fantasy', gradient: 'from-purple-700 to-indigo-600' },
]

const IMAGE_SIZES = [
  { value: '1024x1024', label: '1024×1024 (Square)' },
  { value: '1024x1792', label: '1024×1792 (Portrait)' },
  { value: '1792x1024', label: '1792×1024 (Landscape)' },
]

const VOICE_OPTIONS = [
  { value: 'alloy', label: 'Alloy (Neutral)' },
  { value: 'echo', label: 'Echo (Warm)' },
  { value: 'fable', label: 'Fable (British)' },
  { value: 'onyx', label: 'Onyx (Deep)' },
  { value: 'nova', label: 'Nova (Energetic)' },
  { value: 'shimmer', label: 'Shimmer (Soft)' },
]

const VIDEO_FORMATS = [
  { value: 'mp4', label: 'MP4' },
  { value: 'webm', label: 'WebM' },
  { value: 'mov', label: 'MOV' },
]

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getGradientForStyle(style: string): string {
  const found = IMAGE_STYLES.find(s => s.value === style)
  return found?.gradient || 'from-slate-400 to-slate-600'
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function MediaStudioPanel() {
  const [activeTab, setActiveTab] = useState('image')

  // Image studio state
  const [imgPrompt, setImgPrompt] = useState('')
  const [imgStyle, setImgStyle] = useState('photorealistic')
  const [imgSize, setImgSize] = useState('1024x1024')
  const [imgQuantity, setImgQuantity] = useState(1)
  const [imgGenerating, setImgGenerating] = useState(false)
  const [generatedImages, setGeneratedImages] = useState<GeneratedImage[]>([])

  // Video studio state
  const [vidPrompt, setVidPrompt] = useState('')
  const [vidDuration, setVidDuration] = useState('15')
  const [vidFormat, setVidFormat] = useState('mp4')
  const [vidGenerating, setVidGenerating] = useState(false)
  const [generatedVideos, setGeneratedVideos] = useState<GeneratedVideo[]>([])

  // Audio studio state
  const [audText, setAudText] = useState('')
  const [audVoice, setAudVoice] = useState('alloy')
  const [audSpeed, setAudSpeed] = useState(1.0)
  const [audGenerating, setAudGenerating] = useState(false)
  const [generatedAudios, setGeneratedAudios] = useState<GeneratedAudio[]>([])
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null)

  // ─── Generation Handler (shared) ────────────────────────────────────────

  const handleGenerate = useCallback(async (
    type: 'image' | 'video' | 'audio',
    setLoading: (v: boolean) => void,
    payload: Record<string, unknown>,
    setItems: (updater: (prev: any[]) => any[]) => void,
    statusMap: { status: GenerationStatus; error?: string }
  ) => {
    setLoading(true)
    const tempId = `temp-${Date.now()}`
    const newItem = { id: tempId, ...payload, status: 'generating' as const }
    setItems(prev => [newItem, ...prev])

    try {
      // API route doesn't exist yet — this will fail gracefully
      await fetchApi('/api/media/generate', {
        method: 'POST',
        body: JSON.stringify({ type, ...payload }),
      })
      // If it succeeds, update to completed
      setItems(prev => prev.map(item =>
        item.id === tempId ? { ...item, status: 'completed', url: '#' } : item
      ))
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'Generation failed'
      setItems(prev => prev.map(item =>
        item.id === tempId ? { ...item, status: 'failed', error: errorMsg } : item
      ))
    } finally {
      setLoading(false)
    }
  }, [])

  const handleImageGenerate = () => {
    if (!imgPrompt.trim()) return
    for (let i = 0; i < imgQuantity; i++) {
      handleGenerate(
        'image',
        setImgGenerating,
        { prompt: imgPrompt, style: imgStyle, size: imgSize },
        setGeneratedImages,
        { status: 'completed' },
      )
    }
  }

  const handleVideoGenerate = () => {
    if (!vidPrompt.trim()) return
    handleGenerate(
      'video',
      setVidGenerating,
      { prompt: vidPrompt, duration: vidDuration, format: vidFormat },
      setGeneratedVideos,
      { status: 'completed' },
    )
  }

  const handleAudioGenerate = () => {
    if (!audText.trim()) return
    handleGenerate(
      'audio',
      setAudGenerating,
      { text: audText, voice: audVoice, speed: audSpeed },
      setGeneratedAudios,
      { status: 'completed' },
    )
  }

  // ─── Render ───────────────────────────────────────────────────────────────

  return (
    <div className="space-y-6">
      {/* ─── Premium Header ──────────────────────────────────────────────── */}
      <div className="relative overflow-hidden rounded-xl bg-gradient-to-r from-[#003ABC] to-[#1a56db] p-5 text-white">
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="h-5 w-5" />
            <h2 className="text-xl font-bold">Media Studio</h2>
          </div>
          <p className="text-sm text-white/80">AI-powered image, video, and audio generation. Create stunning media assets with text prompts.</p>
        </div>
        <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/10 blur-2xl" />
        <div className="absolute -right-4 bottom-0 h-20 w-20 rounded-full bg-white/5 blur-xl" />
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-white border border-slate-200">
          <TabsTrigger value="image" className="text-[#1E293B] data-[state=active]:bg-[#003ABC] data-[state=active]:text-white">
            <ImageIcon className="h-4 w-4 mr-1.5" /> Image Studio
          </TabsTrigger>
          <TabsTrigger value="video" className="text-[#1E293B] data-[state=active]:bg-[#003ABC] data-[state=active]:text-white">
            <Video className="h-4 w-4 mr-1.5" /> Video Studio
          </TabsTrigger>
          <TabsTrigger value="audio" className="text-[#1E293B] data-[state=active]:bg-[#003ABC] data-[state=active]:text-white">
            <Music className="h-4 w-4 mr-1.5" /> Audio Studio
          </TabsTrigger>
        </TabsList>

        {/* ─── Image Studio ──────────────────────────────────────────────── */}
        <TabsContent value="image" className="space-y-5">
          <Card className="bg-white border-slate-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-[#1E293B]">Generate Images</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-[#1E293B] mb-1.5 block">Prompt</label>
                <Textarea
                  placeholder="Describe the image you want to create..."
                  value={imgPrompt}
                  onChange={e => setImgPrompt(e.target.value)}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-medium text-[#1E293B] mb-1.5 block">Style</label>
                  <Select value={imgStyle} onValueChange={setImgStyle}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {IMAGE_STYLES.map(s => (
                        <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium text-[#1E293B] mb-1.5 block">Size</label>
                  <Select value={imgSize} onValueChange={setImgSize}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {IMAGE_SIZES.map(s => (
                        <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium text-[#1E293B] mb-1.5 block">Quantity</label>
                  <Select value={String(imgQuantity)} onValueChange={v => setImgQuantity(Number(v))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {[1, 2, 4].map(n => (
                        <SelectItem key={n} value={String(n)}>{n} image{n > 1 ? 's' : ''}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Style Preview Chips */}
              <div>
                <p className="text-xs text-slate-500 mb-2">Style Preview</p>
                <div className="flex flex-wrap gap-2">
                  {IMAGE_STYLES.map(s => (
                    <button
                      key={s.value}
                      onClick={() => setImgStyle(s.value)}
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                        imgStyle === s.value
                          ? 'border-[#003ABC] bg-[#003ABC]/5 text-[#003ABC] ring-1 ring-[#003ABC]/20'
                          : 'border-slate-200 text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      <span className={`h-3 w-3 rounded-full bg-gradient-to-r ${s.gradient}`} />
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              <Button
                onClick={handleImageGenerate}
                disabled={imgGenerating || !imgPrompt.trim()}
                className="bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white w-full sm:w-auto"
              >
                {imgGenerating ? <Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : <Wand2 className="h-4 w-4 mr-1.5" />}
                Generate {imgQuantity > 1 ? `${imgQuantity} Images` : 'Image'}
              </Button>
            </CardContent>
          </Card>

          {/* Generated Images Grid */}
          {generatedImages.length > 0 && (
            <div>
              <h3 className="text-sm font-medium text-[#1E293B] mb-3">Generated Images</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {generatedImages.map(img => (
                  <Card key={img.id} className="bg-white border-slate-200 overflow-hidden group">
                    <div className={`aspect-square bg-gradient-to-br ${getGradientForStyle(img.style)} relative`}>
                      {img.status === 'generating' && (
                        <div className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-sm">
                          <Loader2 className="h-8 w-8 text-white animate-spin" />
                        </div>
                      )}
                      {img.status === 'failed' && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/20 backdrop-blur-sm text-white p-3">
                          <AlertCircle className="h-8 w-8 mb-1 text-red-400" />
                          <p className="text-xs text-center text-red-200 line-clamp-2">{img.error}</p>
                        </div>
                      )}
                      {img.status === 'completed' && (
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/30">
                          <Button size="sm" variant="secondary" className="bg-white text-[#1E293B] hover:bg-white/90">
                            <Download className="h-4 w-4 mr-1" /> Download
                          </Button>
                        </div>
                      )}
                    </div>
                    <CardContent className="p-2.5">
                      <p className="text-xs text-[#1E293B] truncate font-medium">{img.prompt}</p>
                      <div className="flex items-center justify-between mt-1">
                        <Badge variant="outline" className="text-[10px] px-1.5 py-0">{img.style}</Badge>
                        <span className="text-[10px] text-slate-400">{img.size}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </TabsContent>

        {/* ─── Video Studio ──────────────────────────────────────────────── */}
        <TabsContent value="video" className="space-y-5">
          <Card className="bg-white border-slate-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-[#1E293B]">Generate Video</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-[#1E293B] mb-1.5 block">Script / Prompt</label>
                <Textarea
                  placeholder="Describe the video scene or provide a script..."
                  value={vidPrompt}
                  onChange={e => setVidPrompt(e.target.value)}
                  rows={4}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-[#1E293B] mb-1.5 block">Duration (seconds)</label>
                  <Select value={vidDuration} onValueChange={setVidDuration}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 seconds</SelectItem>
                      <SelectItem value="15">15 seconds</SelectItem>
                      <SelectItem value="30">30 seconds</SelectItem>
                      <SelectItem value="60">60 seconds</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium text-[#1E293B] mb-1.5 block">Format</label>
                  <Select value={vidFormat} onValueChange={setVidFormat}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {VIDEO_FORMATS.map(f => (
                        <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button
                onClick={handleVideoGenerate}
                disabled={vidGenerating || !vidPrompt.trim()}
                className="bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white w-full sm:w-auto"
              >
                {vidGenerating ? <Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : <Wand2 className="h-4 w-4 mr-1.5" />}
                Generate Video
              </Button>
            </CardContent>
          </Card>

          {/* Generated Videos List */}
          {generatedVideos.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-[#1E293B]">Generated Videos</h3>
              {generatedVideos.map(vid => (
                <Card key={vid.id} className="bg-white border-slate-200">
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="w-20 h-14 rounded-lg bg-gradient-to-br from-slate-700 to-slate-900 flex items-center justify-center shrink-0">
                      {vid.status === 'generating' ? (
                        <Loader2 className="h-6 w-6 text-white animate-spin" />
                      ) : vid.status === 'completed' ? (
                        <Play className="h-6 w-6 text-white" />
                      ) : (
                        <AlertCircle className="h-6 w-6 text-red-400" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-[#1E293B] truncate">{vid.prompt}</p>
                      <div className="flex items-center gap-3 mt-1">
                        <Badge variant="outline" className="text-xs capitalize">
                          {vid.status === 'generating' && <Loader2 className="h-3 w-3 mr-1 animate-spin" />}
                          {vid.status}
                        </Badge>
                        <span className="text-xs text-slate-500">{vid.duration}s</span>
                        <span className="text-xs text-slate-500 uppercase">{vid.format}</span>
                      </div>
                      {vid.error && <p className="text-xs text-red-500 mt-1">{vid.error}</p>}
                    </div>
                    {vid.status === 'completed' && (
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-1" /> Download
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* ─── Audio Studio ──────────────────────────────────────────────── */}
        <TabsContent value="audio" className="space-y-5">
          <Card className="bg-white border-slate-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-[#1E293B]">Text to Speech</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-[#1E293B] mb-1.5 block">Text</label>
                <Textarea
                  placeholder="Enter the text you want to convert to speech..."
                  value={audText}
                  onChange={e => setAudText(e.target.value)}
                  rows={4}
                />
                <p className="text-xs text-slate-400 mt-1">{audText.length} characters</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-[#1E293B] mb-1.5 block">Voice</label>
                  <Select value={audVoice} onValueChange={setAudVoice}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {VOICE_OPTIONS.map(v => (
                        <SelectItem key={v.value} value={v.value}>{v.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium text-[#1E293B] mb-1.5 block">Speed: {audSpeed.toFixed(1)}x</label>
                  <input
                    type="range"
                    min={0.5}
                    max={2.0}
                    step={0.1}
                    value={audSpeed}
                    onChange={e => setAudSpeed(Number(e.target.value))}
                    className="w-full mt-3 accent-[#003ABC]"
                  />
                  <div className="flex justify-between text-xs text-slate-400 mt-1">
                    <span>0.5x</span>
                    <span>2.0x</span>
                  </div>
                </div>
              </div>

              <Button
                onClick={handleAudioGenerate}
                disabled={audGenerating || !audText.trim()}
                className="bg-[#FF6A00] hover:bg-[#FF6A00]/90 text-white w-full sm:w-auto"
              >
                {audGenerating ? <Loader2 className="h-4 w-4 animate-spin mr-1.5" /> : <Wand2 className="h-4 w-4 mr-1.5" />}
                Generate Speech
              </Button>
            </CardContent>
          </Card>

          {/* Generated Audio List & Playback */}
          {generatedAudios.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-[#1E293B]">Generated Audio</h3>
              {generatedAudios.map(aud => (
                <Card key={aud.id} className="bg-white border-slate-200">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <button
                        className="w-12 h-12 rounded-full bg-gradient-to-br from-[#003ABC] to-[#1a56db] flex items-center justify-center shrink-0 hover:shadow-lg transition-shadow disabled:opacity-50"
                        disabled={aud.status !== 'completed'}
                        onClick={() => setPlayingAudioId(playingAudioId === aud.id ? null : aud.id)}
                      >
                        {aud.status === 'generating' ? (
                          <Loader2 className="h-5 w-5 text-white animate-spin" />
                        ) : playingAudioId === aud.id ? (
                          <Pause className="h-5 w-5 text-white" />
                        ) : (
                          <Play className="h-5 w-5 text-white ml-0.5" />
                        )}
                      </button>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-[#1E293B] truncate">{aud.text}</p>
                        <div className="flex items-center gap-3 mt-1">
                          <span className="text-xs text-slate-500 capitalize">{aud.voice}</span>
                          <span className="text-xs text-slate-500">{aud.speed}x speed</span>
                          <Badge variant="outline" className="text-xs capitalize">
                            {aud.status === 'generating' && <Loader2 className="h-3 w-3 mr-1 animate-spin" />}
                            {aud.status === 'completed' && <CheckCircle2 className="h-3 w-3 mr-1 text-emerald-500" />}
                            {aud.status === 'failed' && <AlertCircle className="h-3 w-3 mr-1 text-red-500" />}
                            {aud.status}
                          </Badge>
                        </div>
                        {aud.error && <p className="text-xs text-red-500 mt-1">{aud.error}</p>}
                        {/* Playback bar (visual only) */}
                        {playingAudioId === aud.id && (
                          <div className="mt-2 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-[#003ABC] to-[#FF6A00] rounded-full animate-pulse" style={{ width: '60%' }} />
                          </div>
                        )}
                      </div>
                      {aud.status === 'completed' && (
                        <div className="flex items-center gap-2 shrink-0">
                          <Volume2 className="h-4 w-4 text-slate-400" />
                          <Button variant="outline" size="sm">
                            <Download className="h-4 w-4 mr-1" /> MP3
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}