'use client'

import { useState } from 'react'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from '@/components/ui/table'
import { Textarea } from '@/components/ui/textarea'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import {
  Zap,
  Play,
  Pause,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Plus,
  Settings,
  GitBranch,
  Webhook,
  Calendar,
  Timer,
  Activity,
  Trash2,
  Edit,
  Search,
  Loader2,
  Globe,
  Database,
  FileText,
  Bell,
  Bot,
  Cpu,
  Layers,
  Copy,
  Eye,
  TrendingUp,
  BarChart3,
  Filter,
  ArrowRight,
  CircleDot,
  ChevronDown,
  ChevronRight,
  Star,
  Mail,
  MousePointerClick,
  Sparkles,
  Shield,
  Users,
  Brain,
  Code,
  Network,
  AlertTriangle,
  Repeat,
  FileOutput,
  Workflow,
} from 'lucide-react'

/* ═══════════════════════════════════════════════════════════════
   TYPES
   ═══════════════════════════════════════════════════════════════ */

type AutomationStatus = 'active' | 'paused' | 'error'
type AutomationType = 'scheduled' | 'event' | 'conditional'
type ExecutionStatus = 'success' | 'failed' | 'running' | 'cancelled'
type NodeKind = 'trigger' | 'condition' | 'action' | 'output'

interface Automation {
  id: string
  name: string
  description: string
  status: AutomationStatus
  type: AutomationType
  runs: number
  successRate: number
  avgDuration: string
  lastRun: string
  triggerType: string
  enabled: boolean
}

interface TriggerCard {
  id: string
  name: string
  description: string
  icon: typeof Zap
  activeCount: number
  color: string
  borderColor: string
}

interface WorkflowNode {
  id: string
  kind: NodeKind
  name: string
  status: 'idle' | 'running' | 'success' | 'error'
  x: number
  y: number
}

interface WorkflowEdge {
  from: string
  to: string
}

interface ActionItem {
  id: string
  name: string
  description: string
  icon: typeof Zap
  category: string
}

interface Execution {
  id: string
  automationName: string
  triggerType: string
  status: ExecutionStatus
  duration: string
  startedAt: string
  actionsCount: number
  steps: ExecutionStep[]
}

interface ExecutionStep {
  name: string
  status: 'success' | 'failed' | 'running' | 'skipped'
  duration: string
  output?: string
}

interface Template {
  id: string
  name: string
  description: string
  category: string
  steps: number
  icon: typeof Zap
  popular: boolean
}

/* ═══════════════════════════════════════════════════════════════
   DEMO DATA
   ═══════════════════════════════════════════════════════════════ */

const DEMO_AUTOMATIONS: Automation[] = [
  { id: 'auto-1', name: 'Daily Lead Enrichment', description: 'Enriches new leads from CRM with company data via LLM analysis', status: 'active', type: 'scheduled', runs: 1247, successRate: 98.3, avgDuration: '4.2s', lastRun: '2 min ago', triggerType: 'Schedule', enabled: true },
  { id: 'auto-2', name: 'Support Ticket Router', description: 'Classifies incoming support tickets and routes to the correct team using pattern matching', status: 'active', type: 'event', runs: 3891, successRate: 95.7, avgDuration: '1.8s', lastRun: '15 sec ago', triggerType: 'Webhook', enabled: true },
  { id: 'auto-3', name: 'Sales Pipeline Alert', description: 'Sends alerts when deal values change by more than 20%', status: 'active', type: 'conditional', runs: 456, successRate: 99.1, avgDuration: '0.9s', lastRun: '1 hr ago', triggerType: 'Threshold', enabled: true },
  { id: 'auto-4', name: 'Weekly Report Generator', description: 'Generates weekly performance reports for all departments', status: 'paused', type: 'scheduled', runs: 52, successRate: 100, avgDuration: '12.5s', lastRun: '7 days ago', triggerType: 'Schedule', enabled: false },
  { id: 'auto-5', name: 'Anomaly Detection Pipeline', description: 'Monitors data streams for anomalies and triggers investigation workflows', status: 'error', type: 'event', runs: 892, successRate: 87.4, avgDuration: '3.1s', lastRun: '35 min ago', triggerType: 'Pattern', enabled: false },
  { id: 'auto-6', name: 'Customer Onboarding Sequence', description: 'Orchestrates the full customer onboarding flow with personalized emails', status: 'active', type: 'event', runs: 634, successRate: 96.8, avgDuration: '8.7s', lastRun: '4 hr ago', triggerType: 'Data Change', enabled: true },
  { id: 'auto-7', name: 'SLA Breach Monitor', description: 'Watches for SLA breaches and escalates to management', status: 'active', type: 'conditional', runs: 2103, successRate: 99.6, avgDuration: '0.5s', lastRun: '8 min ago', triggerType: 'Threshold', enabled: true },
  { id: 'auto-8', name: 'Data Sync Pipeline', description: 'Synchronizes data between internal systems every 6 hours', status: 'active', type: 'scheduled', runs: 2920, successRate: 94.2, avgDuration: '15.3s', lastRun: '3 hr ago', triggerType: 'Schedule', enabled: true },
  { id: 'auto-9', name: 'Agent Completion Handler', description: 'Processes agent task completions and updates downstream systems', status: 'active', type: 'event', runs: 5621, successRate: 97.9, avgDuration: '2.4s', lastRun: '1 min ago', triggerType: 'Agent', enabled: true },
  { id: 'auto-10', name: 'Manual Batch Processor', description: 'On-demand batch processing triggered by admin users', status: 'paused', type: 'event', runs: 28, successRate: 92.8, avgDuration: '45.2s', lastRun: '2 days ago', triggerType: 'Manual', enabled: false },
]

const DEMO_TRIGGERS: TriggerCard[] = [
  { id: 'trig-1', name: 'Webhook', description: 'Triggered by incoming HTTP requests from external services', icon: Globe, activeCount: 12, color: 'bg-blue-50', borderColor: 'border-blue-200' },
  { id: 'trig-2', name: 'Schedule (Cron)', description: 'Runs on a defined schedule using cron expressions', icon: Calendar, activeCount: 8, color: 'bg-emerald-50', borderColor: 'border-emerald-200' },
  { id: 'trig-3', name: 'Agent Completion', description: 'Fires when an AI agent finishes its task execution', icon: Bot, activeCount: 15, color: 'bg-violet-50', borderColor: 'border-violet-200' },
  { id: 'trig-4', name: 'Data Change', description: 'Detects changes in database records or data sources', icon: Database, activeCount: 6, color: 'bg-amber-50', borderColor: 'border-amber-200' },
  { id: 'trig-5', name: 'Threshold Alert', description: 'Activates when a metric crosses a defined threshold', icon: AlertTriangle, activeCount: 9, color: 'bg-red-50', borderColor: 'border-red-200' },
  { id: 'trig-6', name: 'Pattern Match', description: 'Triggers on detected patterns in data streams or logs', icon: Brain, activeCount: 4, color: 'bg-cyan-50', borderColor: 'border-cyan-200' },
  { id: 'trig-7', name: 'Manual', description: 'Manually triggered by a user action or API call', icon: MousePointerClick, activeCount: 3, color: 'bg-gray-50', borderColor: 'border-gray-200' },
]

const DEMO_WORKFLOW_NODES: WorkflowNode[] = [
  { id: 'n1', kind: 'trigger', name: 'Webhook Receiver', status: 'success', x: 0, y: 1 },
  { id: 'n2', kind: 'action', name: 'Parse Payload', status: 'success', x: 1, y: 0 },
  { id: 'n3', kind: 'condition', name: 'Is Valid?', status: 'success', x: 1, y: 2 },
  { id: 'n4', kind: 'action', name: 'LLM Classification', status: 'running', x: 2, y: 0 },
  { id: 'n5', kind: 'action', name: 'Log Error', status: 'idle', x: 2, y: 2 },
  { id: 'n6', kind: 'condition', name: 'Priority Check', status: 'idle', x: 3, y: 0 },
  { id: 'n7', kind: 'action', name: 'Route High', status: 'idle', x: 4, y: 0 },
  { id: 'n8', kind: 'action', name: 'Route Normal', status: 'idle', x: 4, y: 2 },
  { id: 'n9', kind: 'output', name: 'Send Response', status: 'idle', x: 5, y: 1 },
]

const DEMO_WORKFLOW_EDGES: WorkflowEdge[] = [
  { from: 'n1', to: 'n2' }, { from: 'n1', to: 'n3' },
  { from: 'n2', to: 'n4' }, { from: 'n3', to: 'n5' },
  { from: 'n4', to: 'n6' }, { from: 'n6', to: 'n7' },
  { from: 'n6', to: 'n8' }, { from: 'n7', to: 'n9' },
  { from: 'n8', to: 'n9' },
]

const DEMO_ACTIONS: ActionItem[] = [
  { id: 'act-1', name: 'LLM Call', description: 'Invoke a large language model for text generation, analysis, or classification', icon: Brain, category: 'AI' },
  { id: 'act-2', name: 'API Request', description: 'Make HTTP requests to external APIs with configurable headers and body', icon: Globe, category: 'Integration' },
  { id: 'act-3', name: 'DB Query', description: 'Execute database queries to read, write, or transform data', icon: Database, category: 'Data' },
  { id: 'act-4', name: 'File Operation', description: 'Read, write, move, or transform files in storage systems', icon: FileText, category: 'Data' },
  { id: 'act-5', name: 'Send Notification', description: 'Send notifications via email, Slack, SMS, or in-app channels', icon: Bell, category: 'Communication' },
  { id: 'act-6', name: 'Invoke Webhook', description: 'Trigger external webhooks with custom payloads', icon: Webhook, category: 'Integration' },
  { id: 'act-7', name: 'Run Agent', description: 'Execute an AI agent with a specific task and configuration', icon: Bot, category: 'AI' },
  { id: 'act-8', name: 'Transform Data', description: 'Apply transformations, mappings, and filters to data', icon: Layers, category: 'Data' },
  { id: 'act-9', name: 'Conditional Branch', description: 'Split workflow based on conditional logic and evaluate expressions', icon: GitBranch, category: 'Flow' },
  { id: 'act-10', name: 'Loop', description: 'Iterate over collections and execute actions for each item', icon: Repeat, category: 'Flow' },
  { id: 'act-11', name: 'Delay', description: 'Wait for a specified duration before continuing the workflow', icon: Timer, category: 'Flow' },
  { id: 'act-12', name: 'Error Handler', description: 'Catch and handle errors with retry logic or fallback actions', icon: AlertCircle, category: 'Flow' },
  { id: 'act-13', name: 'Code Execution', description: 'Run custom JavaScript or Python code within the workflow', icon: Code, category: 'Advanced' },
  { id: 'act-14', name: 'Network Scan', description: 'Perform network diagnostics, DNS lookups, or port checks', icon: Network, category: 'Advanced' },
]

const DEMO_EXECUTIONS: Execution[] = [
  { id: 'exec-1', automationName: 'Daily Lead Enrichment', triggerType: 'Schedule', status: 'success', duration: '4.2s', startedAt: '2025-01-15 09:00:00', actionsCount: 5, steps: [{ name: 'Fetch New Leads', status: 'success', duration: '1.1s', output: '23 leads fetched' }, { name: 'LLM Enrichment', status: 'success', duration: '2.4s', output: 'All enriched' }, { name: 'Update CRM', status: 'success', duration: '0.5s' }, { name: 'Send Summary', status: 'success', duration: '0.2s' }] },
  { id: 'exec-2', automationName: 'Support Ticket Router', triggerType: 'Webhook', status: 'success', duration: '1.8s', startedAt: '2025-01-15 08:59:42', actionsCount: 3, steps: [{ name: 'Parse Webhook', status: 'success', duration: '0.1s' }, { name: 'Classify Ticket', status: 'success', duration: '1.3s', output: 'Category: Billing' }, { name: 'Route to Team', status: 'success', duration: '0.4s' }] },
  { id: 'exec-3', automationName: 'Anomaly Detection Pipeline', triggerType: 'Pattern', status: 'failed', duration: '3.1s', startedAt: '2025-01-15 08:45:00', actionsCount: 4, steps: [{ name: 'Scan Data Stream', status: 'success', duration: '0.8s' }, { name: 'Detect Anomalies', status: 'success', duration: '1.2s', output: '2 anomalies found' }, { name: 'Score Severity', status: 'failed', duration: '1.1s', output: 'Timeout: LLM model unavailable' }] },
  { id: 'exec-4', automationName: 'Customer Onboarding Sequence', triggerType: 'Data Change', status: 'success', duration: '8.7s', startedAt: '2025-01-15 08:30:15', actionsCount: 6, steps: [{ name: 'Load Customer Data', status: 'success', duration: '0.3s' }, { name: 'Generate Welcome Email', status: 'success', duration: '2.1s' }, { name: 'Create User Account', status: 'success', duration: '1.5s' }, { name: 'Assign to CSM', status: 'success', duration: '0.4s' }, { name: 'Send Slack Notification', status: 'success', duration: '0.8s' }, { name: 'Log Onboarding', status: 'success', duration: '0.2s' }] },
  { id: 'exec-5', automationName: 'SLA Breach Monitor', triggerType: 'Threshold', status: 'success', duration: '0.5s', startedAt: '2025-01-15 08:52:00', actionsCount: 2, steps: [{ name: 'Check SLA Metrics', status: 'success', duration: '0.3s' }, { name: 'No Breaches Found', status: 'success', duration: '0.2s' }] },
  { id: 'exec-6', automationName: 'Sales Pipeline Alert', triggerType: 'Threshold', status: 'success', duration: '0.9s', startedAt: '2025-01-15 08:15:00', actionsCount: 3, steps: [{ name: 'Query Pipeline', status: 'success', duration: '0.4s' }, { name: 'Evaluate Changes', status: 'success', duration: '0.3s', output: '3 deals changed >20%' }, { name: 'Send Alerts', status: 'success', duration: '0.2s' }] },
  { id: 'exec-7', automationName: 'Data Sync Pipeline', triggerType: 'Schedule', status: 'success', duration: '15.3s', startedAt: '2025-01-15 06:00:00', actionsCount: 4, steps: [{ name: 'Export from Source', status: 'success', duration: '5.2s', output: '1,247 records' }, { name: 'Transform Data', status: 'success', duration: '3.8s' }, { name: 'Import to Target', status: 'success', duration: '4.9s' }, { name: 'Verify Sync', status: 'success', duration: '1.4s' }] },
  { id: 'exec-8', automationName: 'Agent Completion Handler', triggerType: 'Agent', status: 'running', duration: '2.4s', startedAt: '2025-01-15 08:58:55', actionsCount: 3, steps: [{ name: 'Receive Result', status: 'success', duration: '0.1s' }, { name: 'Process Output', status: 'running', duration: '1.8s' }, { name: 'Update Systems', status: 'skipped', duration: '-' }] },
  { id: 'exec-9', automationName: 'Daily Lead Enrichment', triggerType: 'Schedule', status: 'success', duration: '3.9s', startedAt: '2025-01-14 09:00:00', actionsCount: 5, steps: [{ name: 'Fetch New Leads', status: 'success', duration: '0.9s', output: '18 leads' }, { name: 'LLM Enrichment', status: 'success', duration: '2.1s' }, { name: 'Update CRM', status: 'success', duration: '0.6s' }, { name: 'Send Summary', status: 'success', duration: '0.3s' }] },
  { id: 'exec-10', automationName: 'Manual Batch Processor', triggerType: 'Manual', status: 'cancelled', duration: '12.8s', startedAt: '2025-01-13 14:22:00', actionsCount: 4, steps: [{ name: 'Load Batch', status: 'success', duration: '2.1s' }, { name: 'Process Items', status: 'running', duration: '10.7s' }, { name: 'Generate Report', status: 'skipped', duration: '-' }] },
  { id: 'exec-11', automationName: 'Support Ticket Router', triggerType: 'Webhook', status: 'failed', duration: '0.8s', startedAt: '2025-01-13 11:30:00', actionsCount: 3, steps: [{ name: 'Parse Webhook', status: 'success', duration: '0.1s' }, { name: 'Classify Ticket', status: 'failed', duration: '0.7s', output: 'Invalid payload format' }] },
  { id: 'exec-12', automationName: 'Weekly Report Generator', triggerType: 'Schedule', status: 'success', duration: '12.5s', startedAt: '2025-01-13 08:00:00', actionsCount: 5, steps: [{ name: 'Gather Metrics', status: 'success', duration: '3.2s' }, { name: 'Generate Charts', status: 'success', duration: '4.1s' }, { name: 'Compile Report', status: 'success', duration: '2.8s' }, { name: 'Send to Stakeholders', status: 'success', duration: '1.2s' }, { name: 'Archive Report', status: 'success', duration: '1.2s' }] },
  { id: 'exec-13', automationName: 'Anomaly Detection Pipeline', triggerType: 'Pattern', status: 'success', duration: '2.8s', startedAt: '2025-01-12 20:00:00', actionsCount: 4, steps: [{ name: 'Scan Data Stream', status: 'success', duration: '0.7s' }, { name: 'Detect Anomalies', status: 'success', duration: '1.1s', output: '0 anomalies' }, { name: 'Score Severity', status: 'skipped', duration: '-' }, { name: 'Log Results', status: 'success', duration: '0.2s' }] },
  { id: 'exec-14', automationName: 'Customer Onboarding Sequence', triggerType: 'Data Change', status: 'success', duration: '9.1s', startedAt: '2025-01-12 16:45:00', actionsCount: 6, steps: [{ name: 'Load Customer Data', status: 'success', duration: '0.4s' }, { name: 'Generate Welcome Email', status: 'success', duration: '2.3s' }, { name: 'Create User Account', status: 'success', duration: '1.8s' }, { name: 'Assign to CSM', status: 'success', duration: '0.5s' }, { name: 'Send Slack Notification', status: 'success', duration: '0.9s' }, { name: 'Log Onboarding', status: 'success', duration: '0.3s' }] },
  { id: 'exec-15', automationName: 'SLA Breach Monitor', triggerType: 'Threshold', status: 'success', duration: '1.2s', startedAt: '2025-01-12 14:00:00', actionsCount: 3, steps: [{ name: 'Check SLA Metrics', status: 'success', duration: '0.4s' }, { name: 'Breach Detected', status: 'success', duration: '0.3s', output: 'Ticket #4521 breached' }, { name: 'Escalate Alert', status: 'success', duration: '0.5s' }] },
  { id: 'exec-16', automationName: 'Data Sync Pipeline', triggerType: 'Schedule', status: 'failed', duration: '18.2s', startedAt: '2025-01-12 12:00:00', actionsCount: 4, steps: [{ name: 'Export from Source', status: 'success', duration: '6.1s', output: '2,103 records' }, { name: 'Transform Data', status: 'failed', duration: '12.1s', output: 'Memory limit exceeded' }] },
]

const DEMO_TEMPLATES: Template[] = [
  { id: 'tpl-1', name: 'Lead Scoring Pipeline', description: 'Automatically score and prioritize incoming leads using AI analysis of firmographic data', category: 'Sales', steps: 5, icon: TrendingUp, popular: true },
  { id: 'tpl-2', name: 'Email Campaign Trigger', description: 'Launch personalized email campaigns based on customer behavior and segmentation', category: 'Marketing', steps: 4, icon: Mail, popular: true },
  { id: 'tpl-3', name: 'Ticket Auto-Resolution', description: 'Attempt automatic resolution of common support tickets before routing to human agents', category: 'Support', steps: 6, icon: Shield, popular: false },
  { id: 'tpl-4', name: 'CI/CD Pipeline Monitor', description: 'Monitor build pipelines, detect failures, and auto-create incident tickets', category: 'DevOps', steps: 5, icon: Activity, popular: true },
  { id: 'tpl-5', name: 'ETL Data Pipeline', description: 'Extract, transform, and load data between systems on a scheduled basis', category: 'Data', steps: 4, icon: Database, popular: false },
  { id: 'tpl-6', name: 'Employee Onboarding', description: 'Automate new hire provisioning across all systems with notifications', category: 'HR', steps: 7, icon: Users, popular: true },
  { id: 'tpl-7', name: 'Churn Prediction Alert', description: 'Analyze customer usage patterns and alert sales team for at-risk accounts', category: 'Sales', steps: 4, icon: AlertTriangle, popular: false },
  { id: 'tpl-8', name: 'Social Media Responder', description: 'Monitor brand mentions and auto-draft responses for social media posts', category: 'Marketing', steps: 5, icon: Sparkles, popular: false },
]

const RUNS_OVER_TIME = [
  { day: 'Mon', runs: 142 },
  { day: 'Tue', runs: 198 },
  { day: 'Wed', runs: 167 },
  { day: 'Thu', runs: 223 },
  { day: 'Fri', runs: 189 },
  { day: 'Sat', runs: 87 },
  { day: 'Sun', runs: 63 },
]

const ERROR_RATES_BY_TYPE = [
  { type: 'Webhook', rate: 2.1 },
  { type: 'Schedule', rate: 1.4 },
  { type: 'Agent', rate: 3.8 },
  { type: 'Threshold', rate: 0.5 },
  { type: 'Pattern', rate: 5.2 },
  { type: 'Data Change', rate: 1.1 },
  { type: 'Manual', rate: 7.2 },
]

/* ═══════════════════════════════════════════════════════════════
   HELPER COMPONENTS
   ═══════════════════════════════════════════════════════════════ */

function StatusBadge({ status }: { status: AutomationStatus | ExecutionStatus }) {
  const map: Record<string, { label: string; className: string }> = {
    active: { label: 'Active', className: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
    paused: { label: 'Paused', className: 'bg-amber-100 text-amber-700 border-amber-200' },
    error: { label: 'Error', className: 'bg-red-100 text-red-700 border-red-200' },
    success: { label: 'Success', className: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
    failed: { label: 'Failed', className: 'bg-red-100 text-red-700 border-red-200' },
    running: { label: 'Running', className: 'bg-blue-100 text-blue-700 border-blue-200' },
    cancelled: { label: 'Cancelled', className: 'bg-gray-100 text-gray-600 border-gray-200' },
  }
  const { label, className } = map[status] ?? { label: status, className: '' }
  return <Badge variant="outline" className={`${className} text-xs font-medium`}>{label}</Badge>
}

function TypeBadge({ type }: { type: AutomationType }) {
  const map: Record<string, { label: string; className: string }> = {
    scheduled: { label: 'Scheduled', className: 'bg-sky-50 text-sky-700 border-sky-200' },
    event: { label: 'Event', className: 'bg-violet-50 text-violet-700 border-violet-200' },
    conditional: { label: 'Conditional', className: 'bg-amber-50 text-amber-700 border-amber-200' },
  }
  const { label, className } = map[type] ?? { label: type, className: '' }
  return <Badge variant="outline" className={`${className} text-xs font-medium`}>{label}</Badge>
}

function StepStatusIcon({ status }: { status: string }) {
  switch (status) {
    case 'success': return <CheckCircle className="h-4 w-4 text-emerald-500" />
    case 'failed': return <XCircle className="h-4 w-4 text-red-500" />
    case 'running': return <Loader2 className="h-4 w-4 text-blue-500 animate-spin" />
    default: return <CircleDot className="h-4 w-4 text-gray-400" />
  }
}

/* ═══════════════════════════════════════════════════════════════
   MAIN COMPONENT
   ═══════════════════════════════════════════════════════════════ */

export default function AutomationPanel() {
  /* ── State ── */
  const [automations, setAutomations] = useState<Automation[]>(DEMO_AUTOMATIONS)
  const [execFilter, setExecFilter] = useState<ExecutionStatus | 'all'>('all')
  const [expandedExec, setExpandedExec] = useState<string | null>(null)
  const [actionSearch, setActionSearch] = useState('')
  const [actionCategory, setActionCategory] = useState('All')
  const [templateCategory, setTemplateCategory] = useState('All')
  const [selectedNode, setSelectedNode] = useState<WorkflowNode | null>(null)
  const [createDialogOpen, setCreateDialogOpen] = useState(false)
  const [triggerDialogOpen, setTriggerDialogOpen] = useState(false)
  const [newAutoName, setNewAutoName] = useState('')
  const [newAutoType, setNewAutoType] = useState<AutomationType>('event')
  const [newAutoDesc, setNewAutoDesc] = useState('')
  const [newAutoTrigger, setNewAutoTrigger] = useState('webhook')

  /* ── Handlers ── */
  const toggleAutomation = (id: string) => {
    setAutomations(prev => prev.map(a => {
      if (a.id !== id) return a
      const enabled = !a.enabled
      return { ...a, enabled, status: enabled ? 'active' as AutomationStatus : 'paused' as AutomationStatus }
    }))
  }

  const deleteAutomation = (id: string) => {
    setAutomations(prev => prev.filter(a => a.id !== id))
  }

  const createAutomation = () => {
    if (!newAutoName.trim()) return
    const newAuto: Automation = {
      id: `auto-${Date.now()}`,
      name: newAutoName,
      description: newAutoDesc,
      status: 'active',
      type: newAutoType,
      runs: 0,
      successRate: 100,
      avgDuration: '0.0s',
      lastRun: 'Never',
      triggerType: newAutoTrigger,
      enabled: true,
    }
    setAutomations(prev => [newAuto, ...prev])
    setNewAutoName('')
    setNewAutoDesc('')
    setCreateDialogOpen(false)
  }

  const handleUseTemplate = (tpl: Template) => {
    const newAuto: Automation = {
      id: `auto-${Date.now()}`,
      name: tpl.name,
      description: tpl.description,
      status: 'paused',
      type: 'event',
      runs: 0,
      successRate: 100,
      avgDuration: '0.0s',
      lastRun: 'Never',
      triggerType: 'Manual',
      enabled: false,
    }
    setAutomations(prev => [newAuto, ...prev])
  }

  /* ── Filters ── */
  const filteredExecutions = execFilter === 'all'
    ? DEMO_EXECUTIONS
    : DEMO_EXECUTIONS.filter(e => e.status === execFilter)

  const categories = ['All', ...Array.from(new Set(DEMO_ACTIONS.map(a => a.category)))]
  const filteredActions = DEMO_ACTIONS.filter(a => {
    const matchSearch = a.name.toLowerCase().includes(actionSearch.toLowerCase()) || a.description.toLowerCase().includes(actionSearch.toLowerCase())
    const matchCat = actionCategory === 'All' || a.category === actionCategory
    return matchSearch && matchCat
  })

  const templateCategories = ['All', 'Marketing', 'Sales', 'Support', 'DevOps', 'Data', 'HR']
  const filteredTemplates = templateCategory === 'All'
    ? DEMO_TEMPLATES
    : DEMO_TEMPLATES.filter(t => t.category === templateCategory)

  const maxRuns = Math.max(...RUNS_OVER_TIME.map(d => d.runs))

  /* ═══════════════════════════════════════════════════════════════
     RENDER
     ═══════════════════════════════════════════════════════════════ */
  return (
    <TooltipProvider>
      <div className="h-full bg-[#F8FAFC] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 pt-5 pb-3 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-[#1E293B] flex items-center gap-2">
                <Zap className="h-5 w-5 text-[#003ABC]" />
                Automation Center
              </h1>
              <p className="text-sm text-slate-500 mt-0.5">Build, monitor, and manage automated workflows</p>
            </div>
            <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-[#003ABC] hover:bg-[#002d8f] text-white">
                  <Plus className="h-4 w-4 mr-1.5" /> Create Automation
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[480px]">
                <DialogHeader>
                  <DialogTitle className="text-[#1E293B]">Create New Automation</DialogTitle>
                  <DialogDescription>Define a new automated workflow for your organization.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-3">
                  <div className="space-y-2">
                    <Label>Automation Name</Label>
                    <Input placeholder="e.g. Lead Enrichment Pipeline" value={newAutoName} onChange={e => setNewAutoName(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Type</Label>
                    <Select value={newAutoType} onValueChange={v => setNewAutoType(v as AutomationType)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="scheduled">Scheduled</SelectItem>
                        <SelectItem value="event">Event-Driven</SelectItem>
                        <SelectItem value="conditional">Conditional</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Trigger Type</Label>
                    <Select value={newAutoTrigger} onValueChange={setNewAutoTrigger}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="webhook">Webhook</SelectItem>
                        <SelectItem value="schedule">Schedule (Cron)</SelectItem>
                        <SelectItem value="agent">Agent Completion</SelectItem>
                        <SelectItem value="data">Data Change</SelectItem>
                        <SelectItem value="threshold">Threshold Alert</SelectItem>
                        <SelectItem value="pattern">Pattern Match</SelectItem>
                        <SelectItem value="manual">Manual</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Textarea placeholder="Describe what this automation does..." value={newAutoDesc} onChange={e => setNewAutoDesc(e.target.value)} rows={3} />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>Cancel</Button>
                  <Button className="bg-[#003ABC] hover:bg-[#002d8f] text-white" onClick={createAutomation}>Create</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="automations" className="flex-1 flex flex-col min-h-0 px-6">
          <TabsList className="bg-white border border-slate-200 rounded-lg p-0.5 h-10 flex-shrink-0 w-fit">
            <TabsTrigger value="automations" className="text-xs font-medium data-[state=active]:bg-[#003ABC] data-[state=active]:text-white rounded-md px-3">Automations</TabsTrigger>
            <TabsTrigger value="triggers" className="text-xs font-medium data-[state=active]:bg-[#003ABC] data-[state=active]:text-white rounded-md px-3">Triggers</TabsTrigger>
            <TabsTrigger value="workflow" className="text-xs font-medium data-[state=active]:bg-[#003ABC] data-[state=active]:text-white rounded-md px-3">Workflow Builder</TabsTrigger>
            <TabsTrigger value="actions" className="text-xs font-medium data-[state=active]:bg-[#003ABC] data-[state=active]:text-white rounded-md px-3">Actions Library</TabsTrigger>
            <TabsTrigger value="executions" className="text-xs font-medium data-[state=active]:bg-[#003ABC] data-[state=active]:text-white rounded-md px-3">Executions</TabsTrigger>
            <TabsTrigger value="templates" className="text-xs font-medium data-[state=active]:bg-[#003ABC] data-[state=active]:text-white rounded-md px-3">Templates</TabsTrigger>
            <TabsTrigger value="metrics" className="text-xs font-medium data-[state=active]:bg-[#003ABC] data-[state=active]:text-white rounded-md px-3">Metrics</TabsTrigger>
          </TabsList>

          <div className="flex-1 min-h-0 mt-4 pb-6">
            {/* ═══════ TAB 1: AUTOMATIONS ═══════ */}
            <TabsContent value="automations" className="h-full m-0">
              <ScrollArea className="h-full">
                <div className="space-y-3">
                  {automations.map(auto => (
                    <Card key={auto.id} className="bg-white border-slate-200 hover:border-slate-300 transition-colors">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h3 className="font-semibold text-[#1E293B] text-sm">{auto.name}</h3>
                              <StatusBadge status={auto.status} />
                              <TypeBadge type={auto.type} />
                            </div>
                            <p className="text-xs text-slate-500 mt-1 line-clamp-1">{auto.description}</p>
                            <div className="flex items-center gap-4 mt-2.5 flex-wrap">
                              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                                <Play className="h-3 w-3" />
                                <span className="font-medium text-[#1E293B]">{auto.runs.toLocaleString()}</span> runs
                              </div>
                              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                                <CheckCircle className="h-3 w-3 text-emerald-500" />
                                <span className="font-medium text-[#1E293B]">{auto.successRate}%</span> success
                              </div>
                              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                                <Timer className="h-3 w-3" />
                                <span className="font-medium text-[#1E293B]">{auto.avgDuration}</span> avg
                              </div>
                              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                                <Clock className="h-3 w-3" />
                                Last: {auto.lastRun}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-1.5 flex-shrink-0">
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div className="flex items-center gap-1.5">
                                  <Switch
                                    checked={auto.enabled}
                                    onCheckedChange={() => toggleAutomation(auto.id)}
                                    className="data-[state=checked]:bg-[#003ABC]"
                                  />
                                </div>
                              </TooltipTrigger>
                              <TooltipContent>{auto.enabled ? 'Pause automation' : 'Enable automation'}</TooltipContent>
                            </Tooltip>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-500 hover:text-[#003ABC]">
                                  <Play className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Run now</TooltipContent>
                            </Tooltip>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-500 hover:text-[#003ABC]">
                                  <Edit className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Edit automation</TooltipContent>
                            </Tooltip>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-500 hover:text-red-600" onClick={() => deleteAutomation(auto.id)}>
                                  <Trash2 className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Delete automation</TooltipContent>
                            </Tooltip>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            {/* ═══════ TAB 2: TRIGGERS ═══════ */}
            <TabsContent value="triggers" className="h-full m-0">
              <ScrollArea className="h-full">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-base font-semibold text-[#1E293B]">Trigger Types</h2>
                    <p className="text-xs text-slate-500">Configure how your automations are activated</p>
                  </div>
                  <Dialog open={triggerDialogOpen} onOpenChange={setTriggerDialogOpen}>
                    <DialogTrigger asChild>
                      <Button className="bg-[#003ABC] hover:bg-[#002d8f] text-white text-xs">
                        <Plus className="h-3.5 w-3.5 mr-1.5" /> Create Trigger
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[460px]">
                      <DialogHeader>
                        <DialogTitle className="text-[#1E293B]">Create New Trigger</DialogTitle>
                        <DialogDescription>Set up a new trigger to activate your automations.</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-3">
                        <div className="space-y-2">
                          <Label>Trigger Name</Label>
                          <Input placeholder="e.g. Daily Data Sync" />
                        </div>
                        <div className="space-y-2">
                          <Label>Trigger Type</Label>
                          <Select defaultValue="webhook">
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="webhook">Webhook</SelectItem>
                              <SelectItem value="schedule">Schedule (Cron)</SelectItem>
                              <SelectItem value="agent">Agent Completion</SelectItem>
                              <SelectItem value="data">Data Change</SelectItem>
                              <SelectItem value="threshold">Threshold Alert</SelectItem>
                              <SelectItem value="pattern">Pattern Match</SelectItem>
                              <SelectItem value="manual">Manual</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Cron Expression (for Schedule type)</Label>
                          <Input placeholder="0 */6 * * *" />
                          <p className="text-xs text-slate-400">Every 6 hours. Use crontab.guru for reference.</p>
                        </div>
                        <div className="space-y-2">
                          <Label>Webhook URL (for Webhook type)</Label>
                          <Input placeholder="https://your-app.com/api/webhook" />
                        </div>
                        <div className="space-y-2">
                          <Label>Threshold Value (for Threshold type)</Label>
                          <div className="flex gap-2">
                            <Input placeholder="e.g. 100" className="flex-1" />
                            <Select defaultValue="gt">
                              <SelectTrigger className="w-[120px]"><SelectValue /></SelectTrigger>
                              <SelectContent>
                                <SelectItem value="gt">Greater than</SelectItem>
                                <SelectItem value="lt">Less than</SelectItem>
                                <SelectItem value="eq">Equals</SelectItem>
                                <SelectItem value="gte">GTE</SelectItem>
                                <SelectItem value="lte">LTE</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label>Pattern (for Pattern Match type)</Label>
                          <Input placeholder="e.g. error.*timeout" />
                        </div>
                        <div className="space-y-2">
                          <Label>Description</Label>
                          <Textarea placeholder="Describe this trigger..." rows={2} />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setTriggerDialogOpen(false)}>Cancel</Button>
                        <Button className="bg-[#003ABC] hover:bg-[#002d8f] text-white">Create Trigger</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {DEMO_TRIGGERS.map(trigger => (
                    <Card key={trigger.id} className={`bg-white ${trigger.borderColor} border hover:shadow-md transition-shadow cursor-pointer`}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className={`p-2.5 rounded-lg ${trigger.color}`}>
                            <trigger.icon className="h-5 w-5 text-[#1E293B]" />
                          </div>
                          <Badge variant="secondary" className="text-xs font-normal bg-slate-100 text-slate-600">
                            {trigger.activeCount} active
                          </Badge>
                        </div>
                        <h3 className="font-semibold text-[#1E293B] text-sm mt-3">{trigger.name}</h3>
                        <p className="text-xs text-slate-500 mt-1 leading-relaxed">{trigger.description}</p>
                        <Button variant="ghost" size="sm" className="mt-3 text-[#003ABC] text-xs p-0 h-auto hover:bg-transparent">
                          Configure <ArrowRight className="h-3 w-3 ml-1" />
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            {/* ═══════ TAB 3: WORKFLOW BUILDER ═══════ */}
            <TabsContent value="workflow" className="h-full m-0">
              <ScrollArea className="h-full">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-base font-semibold text-[#1E293B]">Workflow Builder</h2>
                    <p className="text-xs text-slate-500">Visual node-based automation workflow designer</p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="text-xs">
                      <Eye className="h-3.5 w-3.5 mr-1.5" /> Preview
                    </Button>
                    <Button size="sm" className="bg-[#003ABC] hover:bg-[#002d8f] text-white text-xs">
                      <Plus className="h-3.5 w-3.5 mr-1.5" /> Add Node
                    </Button>
                  </div>
                </div>

                {/* Workflow Canvas */}
                <Card className="bg-white border-slate-200">
                  <CardContent className="p-6">
                    <div className="relative">
                      {/* Grid background */}
                      <div className="absolute inset-0 opacity-[0.03]" style={{
                        backgroundImage: 'radial-gradient(circle, #1E293B 1px, transparent 1px)',
                        backgroundSize: '24px 24px',
                      }} />

                      {/* Node Grid */}
                      <div className="relative grid grid-cols-6 gap-x-6 gap-y-16" style={{ minHeight: '320px' }}>
                        {DEMO_WORKFLOW_NODES.map(node => {
                          const nodeColors: Record<NodeKind, { bg: string; border: string; icon: string }> = {
                            trigger: { bg: 'bg-emerald-50', border: 'border-emerald-300', icon: 'text-emerald-600' },
                            condition: { bg: 'bg-amber-50', border: 'border-amber-300', icon: 'text-amber-600' },
                            action: { bg: 'bg-blue-50', border: 'border-blue-300', icon: 'text-[#003ABC]' },
                            output: { bg: 'bg-purple-50', border: 'border-purple-300', icon: 'text-purple-600' },
                          }
                          const statusColors: Record<string, string> = {
                            idle: 'bg-gray-300',
                            running: 'bg-blue-500 animate-pulse',
                            success: 'bg-emerald-500',
                            error: 'bg-red-500',
                          }
                          const nodeKindIcons: Record<NodeKind, typeof Zap> = {
                            trigger: Zap,
                            condition: GitBranch,
                            action: Play,
                            output: FileOutput,
                          }
                          const colors = nodeColors[node.kind]
                          const KindIcon = nodeKindIcons[node.kind]

                          return (
                            <div
                              key={node.id}
                              className={`relative flex flex-col items-center justify-center p-3 rounded-xl border-2 ${colors.bg} ${colors.border} cursor-pointer hover:shadow-lg transition-all min-h-[80px] col-start-[${node.x + 1}] row-start-[${node.y + 1}]`}
                              style={{
                                gridColumnStart: node.x + 1,
                                gridRowStart: node.y + 1,
                              }}
                              onClick={() => setSelectedNode(selectedNode?.id === node.id ? null : node)}
                            >
                              {/* Status indicator */}
                              <div className={`absolute -top-1.5 -right-1.5 h-3 w-3 rounded-full border-2 border-white ${statusColors[node.status]}`} />
                              <KindIcon className={`h-4 w-4 ${colors.icon} mb-1.5`} />
                              <span className="text-xs font-medium text-[#1E293B] text-center leading-tight">{node.name}</span>
                              <Badge variant="outline" className={`text-[10px] mt-1 ${colors.border} ${colors.icon} capitalize`}>
                                {node.kind}
                              </Badge>
                            </div>
                          )
                        })}
                      </div>

                      {/* Connection lines (CSS-based) */}
                      <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 0 }}>
                        {DEMO_WORKFLOW_EDGES.map((edge, i) => {
                          const from = DEMO_WORKFLOW_NODES.find(n => n.id === edge.from)
                          const to = DEMO_WORKFLOW_NODES.find(n => n.id === edge.to)
                          if (!from || !to) return null
                          const colWidth = 16.67
                          const fromCx = (from.x + 0.5) * colWidth
                          const toCx = (to.x + 0.5) * colWidth
                          const rowHeight = 16
                          const fromCy = (from.y + 0.5) * rowHeight
                          const toCy = (to.y + 0.5) * rowHeight
                          const midX = (fromCx + toCx) / 2
                          return (
                            <path
                              key={i}
                              d={`M ${fromCx}% ${fromCy}% C ${midX}% ${fromCy}%, ${midX}% ${toCy}%, ${toCx}% ${toCy}%`}
                              fill="none"
                              stroke="#CBD5E1"
                              strokeWidth="2"
                              strokeDasharray="6 3"
                              markerEnd="url(#arrowhead)"
                            />
                          )
                        })}
                        <defs>
                          <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                            <polygon points="0 0, 10 3.5, 0 7" fill="#CBD5E1" />
                          </marker>
                        </defs>
                      </svg>
                    </div>
                  </CardContent>
                </Card>

                {/* Node Detail Panel */}
                {selectedNode && (
                  <Card className="bg-white border-slate-200 mt-4">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-sm text-[#1E293B]">Node Details: {selectedNode.name}</CardTitle>
                        <Button variant="ghost" size="sm" className="h-7 text-xs text-slate-500" onClick={() => setSelectedNode(null)}>
                          <XCircle className="h-3.5 w-3.5 mr-1" /> Close
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                        <div>
                          <span className="text-slate-500">Type</span>
                          <p className="font-medium text-[#1E293B] capitalize mt-0.5">{selectedNode.kind}</p>
                        </div>
                        <div>
                          <span className="text-slate-500">Status</span>
                          <p className="font-medium text-[#1E293B] capitalize mt-0.5">{selectedNode.status}</p>
                        </div>
                        <div>
                          <span className="text-slate-500">Position</span>
                          <p className="font-medium text-[#1E293B] mt-0.5">({selectedNode.x}, {selectedNode.y})</p>
                        </div>
                        <div>
                          <span className="text-slate-500">Connections</span>
                          <p className="font-medium text-[#1E293B] mt-0.5">
                            {DEMO_WORKFLOW_EDGES.filter(e => e.from === selectedNode.id || e.to === selectedNode.id).length}
                          </p>
                        </div>
                      </div>
                      <Separator className="my-3" />
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="text-xs"><Edit className="h-3 w-3 mr-1.5" /> Edit Config</Button>
                        <Button variant="outline" size="sm" className="text-xs text-red-600"><Trash2 className="h-3 w-3 mr-1.5" /> Remove Node</Button>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </ScrollArea>
            </TabsContent>

            {/* ═══════ TAB 4: ACTIONS LIBRARY ═══════ */}
            <TabsContent value="actions" className="h-full m-0">
              <ScrollArea className="h-full">
                <div className="mb-4">
                  <h2 className="text-base font-semibold text-[#1E293B]">Actions Library</h2>
                  <p className="text-xs text-slate-500">Browse and use actions in your automation workflows</p>
                </div>
                {/* Search & Filter */}
                <div className="flex flex-col sm:flex-row gap-3 mb-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
                    <Input
                      placeholder="Search actions..."
                      value={actionSearch}
                      onChange={e => setActionSearch(e.target.value)}
                      className="pl-9 h-9 text-sm"
                    />
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {categories.map(cat => (
                      <Button
                        key={cat}
                        variant={actionCategory === cat ? 'default' : 'outline'}
                        size="sm"
                        className={`text-xs h-8 ${actionCategory === cat ? 'bg-[#003ABC] hover:bg-[#002d8f] text-white' : ''}`}
                        onClick={() => setActionCategory(cat)}
                      >
                        {cat}
                      </Button>
                    ))}
                  </div>
                </div>
                {/* Action Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                  {filteredActions.map(action => (
                    <Card key={action.id} className="bg-white border-slate-200 hover:border-[#003ABC]/30 hover:shadow-md transition-all cursor-pointer group">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="p-2 rounded-lg bg-slate-50 group-hover:bg-blue-50 transition-colors">
                            <action.icon className="h-4 w-4 text-[#003ABC]" />
                          </div>
                          <Badge variant="secondary" className="text-[10px] bg-slate-100 text-slate-600">
                            {action.category}
                          </Badge>
                        </div>
                        <h3 className="font-semibold text-[#1E293B] text-sm mt-3">{action.name}</h3>
                        <p className="text-xs text-slate-500 mt-1 leading-relaxed line-clamp-2">{action.description}</p>
                        <Button variant="ghost" size="sm" className="mt-3 text-[#003ABC] text-xs p-0 h-auto hover:bg-transparent">
                          Use Action <ArrowRight className="h-3 w-3 ml-1" />
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            {/* ═══════ TAB 5: EXECUTIONS ═══════ */}
            <TabsContent value="executions" className="h-full m-0">
              <ScrollArea className="h-full">
                <div className="mb-4">
                  <h2 className="text-base font-semibold text-[#1E293B]">Execution History</h2>
                  <p className="text-xs text-slate-500">Review past automation runs and their results</p>
                </div>
                {/* Filters */}
                <div className="flex items-center gap-2 mb-4 flex-wrap">
                  <Filter className="h-4 w-4 text-slate-400" />
                  {(['all', 'success', 'failed', 'running', 'cancelled'] as const).map(s => (
                    <Button
                      key={s}
                      variant={execFilter === s ? 'default' : 'outline'}
                      size="sm"
                      className={`text-xs h-8 ${execFilter === s ? 'bg-[#003ABC] hover:bg-[#002d8f] text-white' : ''}`}
                      onClick={() => setExecFilter(s)}
                    >
                      {s === 'all' ? 'All' : s.charAt(0).toUpperCase() + s.slice(1)}
                      {s !== 'all' && (
                        <Badge variant="secondary" className="ml-1.5 text-[10px] h-4 px-1.5 bg-white/20 text-current">
                          {DEMO_EXECUTIONS.filter(e => e.status === (s as ExecutionStatus)).length}
                        </Badge>
                      )}
                    </Button>
                  ))}
                </div>
                {/* Table */}
                <Card className="bg-white border-slate-200">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-slate-200 hover:bg-transparent">
                        <TableHead className="text-xs font-semibold text-slate-500">Automation</TableHead>
                        <TableHead className="text-xs font-semibold text-slate-500">Trigger</TableHead>
                        <TableHead className="text-xs font-semibold text-slate-500">Status</TableHead>
                        <TableHead className="text-xs font-semibold text-slate-500">Duration</TableHead>
                        <TableHead className="text-xs font-semibold text-slate-500">Started</TableHead>
                        <TableHead className="text-xs font-semibold text-slate-500">Actions</TableHead>
                        <TableHead className="w-10"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredExecutions.map(exec => (
                        <>
                          <TableRow key={exec.id} className="border-slate-100 cursor-pointer hover:bg-slate-50" onClick={() => setExpandedExec(expandedExec === exec.id ? null : exec.id)}>
                            <TableCell className="text-sm font-medium text-[#1E293B]">{exec.automationName}</TableCell>
                            <TableCell className="text-xs text-slate-500">{exec.triggerType}</TableCell>
                            <TableCell><StatusBadge status={exec.status} /></TableCell>
                            <TableCell className="text-xs text-slate-600 font-mono">{exec.duration}</TableCell>
                            <TableCell className="text-xs text-slate-500">{exec.startedAt}</TableCell>
                            <TableCell className="text-xs text-slate-600">{exec.actionsCount}</TableCell>
                            <TableCell>
                              {expandedExec === exec.id
                                ? <ChevronDown className="h-4 w-4 text-slate-400" />
                                : <ChevronRight className="h-4 w-4 text-slate-400" />
                              }
                            </TableCell>
                          </TableRow>
                          {expandedExec === exec.id && (
                            <TableRow key={`${exec.id}-detail`} className="border-slate-100 bg-slate-50/50">
                              <TableCell colSpan={7} className="p-4">
                                <div className="ml-4">
                                  <h4 className="text-xs font-semibold text-[#1E293B] mb-3">Step Timeline</h4>
                                  <div className="space-y-3">
                                    {exec.steps.map((step, idx) => (
                                      <div key={idx} className="flex items-start gap-3">
                                        <div className="flex flex-col items-center">
                                          <StepStatusIcon status={step.status} />
                                          {idx < exec.steps.length - 1 && (
                                            <div className="w-px h-6 bg-slate-200 mt-1" />
                                          )}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                          <div className="flex items-center gap-2">
                                            <span className="text-xs font-medium text-[#1E293B]">{step.name}</span>
                                            <span className="text-[10px] text-slate-400 font-mono">{step.duration}</span>
                                          </div>
                                          {step.output && (
                                            <p className="text-[11px] text-slate-500 mt-0.5 bg-white border border-slate-200 rounded px-2 py-1 inline-block">
                                              {step.output}
                                            </p>
                                          )}
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              </TableCell>
                            </TableRow>
                          )}
                        </>
                      ))}
                    </TableBody>
                  </Table>
                </Card>
              </ScrollArea>
            </TabsContent>

            {/* ═══════ TAB 6: TEMPLATES ═══════ */}
            <TabsContent value="templates" className="h-full m-0">
              <ScrollArea className="h-full">
                <div className="mb-4">
                  <h2 className="text-base font-semibold text-[#1E293B]">Automation Templates</h2>
                  <p className="text-xs text-slate-500">Start from pre-built automation templates for common use cases</p>
                </div>
                {/* Category Filter */}
                <div className="flex gap-2 mb-4 flex-wrap">
                  {templateCategories.map(cat => (
                    <Button
                      key={cat}
                      variant={templateCategory === cat ? 'default' : 'outline'}
                      size="sm"
                      className={`text-xs h-8 ${templateCategory === cat ? 'bg-[#003ABC] hover:bg-[#002d8f] text-white' : ''}`}
                      onClick={() => setTemplateCategory(cat)}
                    >
                      {cat}
                    </Button>
                  ))}
                </div>
                {/* Template Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredTemplates.map(tpl => (
                    <Card key={tpl.id} className="bg-white border-slate-200 hover:border-[#003ABC]/30 hover:shadow-lg transition-all overflow-hidden group">
                      {/* Template Preview Header */}
                      <div className="h-20 bg-gradient-to-br from-[#003ABC]/5 to-[#FF6A00]/5 flex items-center justify-center border-b border-slate-100">
                        <div className="p-3 rounded-xl bg-white shadow-sm group-hover:scale-110 transition-transform">
                          <tpl.icon className="h-6 w-6 text-[#003ABC]" />
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-[#1E293B] text-sm flex-1">{tpl.name}</h3>
                          {tpl.popular && (
                            <Badge className="bg-[#FF6A00]/10 text-[#FF6A00] border-[#FF6A00]/20 text-[10px]">
                              <Star className="h-2.5 w-2.5 mr-0.5 fill-current" /> Popular
                            </Badge>
                          )}
                        </div>
                        <Badge variant="outline" className="text-[10px] bg-slate-50 text-slate-600 mb-2">{tpl.category}</Badge>
                        <p className="text-xs text-slate-500 leading-relaxed line-clamp-2 mb-3">{tpl.description}</p>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-slate-400">{tpl.steps} steps</span>
                          <Button size="sm" className="bg-[#003ABC] hover:bg-[#002d8f] text-white text-xs h-7" onClick={() => handleUseTemplate(tpl)}>
                            <Copy className="h-3 w-3 mr-1" /> Use Template
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            {/* ═══════ TAB 7: METRICS ═══════ */}
            <TabsContent value="metrics" className="h-full m-0">
              <ScrollArea className="h-full">
                <div className="mb-4">
                  <h2 className="text-base font-semibold text-[#1E293B]">Automation Metrics</h2>
                  <p className="text-xs text-slate-500">Analytics and performance insights for your automations</p>
                </div>

                {/* Stat Cards */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  <Card className="bg-white border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="p-1.5 rounded-md bg-blue-50">
                          <Zap className="h-4 w-4 text-[#003ABC]" />
                        </div>
                        <span className="text-xs text-slate-500">Total Automations</span>
                      </div>
                      <p className="text-2xl font-bold text-[#1E293B]">{automations.length}</p>
                      <p className="text-[10px] text-emerald-600 mt-1 flex items-center gap-0.5">
                        <TrendingUp className="h-3 w-3" /> +2 this week
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="bg-white border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="p-1.5 rounded-md bg-emerald-50">
                          <Activity className="h-4 w-4 text-emerald-600" />
                        </div>
                        <span className="text-xs text-slate-500">Active Triggers</span>
                      </div>
                      <p className="text-2xl font-bold text-[#1E293B]">57</p>
                      <p className="text-[10px] text-emerald-600 mt-1 flex items-center gap-0.5">
                        <TrendingUp className="h-3 w-3" /> +5 this week
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="bg-white border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="p-1.5 rounded-md bg-amber-50">
                          <BarChart3 className="h-4 w-4 text-amber-600" />
                        </div>
                        <span className="text-xs text-slate-500">Daily Runs (Avg)</span>
                      </div>
                      <p className="text-2xl font-bold text-[#1E293B]">152</p>
                      <p className="text-[10px] text-emerald-600 mt-1 flex items-center gap-0.5">
                        <TrendingUp className="h-3 w-3" /> +12% vs last week
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="bg-white border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="p-1.5 rounded-md bg-violet-50">
                          <CheckCircle className="h-4 w-4 text-violet-600" />
                        </div>
                        <span className="text-xs text-slate-500">Success Rate</span>
                      </div>
                      <p className="text-2xl font-bold text-[#1E293B]">96.4%</p>
                      <p className="text-[10px] text-red-500 mt-1 flex items-center gap-0.5">
                        <AlertTriangle className="h-3 w-3" /> -0.3% vs last week
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* Runs Over Time Chart */}
                <Card className="bg-white border-slate-200 mb-6">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm text-[#1E293B]">Runs Over Time</CardTitle>
                    <CardDescription>Daily automation runs for the past 7 days</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-end gap-3 h-48">
                      {RUNS_OVER_TIME.map((d, i) => (
                        <div key={i} className="flex-1 flex flex-col items-center gap-2">
                          <span className="text-xs font-medium text-[#1E293B]">{d.runs}</span>
                          <div
                            className="w-full rounded-t-md bg-gradient-to-t from-[#003ABC] to-[#003ABC]/60 transition-all hover:from-[#FF6A00] hover:to-[#FF6A00]/60 cursor-pointer min-h-[8px]"
                            style={{ height: `${(d.runs / maxRuns) * 140}px` }}
                          />
                          <span className="text-[10px] text-slate-500">{d.day}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Two column tables */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Top Performing Automations */}
                  <Card className="bg-white border-slate-200">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm text-[#1E293B]">Top Performing Automations</CardTitle>
                      <CardDescription>By total execution count</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow className="border-slate-100 hover:bg-transparent">
                            <TableHead className="text-xs text-slate-500">Automation</TableHead>
                            <TableHead className="text-xs text-slate-500 text-right">Runs</TableHead>
                            <TableHead className="text-xs text-slate-500 text-right">Success</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {[...automations].sort((a, b) => b.runs - a.runs).slice(0, 5).map(auto => (
                            <TableRow key={auto.id} className="border-slate-50">
                              <TableCell className="text-xs font-medium text-[#1E293B] py-2">{auto.name}</TableCell>
                              <TableCell className="text-xs text-slate-600 text-right py-2 font-mono">{auto.runs.toLocaleString()}</TableCell>
                              <TableCell className="text-xs text-right py-2">
                                <span className={auto.successRate >= 95 ? 'text-emerald-600' : auto.successRate >= 90 ? 'text-amber-600' : 'text-red-600'}>
                                  {auto.successRate}%
                                </span>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>

                  {/* Error Rate by Type */}
                  <Card className="bg-white border-slate-200">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm text-[#1E293B]">Error Rate by Trigger Type</CardTitle>
                      <CardDescription>Failure percentage per trigger category</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow className="border-slate-100 hover:bg-transparent">
                            <TableHead className="text-xs text-slate-500">Trigger Type</TableHead>
                            <TableHead className="text-xs text-slate-500 text-right">Error Rate</TableHead>
                            <TableHead className="text-xs text-slate-500 text-left w-[120px]"></TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {ERROR_RATES_BY_TYPE.map((er, i) => (
                            <TableRow key={i} className="border-slate-50">
                              <TableCell className="text-xs font-medium text-[#1E293B] py-2">{er.type}</TableCell>
                              <TableCell className="text-xs text-right py-2">
                                <span className={er.rate <= 2 ? 'text-emerald-600' : er.rate <= 5 ? 'text-amber-600' : 'text-red-600'}>
                                  {er.rate}%
                                </span>
                              </TableCell>
                              <TableCell className="py-2 pl-2">
                                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                                  <div
                                    className={`h-full rounded-full transition-all ${
                                      er.rate <= 2 ? 'bg-emerald-500' : er.rate <= 5 ? 'bg-amber-500' : 'bg-red-500'
                                    }`}
                                    style={{ width: `${(er.rate / 10) * 100}%` }}
                                  />
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                </div>
              </ScrollArea>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </TooltipProvider>
  )
}