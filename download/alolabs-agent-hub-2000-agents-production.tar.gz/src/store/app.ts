import { create } from 'zustand'

interface User {
  id: string
  email: string
  name: string
  role: string
}

interface AppState {
  user: User | null
  token: string | null
  sidebarOpen: boolean
  currentView: string
  selectedCompany: string | null
  showPublicSite: boolean
  login: (user: User, token: string) => void
  logout: () => void
  setSidebarOpen: (open: boolean) => void
  setView: (view: string) => void
  setSelectedCompany: (slug: string | null) => void
  setShowPublicSite: (show: boolean) => void
  _init: () => void
}

export const useAppStore = create<AppState>((set) => ({
  user: null,
  token: null,
  sidebarOpen: true,
  currentView: 'web-crm',
  selectedCompany: null,
  showPublicSite: false,
  login: (user, token) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('token', token)
      localStorage.setItem('user', JSON.stringify(user))
    }
    set({ user, token, currentView: 'web-crm' })
  },
  logout: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
    }
    set({ user: null, token: null, currentView: 'login' })
  },
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setView: (view) => set({ currentView: view }),
  setSelectedCompany: (slug) => set({ selectedCompany: slug }),
  setShowPublicSite: (show) => set({ showPublicSite: show }),
  _init: () => {
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('token')
      const userStr = localStorage.getItem('user')
      if (token && userStr) {
        try {
          set({ token, user: JSON.parse(userStr), currentView: 'web-crm' })
        } catch {
          // ignore parse errors
        }
      }
    }
  },
}))