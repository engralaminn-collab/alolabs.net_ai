import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const companiesCount = await db.company.count();
    const agentsCount = await db.agent.count();
    const workflowsCount = await db.workflow.count();
    const departmentsCount = await db.department.count();
    const usageLogsCount = await db.usageLog.count();
    const skillsCount = await db.skill.count();

    return NextResponse.json({
      system_name: 'ALO Labs Agent Hub',
      subtitle: 'Central AI Workforce for All ALO Group Companies',
      companies_count: companiesCount,
      agents_count: agentsCount,
      skills_count: skillsCount,
      workflows_count: workflowsCount,
      departments_count: departmentsCount,
      agent_runs_count: 0,
      skill_runs_count: 0,
      workflow_runs_count: 0,
      usage_logs_count: usageLogsCount,
      payment_guard_enabled: true,
      protection_mode_enabled: true,
      self_improvement_enabled: true,
      productivity_mode_enabled: true,
      rag_enabled: true,
      paid_ai_api_allowed: false,
      central_agent_hub_enabled: true,
      multi_company_routing_enabled: true,
      company_usage_tracking_enabled: true,
      selected_agent_runtime_enabled: true,
      web_crm_auto_connected: true,
      all_sister_companies_connected: true,
      status: 'healthy',
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}