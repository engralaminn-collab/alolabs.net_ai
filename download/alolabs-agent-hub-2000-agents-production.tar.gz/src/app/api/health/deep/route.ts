import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const [
      companiesCount,
      agentsCount,
      skillsCount,
      workflowsCount,
      departmentsCount,
      agentRunsCount,
      skillRunsCount,
      workflowRunsCount,
      usageLogsCount,
      tasksCount,
      approvalsCount,
      protectionLogsCount,
      paymentGuardLogsCount,
      auditLogsCount,
      usersCount,
    ] = await Promise.all([
      db.company.count(),
      db.agent.count(),
      db.skill.count(),
      db.workflow.count(),
      db.department.count(),
      db.agentRun.count(),
      db.skillRun.count(),
      db.workflowRun.count(),
      db.usageLog.count(),
      db.task.count(),
      db.approval.count(),
      db.protectionLog.count(),
      db.paymentGuardLog.count(),
      db.auditLog.count(),
      db.user.count(),
    ]);

    // Simulated service health checks
    const now = new Date().toISOString();
    const services = [
      { service: 'Database', status: 'healthy', responseMs: Math.floor(Math.random() * 20) + 5, details: 'SQLite connected', updatedAt: now },
      { service: 'Agent Registry', status: 'healthy', responseMs: Math.floor(Math.random() * 50) + 10, details: `${agentsCount} agents loaded`, updatedAt: now },
      { service: 'API Gateway', status: 'healthy', responseMs: Math.floor(Math.random() * 15) + 2, details: 'Gateway active', updatedAt: now },
      { service: 'Auth Service', status: 'healthy', responseMs: Math.floor(Math.random() * 30) + 5, details: `${usersCount} users, session validation active`, updatedAt: now },
      { service: 'Usage Tracker', status: 'healthy', responseMs: Math.floor(Math.random() * 40) + 10, details: `${usageLogsCount} usage records`, updatedAt: now },
      { service: 'Audit Logger', status: 'healthy', responseMs: Math.floor(Math.random() * 25) + 5, details: `${auditLogsCount} audit entries`, updatedAt: now },
    ];

    return NextResponse.json({
      system_name: 'ALO Labs Agent Hub',
      subtitle: 'Central AI Workforce for All ALO Group Companies',
      companies_count: companiesCount,
      agents_count: agentsCount,
      skills_count: skillsCount,
      workflows_count: workflowsCount,
      departments_count: departmentsCount,
      agent_runs_count: agentRunsCount,
      skill_runs_count: skillRunsCount,
      workflow_runs_count: workflowRunsCount,
      usage_logs_count: usageLogsCount,
      payment_guard_enabled: true,
      protection_mode_enabled: true,
      self_improvement_enabled: true,
      productivity_mode_enabled: true,
      rag_enabled: true,
      paid_ai_api_allowed: false,
      central_agent_hub_enabled: true,
      multi_company_routing_enabled: true,
      company_usage_tracking_enabled: true,
      selected_agent_runtime_enabled: true,
      web_crm_auto_connected: true,
      all_sister_companies_connected: companiesCount >= 6,
      status: 'healthy',
      timestamp: now,
      uptime: process.uptime(),
      memory_usage_mb: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
      services,
      table_counts: {
        companies: companiesCount,
        agents: agentsCount,
        skills: skillsCount,
        workflows: workflowsCount,
        departments: departmentsCount,
        agent_runs: agentRunsCount,
        skill_runs: skillRunsCount,
        workflow_runs: workflowRunsCount,
        usage_logs: usageLogsCount,
        tasks: tasksCount,
        approvals: approvalsCount,
        protection_logs: protectionLogsCount,
        payment_guard_logs: paymentGuardLogsCount,
        audit_logs: auditLogsCount,
        users: usersCount,
      },
    });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}