import { NextRequest, NextResponse } from 'next/server';
import { evaluateProtection, ProtectionCheck } from '../route';

export async function POST(request: NextRequest) {
  try {
    const body: ProtectionCheck = await request.json();

    if (!body.action || typeof body.action !== 'string') {
      return NextResponse.json(
        { error: 'action is required and must be a string' },
        { status: 400 }
      );
    }

    const result = await evaluateProtection(body);

    return NextResponse.json(result);
  } catch (error) {
    console.error('[Protection Evaluate Error]', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}