import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET: Retrieve current SSO configuration
export async function GET() {
  try {
    const configs = await db.ssoConfig.findMany({
      orderBy: { createdAt: 'asc' },
    });

    return NextResponse.json({ configs });
  } catch (error) {
    console.error('SSO get config error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST: Create or update an SSO configuration
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { provider, metadataUrl, entityId, callbackUrl, isActive, config } = body;

    if (!provider) {
      return NextResponse.json(
        { error: 'Provider type is required (saml, ldap, oidc)' },
        { status: 400 }
      );
    }

    const validProviders = ['saml', 'ldap', 'oidc'];
    if (!validProviders.includes(provider)) {
      return NextResponse.json(
        { error: `Invalid provider. Must be one of: ${validProviders.join(', ')}` },
        { status: 400 }
      );
    }

    // Upsert by provider name
    const upserted = await db.ssoConfig.upsert({
      where: { provider },
      update: {
        metadataUrl: metadataUrl ?? undefined,
        entityId: entityId ?? undefined,
        callbackUrl: callbackUrl ?? undefined,
        isActive: isActive !== undefined ? isActive : false,
        config: config ? JSON.stringify(config) : undefined,
        updatedAt: new Date(),
      },
      create: {
        provider,
        metadataUrl: metadataUrl ?? null,
        entityId: entityId ?? null,
        callbackUrl: callbackUrl ?? null,
        isActive: isActive !== undefined ? isActive : false,
        config: config ? JSON.stringify(config) : '{}',
      },
    });

    return NextResponse.json({
      id: upserted.id,
      provider: upserted.provider,
      metadataUrl: upserted.metadataUrl,
      entityId: upserted.entityId,
      callbackUrl: upserted.callbackUrl,
      isActive: upserted.isActive,
      config: upserted.config,
      createdAt: upserted.createdAt,
      updatedAt: upserted.updatedAt,
    });
  } catch (error) {
    console.error('SSO upsert error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}