import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { db } from '@/lib/db';

/**
 * Simulated TOTP code generation for demo purposes.
 * Real TOTP uses HMAC-SHA1; here we use SHA-256 as a deterministic simulation.
 * Code changes every 30 seconds.
 */
function generateCode(secret: string): string {
  const timeSlot = Math.floor(Date.now() / 30000);
  const hash = crypto
    .createHash('sha256')
    .update(secret + timeSlot.toString())
    .digest('hex');
  // Take the last 6 characters of the hex hash
  return hash.slice(-6);
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, code } = body;

    if (!userId || !code) {
      return NextResponse.json(
        { error: 'User ID and code are required' },
        { status: 400 }
      );
    }

    // Find the user
    const user = await db.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    if (!user.otpSecret) {
      return NextResponse.json(
        { error: 'MFA has not been set up. Please call /api/auth/mfa/setup first.' },
        { status: 400 }
      );
    }

    if (user.otpEnabled) {
      return NextResponse.json(
        { error: 'MFA is already enabled for this user.' },
        { status: 400 }
      );
    }

    // Generate the expected code for the current time slot
    const expectedCode = generateCode(user.otpSecret);

    if (code !== expectedCode) {
      return NextResponse.json(
        { error: 'Invalid verification code. Please try again.' },
        { status: 401 }
      );
    }

    // Enable MFA
    await db.user.update({
      where: { id: userId },
      data: { otpEnabled: true },
    });

    return NextResponse.json({
      message: 'MFA enabled successfully',
      enabled: true,
    });
  } catch (error) {
    console.error('MFA verify error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}