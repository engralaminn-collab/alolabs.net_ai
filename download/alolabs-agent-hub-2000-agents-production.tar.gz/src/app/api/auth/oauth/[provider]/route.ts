import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { db } from '@/lib/db';
import { hashPassword } from '@/lib/auth';

// Simulate exchanging the authorization code for an OAuth token
function simulateTokenExchange(): {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
} {
  return {
    accessToken: crypto.randomBytes(32).toString('hex'),
    refreshToken: crypto.randomBytes(32).toString('hex'),
    expiresIn: 3600,
  };
}

// Simulate fetching user profile from OAuth provider
function simulateUserInfo(provider: string): {
  id: string;
  email: string;
  name: string;
  avatar?: string;
} {
  return {
    id: `sim_${provider}_${Date.now()}`,
    email: `user_${provider}_${Date.now()}@example.com`,
    name: `OAuth User (${provider})`,
    avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${provider}`,
  };
}

// GET: Initiate OAuth flow — return { authorizationUrl, state }
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ provider: string }> }
) {
  try {
    const { provider } = await params;

    // Look up the OAuth provider configuration
    const providerConfig = await db.oAuthProvider.findUnique({
      where: { provider },
    });

    if (!providerConfig) {
      return NextResponse.json(
        { error: `OAuth provider '${provider}' is not configured` },
        { status: 404 }
      );
    }

    if (!providerConfig.isActive) {
      return NextResponse.json(
        { error: `OAuth provider '${provider}' is currently disabled` },
        { status: 400 }
      );
    }

    // Generate a random state for CSRF protection
    const state = crypto.randomBytes(24).toString('hex');

    // Parse scopes
    let scopes: string[] = [];
    try {
      scopes = JSON.parse(providerConfig.scopes);
    } catch {
      scopes = [];
    }

    // Build the authorization URL
    const url = new URL(providerConfig.authorizationUrl);
    url.searchParams.set('response_type', 'code');
    url.searchParams.set('client_id', providerConfig.clientId);
    url.searchParams.set('redirect_uri', `/api/auth/oauth/${provider}`);
    url.searchParams.set('scope', scopes.join(' '));
    url.searchParams.set('state', state);

    // Store the state temporarily in Settings for validation on callback
    await db.settings.upsert({
      where: { key: `oauth_state:${state}` },
      update: { value: provider, updatedAt: new Date() },
      create: { key: `oauth_state:${state}`, value: provider, type: 'string' },
    });

    return NextResponse.json({
      authorizationUrl: url.toString(),
      state,
    });
  } catch (error) {
    console.error('OAuth initiate error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST: Handle OAuth callback — exchange code for token, create/find user, create session
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ provider: string }> }
) {
  try {
    const { provider } = await params;
    const body = await request.json();
    const { code, state } = body;

    if (!code || !state) {
      return NextResponse.json(
        { error: 'Authorization code and state are required' },
        { status: 400 }
      );
    }

    // Validate the state parameter
    const stateRecord = await db.settings.findUnique({
      where: { key: `oauth_state:${state}` },
    });

    if (!stateRecord || stateRecord.value !== provider) {
      return NextResponse.json(
        { error: 'Invalid or expired OAuth state. Please restart the OAuth flow.' },
        { status: 400 }
      );
    }

    // Clean up the state
    await db.settings.delete({
      where: { key: `oauth_state:${state}` },
    });

    // Verify the provider is configured
    const providerConfig = await db.oAuthProvider.findUnique({
      where: { provider },
    });

    if (!providerConfig) {
      return NextResponse.json(
        { error: `OAuth provider '${provider}' is not configured` },
        { status: 404 }
      );
    }

    // Simulate token exchange
    const tokens = simulateTokenExchange();

    // Simulate fetching user info from provider
    const providerUser = simulateUserInfo(provider);

    // Check if an OAuth account already exists for this provider+providerAccountId
    const existingAccount = await db.oAuthAccount.findUnique({
      where: {
        provider_providerAccountId: {
          provider,
          providerAccountId: providerUser.id,
        },
      },
      include: { user: true },
    });

    let user;

    if (existingAccount) {
      // Link to existing user
      user = existingAccount.user;

      // Update the OAuth account with fresh tokens
      await db.oAuthAccount.update({
        where: { id: existingAccount.id },
        data: {
          accessToken: tokens.accessToken,
          refreshToken: tokens.refreshToken,
          tokenExpiry: new Date(Date.now() + tokens.expiresIn * 1000),
          profileJson: JSON.stringify(providerUser),
          updatedAt: new Date(),
        },
      });
    } else {
      // Check if a user with this email already exists
      user = await db.user.findUnique({
        where: { email: providerUser.email },
      });

      if (user) {
        // Link the OAuth account to the existing user
        await db.oAuthAccount.create({
          data: {
            userId: user.id,
            providerId: providerConfig.id,
            provider,
            providerAccountId: providerUser.id,
            accessToken: tokens.accessToken,
            refreshToken: tokens.refreshToken,
            tokenExpiry: new Date(Date.now() + tokens.expiresIn * 1000),
            profileJson: JSON.stringify(providerUser),
          },
        });
      } else {
        // Create a new user
        const randomPassword = crypto.randomBytes(24).toString('hex');
        user = await db.user.create({
          data: {
            email: providerUser.email,
            passwordHash: await hashPassword(randomPassword),
            name: providerUser.name,
            role: 'viewer',
            isActive: true,
            oauthAccounts: {
              create: {
                providerId: providerConfig.id,
                provider,
                providerAccountId: providerUser.id,
                accessToken: tokens.accessToken,
                refreshToken: tokens.refreshToken,
                tokenExpiry: new Date(Date.now() + tokens.expiresIn * 1000),
                profileJson: JSON.stringify(providerUser),
              },
            },
          },
        });
      }
    }

    // Create a session token
    const sessionToken = crypto.randomBytes(24).toString('hex');
    await db.settings.upsert({
      where: { key: `session:${sessionToken}` },
      update: {
        value: JSON.stringify({ userId: user.id }),
        updatedAt: new Date(),
      },
      create: {
        key: `session:${sessionToken}`,
        value: JSON.stringify({ userId: user.id }),
        type: 'json',
      },
    });

    // Update last login
    await db.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      },
      token: sessionToken,
    });
  } catch (error) {
    console.error('OAuth callback error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}