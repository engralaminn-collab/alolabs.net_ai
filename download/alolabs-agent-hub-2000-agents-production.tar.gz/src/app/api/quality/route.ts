import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET: List quality assessments. ?agentId=xxx returns assessments for an agent.
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const agentId = searchParams.get('agentId')
    const skillId = searchParams.get('skillId')
    const workflowId = searchParams.get('workflowId')
    const page = parseInt(searchParams.get('page') || '1', 10)
    const limit = parseInt(searchParams.get('limit') || '20', 10)

    const where: Record<string, unknown> = {}
    if (agentId) where.agentId = agentId
    if (skillId) where.skillId = skillId
    if (workflowId) where.workflowId = workflowId

    const [assessments, total] = await Promise.all([
      db.qualityAssessment.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.qualityAssessment.count({ where }),
    ])

    return NextResponse.json({
      assessments,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error('Error listing quality assessments:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// POST: Create quality assessment
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { agentId, skillId, workflowId, assessor, level, score, criteria, notes } = body

    if (score === undefined || score === null) {
      return NextResponse.json({ error: 'score is required' }, { status: 400 })
    }

    if (typeof score !== 'number' || score < 0 || score > 100) {
      return NextResponse.json({ error: 'score must be a number between 0 and 100' }, { status: 400 })
    }

    const validLevels = ['draft', 'junior', 'mid', 'senior', 'expert', 'dept_lead']
    if (level && !validLevels.includes(level)) {
      return NextResponse.json({ error: `level must be one of: ${validLevels.join(', ')}` }, { status: 400 })
    }

    const validAssessors = ['system', 'human', 'peer']
    if (assessor && !validAssessors.includes(assessor)) {
      return NextResponse.json({ error: `assessor must be one of: ${validAssessors.join(', ')}` }, { status: 400 })
    }

    const data: Record<string, unknown> = {
      score,
      criteria: criteria ? (typeof criteria === 'string' ? criteria : JSON.stringify(criteria)) : '{}',
    }
    if (agentId) data.agentId = agentId
    if (skillId) data.skillId = skillId
    if (workflowId) data.workflowId = workflowId
    if (assessor) data.assessor = assessor
    if (level) data.level = level
    if (notes) data.notes = notes

    const assessment = await db.qualityAssessment.create({ data: data as never })

    return NextResponse.json({ assessment }, { status: 201 })
  } catch (error) {
    console.error('Error creating quality assessment:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}