import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

export async function POST(request: NextRequest) {
  try {
    await requireAuth();
    const body = await request.json();
    const { ids, markAll } = body;

    if (markAll) {
      // Mark all as read
      const notifications = await db.settings.findMany({
        where: { key: { startsWith: 'notification:' } },
      });
      for (const n of notifications) {
        try {
          const parsed = JSON.parse(n.value);
          if (!parsed.read) {
            await db.settings.update({
              where: { id: n.id },
              data: { value: JSON.stringify({ ...parsed, read: true }) },
            });
          }
        } catch { /* skip */ }
      }
      return NextResponse.json({ success: true, message: 'All notifications marked as read' });
    }

    if (ids && Array.isArray(ids)) {
      for (const id of ids) {
        const n = await db.settings.findUnique({ where: { id } });
        if (n) {
          try {
            const parsed = JSON.parse(n.value);
            await db.settings.update({
              where: { id },
              data: { value: JSON.stringify({ ...parsed, read: true }) },
            });
          } catch { /* skip */ }
        }
      }
      return NextResponse.json({ success: true, message: `${ids.length} notifications marked as read` });
    }

    return NextResponse.json({ error: 'ids or markAll required' }, { status: 400 });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Notifications read POST error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}