import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

export async function GET(request: NextRequest) {
  try {
    await requireAuth();
    const { searchParams } = new URL(request.url);
    const tab = searchParams.get('tab') || '';

    const notifications = await db.settings.findMany({
      where: { key: { startsWith: 'notification:' } },
      orderBy: { createdAt: 'desc' },
    });

    let data = notifications.map((n) => {
      try { return { id: n.id, key: n.key, ...JSON.parse(n.value), createdAt: n.createdAt, updatedAt: n.updatedAt }; }
      catch { return null; }
    }).filter(Boolean);

    if (tab === 'unread') {
      data = data.filter((d) => !d.read);
    } else if (tab === 'alerts') {
      data = data.filter((d) => d.type === 'security_alert' || d.type === 'usage_warning' || d.type === 'agent_alert');
    } else if (tab === 'system') {
      data = data.filter((d) => d.type === 'system_update');
    }

    return NextResponse.json({ data, unreadCount: data.filter((d) => !d.read).length });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Notifications GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}