import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireAuth();
    const { id } = await params;
    const body = await request.json();
    const { status, description, assignedTo } = body;

    const existing = await db.settings.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 });
    }

    const parsed = JSON.parse(existing.value);
    const updates: Record<string, unknown> = {};

    if (status) {
      updates.status = status;
      parsed.timeline = parsed.timeline || [];
      parsed.timeline.push({ event: `Status changed to ${status}`, by: user.name, at: new Date().toISOString() });
      updates.timeline = parsed.timeline;
    }
    if (description) updates.description = description;
    if (assignedTo) updates.assignedTo = assignedTo;

    const newValue = { ...parsed, ...updates };
    await db.settings.update({
      where: { id },
      data: { value: JSON.stringify(newValue) },
    });

    return NextResponse.json({ id, key: existing.key, ...newValue });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Incidents PUT error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}