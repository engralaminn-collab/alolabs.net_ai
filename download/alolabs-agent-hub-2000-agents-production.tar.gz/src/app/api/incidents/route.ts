import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status') || ''

    const allSettings = await db.settings.findMany({
      where: { key: { startsWith: 'incident:' } },
      orderBy: { createdAt: 'desc' },
    })

    let incidents: Array<Record<string, unknown>> = []
    let counter = 0

    for (const s of allSettings) {
      try {
        const parsed = JSON.parse(s.value)
        if (status && parsed.status !== status) continue
        counter++
        incidents.push({
          id: s.id,
          incidentId: `INC-${String(counter).padStart(4, '0')}`,
          ...parsed,
          createdAt: s.createdAt.toISOString(),
          updatedAt: s.updatedAt.toISOString(),
        })
      } catch {
        // skip
      }
    }

    // Re-number by creation order
    incidents.sort((a, b) => new Date(b.createdAt as string).getTime() - new Date(a.createdAt as string).getTime())
    incidents.forEach((inc, idx) => {
      inc.incidentId = `INC-${String(incidents.length - idx).padStart(4, '0')}`
    })

    const stats = {
      active: incidents.filter((i) => i.status === 'active').length,
      investigating: incidents.filter((i) => i.status === 'investigating').length,
      resolved: incidents.filter((i) => i.status === 'resolved').length,
      total: incidents.length,
    }

    return NextResponse.json({ incidents, stats })
  } catch (error) {
    console.error('Incidents GET error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, severity, description, assignedDept } = body as {
      type: string
      severity: string
      description: string
      assignedDept: string
    }

    if (!type || !severity || !description) {
      return NextResponse.json({ error: 'type, severity, and description are required' }, { status: 400 })
    }

    const ts = new Date().toISOString()
    const id = `incident:${Date.now()}`
    const value = JSON.stringify({
      type,
      severity,
      description,
      assignedDept: assignedDept || 'unassigned',
      status: 'active',
      resolution: '',
      timeline: [{ status: 'active', timestamp: ts, note: 'Incident reported' }],
      createdAt: ts,
    })

    const setting = await db.settings.create({
      data: { key: id, value, type: 'json' },
    })

    return NextResponse.json({ success: true, id: setting.id })
  } catch (error) {
    console.error('Incidents POST error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, status, resolution } = body as { id: string; status: string; resolution?: string }

    if (!id || !status) {
      return NextResponse.json({ error: 'id and status are required' }, { status: 400 })
    }

    const existing = await db.settings.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Incident not found' }, { status: 404 })
    }

    const parsed = JSON.parse(existing.value)
    const oldStatus = parsed.status
    parsed.status = status
    if (resolution) parsed.resolution = resolution
    if (!parsed.timeline) parsed.timeline = []
    parsed.timeline.push({
      status,
      timestamp: new Date().toISOString(),
      note: `Status changed from ${oldStatus} to ${status}${resolution ? `. Resolution: ${resolution}` : ''}`,
    })

    await db.settings.update({
      where: { id },
      data: { value: JSON.stringify(parsed), updatedAt: new Date() },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Incidents PUT error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}