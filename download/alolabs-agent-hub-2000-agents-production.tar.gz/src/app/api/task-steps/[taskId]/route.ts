import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ taskId: string }> }
) {
  try {
    const { taskId } = await params

    const steps = await db.taskStep.findMany({
      where: { taskId },
      orderBy: [{ stepNumber: 'asc' }, { createdAt: 'asc' }],
    })

    return NextResponse.json(steps)
  } catch (error) {
    console.error('[Task Steps] Error:', error)
    return NextResponse.json(
      { error: 'Failed to load task steps' },
      { status: 500 }
    )
  }
}