import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

export async function GET() {
  try {
    await requireAuth();

    // Redirect to workers/action which handles GET
    const workers = await db.settings.findMany({
      where: { key: { startsWith: 'worker:' } },
    });

    const poolConfig = await db.settings.findUnique({ where: { key: 'worker_pool_config' } });
    let pool = { minWorkers: 2, maxWorkers: 8, autoScale: true };
    if (poolConfig) {
      try { pool = { ...pool, ...JSON.parse(poolConfig.value) }; } catch { /* default */ }
    }

    const data = workers.map((w) => {
      try { return { id: w.id, key: w.key, ...JSON.parse(w.value), createdAt: w.createdAt, updatedAt: w.updatedAt }; }
      catch { return null; }
    }).filter(Boolean);

    return NextResponse.json({ data, pool });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Workers GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}