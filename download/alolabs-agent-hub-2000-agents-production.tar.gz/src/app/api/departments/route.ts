import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const departments = await db.department.findMany({
      orderBy: { sortOrder: 'asc' },
      include: {
        _count: { select: { agents: true } },
      },
    });

    const data = departments.map((d) => ({
      id: d.id,
      name: d.name,
      slug: d.slug,
      description: d.description,
      agentCount: d._count.agents,
      sortOrder: d.sortOrder,
      status: d.status,
    }));

    return NextResponse.json({ data });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}