import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

const DEFAULT_MODELS = [
  {
    modelId: 'deepseek-v3',
    name: 'DeepSeek V3',
    provider: 'local',
    costPer1kTokens: 0,
    maxContext: 8192,
    capabilities: ['chat', 'completion'],
    status: 'active',
    healthStatus: 'healthy',
  },
  {
    modelId: 'deepseek-r1',
    name: 'DeepSeek R1',
    provider: 'local',
    costPer1kTokens: 0,
    maxContext: 8192,
    capabilities: ['chat', 'completion', 'reasoning'],
    status: 'active',
    healthStatus: 'healthy',
  },
  {
    modelId: 'llama-3-70b',
    name: 'LLaMA 3 70B',
    provider: 'local',
    costPer1kTokens: 0,
    maxContext: 8192,
    capabilities: ['chat', 'completion'],
    status: 'active',
    healthStatus: 'healthy',
  },
  {
    modelId: 'qwen-2.5-72b',
    name: 'Qwen 2.5 72B',
    provider: 'local',
    costPer1kTokens: 0,
    maxContext: 16384,
    capabilities: ['chat', 'completion', 'code'],
    status: 'active',
    healthStatus: 'healthy',
  },
  {
    modelId: 'mixtral-8x22b',
    name: 'Mixtral 8x22B',
    provider: 'local',
    costPer1kTokens: 0,
    maxContext: 65536,
    capabilities: ['chat', 'completion'],
    status: 'standby',
    healthStatus: 'unknown',
  },
];

// GET /api/models — list models from registry
export async function GET() {
  try {
    await requireAuth();

    const models = await db.modelRegistry.findMany({
      orderBy: { createdAt: 'desc' },
    });

    // If no models registered, return defaults
    const data = models.length > 0
      ? models.map((m) => ({
          ...m,
          capabilities: JSON.parse(m.capabilities),
        }))
      : DEFAULT_MODELS;

    return NextResponse.json({ data, total: data.length });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST /api/models — register a new model
export async function POST(req: NextRequest) {
  try {
    await requireAuth();
    const body = await req.json();
    const { modelId, name, provider, costPer1kTokens, maxContext, capabilities, endpoint } = body;

    if (!modelId || !name) {
      return NextResponse.json({ error: 'modelId and name are required' }, { status: 400 });
    }

    const model = await db.modelRegistry.create({
      data: {
        modelId,
        name,
        provider: provider || 'local',
        costPer1kTokens: costPer1kTokens ?? 0,
        maxContext: maxContext || 4096,
        capabilities: capabilities ? JSON.stringify(capabilities) : '[]',
        status: 'active',
        healthStatus: 'healthy',
        endpoint: endpoint || null,
        deployedAt: new Date(),
      },
    });

    return NextResponse.json({ data: { ...model, capabilities: JSON.parse(model.capabilities) } }, { status: 201 });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    if (error instanceof Error && error.message.includes('Unique')) {
      return NextResponse.json({ error: 'Model with this modelId already exists' }, { status: 409 });
    }
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}