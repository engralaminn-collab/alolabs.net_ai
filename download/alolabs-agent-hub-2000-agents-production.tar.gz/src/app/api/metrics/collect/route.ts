import { NextResponse } from 'next/server'
import { collectSystemMetrics } from '@/lib/metrics-collector'

// ──────────────────────────────────────────────
// POST /api/metrics/collect — trigger system metrics collection
// ──────────────────────────────────────────────

export async function POST() {
  try {
    const metrics = await collectSystemMetrics()

    return NextResponse.json({
      data: metrics,
      message: 'System metrics collected and recorded successfully',
    })
  } catch (error) {
    console.error('Error collecting system metrics:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}