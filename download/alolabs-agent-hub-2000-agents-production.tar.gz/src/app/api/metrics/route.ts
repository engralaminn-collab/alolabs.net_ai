import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/metrics — query metrics with optional aggregation
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const name = searchParams.get('name');
    const from = searchParams.get('from');
    const to = searchParams.get('to');
    const agg = searchParams.get('agg'); // sum, avg, min, max, count
    const period = searchParams.get('period'); // e.g. 5m, 1h, 1d
    const labels = searchParams.get('labels'); // JSON string of label filters
    const limit = Math.min(500, parseInt(searchParams.get('limit') || '100'));

    const where: Record<string, unknown> = {};

    if (name) where.name = name;

    if (from || to) {
      where.createdAt = {};
      if (from) (where.createdAt as Record<string, unknown>).gte = new Date(from);
      if (to) (where.createdAt as Record<string, unknown>).lte = new Date(to);
    }

    // Filter by labels (JSON match on the labels string field)
    if (labels) {
      try {
        const labelFilters = JSON.parse(labels);
        for (const [key, value] of Object.entries(labelFilters)) {
          where.labels = { contains: `"${key}":"${value}"` };
        }
      } catch {
        return NextResponse.json({ error: 'Invalid labels JSON' }, { status: 400 });
      }
    }

    // Aggregation mode
    if (agg) {
      const validAggs = ['sum', 'avg', 'min', 'max', 'count'];
      if (!validAggs.includes(agg)) {
        return NextResponse.json({ error: `Invalid aggregation. Must be one of: ${validAggs.join(', ')}` }, { status: 400 });
      }

      const metrics = await db.metric.findMany({
        where,
        orderBy: { createdAt: 'asc' },
        take: 10000, // reasonable upper bound for aggregation
      });

      if (metrics.length === 0) {
        return NextResponse.json({ data: { aggregation: agg, name, result: null, count: 0 } });
      }

      const values = metrics.map((m) => m.value);
      let result: number | null = null;

      switch (agg) {
        case 'sum':
          result = values.reduce((a, b) => a + b, 0);
          break;
        case 'avg':
          result = values.reduce((a, b) => a + b, 0) / values.length;
          break;
        case 'min':
          result = Math.min(...values);
          break;
        case 'max':
          result = Math.max(...values);
          break;
        case 'count':
          result = values.length;
          break;
      }

      // Time-bucketed aggregation if period is specified
      let buckets: Array<{ bucket: string; value: number; count: number }> | null = null;
      if (period) {
        const periodMs = parsePeriod(period);
        if (periodMs > 0) {
          const bucketValues = new Map<string, number[]>();
          for (const m of metrics) {
            const ts = new Date(m.createdAt).getTime();
            const bucketStart = Math.floor(ts / periodMs) * periodMs;
            const bucketKey = new Date(bucketStart).toISOString();
            const arr = bucketValues.get(bucketKey) || [];
            arr.push(m.value);
            bucketValues.set(bucketKey, arr);
          }

          buckets = Array.from(bucketValues.entries())
            .sort(([a], [b]) => a.localeCompare(b))
            .map(([bucket, values]) => {
              let bucketValue: number;
              switch (agg) {
                case 'sum': bucketValue = values.reduce((a, b) => a + b, 0); break;
                case 'avg': bucketValue = values.reduce((a, b) => a + b, 0) / values.length; break;
                case 'min': bucketValue = Math.min(...values); break;
                case 'max': bucketValue = Math.max(...values); break;
                case 'count': bucketValue = values.length; break;
                default: bucketValue = values.reduce((a, b) => a + b, 0);
              }
              return { bucket, value: bucketValue, count: values.length };
            });
        }
      }

      return NextResponse.json({
        data: {
          aggregation: agg,
          name,
          result: Math.round(result! * 10000) / 10000,
          count: metrics.length,
          period: period || null,
          buckets,
        },
      });
    }

    // Standard query (no aggregation)
    const metrics = await db.metric.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
    });

    const data = metrics.map((m) => ({
      id: m.id,
      name: m.name,
      value: m.value,
      labels: m.labels,
      unit: m.unit,
      createdAt: m.createdAt.toISOString(),
    }));

    return NextResponse.json({ data, count: data.length });
  } catch (error) {
    console.error('GET /api/metrics error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST /api/metrics — record a metric
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, value, labels, unit } = body;

    if (!name || typeof name !== 'string') {
      return NextResponse.json({ error: 'name is required' }, { status: 400 });
    }
    if (typeof value !== 'number') {
      return NextResponse.json({ error: 'value must be a number' }, { status: 400 });
    }

    const metric = await db.metric.create({
      data: {
        name,
        value,
        labels: labels ? JSON.stringify(labels) : '{}',
        unit: unit || '',
      },
    });

    return NextResponse.json({ data: metric }, { status: 201 });
  } catch (error) {
    console.error('POST /api/metrics error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// DELETE /api/metrics — prune old metrics (?olderThan=2025-01-01)
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const olderThan = searchParams.get('olderThan');

    if (!olderThan) {
      return NextResponse.json({ error: 'olderThan query parameter is required (ISO date string)' }, { status: 400 });
    }

    const cutoff = new Date(olderThan);
    if (isNaN(cutoff.getTime())) {
      return NextResponse.json({ error: 'Invalid date format for olderThan' }, { status: 400 });
    }

    const result = await db.metric.deleteMany({
      where: {
        createdAt: { lt: cutoff },
      },
    });

    return NextResponse.json({ data: { deleted: result.count, olderThan } });
  } catch (error) {
    console.error('DELETE /api/metrics error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// Helper: parse period string like "5m", "1h", "1d" into milliseconds
function parsePeriod(period: string): number {
  const match = period.match(/^(\d+)(ms|s|m|h|d)$/);
  if (!match) return 0;
  const num = parseInt(match[1]);
  const unit = match[2];
  switch (unit) {
    case 'ms': return num;
    case 's': return num * 1000;
    case 'm': return num * 60 * 1000;
    case 'h': return num * 60 * 60 * 1000;
    case 'd': return num * 24 * 60 * 60 * 1000;
    default: return 0;
  }
}