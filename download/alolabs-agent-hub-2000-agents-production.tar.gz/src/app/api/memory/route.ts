import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

export async function GET(request: NextRequest) {
  try {
    await requireAuth();
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get('page') || '1'));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20')));
    const search = searchParams.get('search') || '';
    const category = searchParams.get('category') || '';
    const temperature = searchParams.get('temperature') || '';
    const agentId = searchParams.get('agentId') || '';

    const where: Record<string, unknown> = {};
    if (search) {
      where.content = { contains: search };
    }
    if (category) where.category = category;
    if (temperature) where.temperature = temperature;
    if (agentId) where.agentId = agentId;

    const [data, total] = await Promise.all([
      db.agentMemory.findMany({
        where,
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { updatedAt: 'desc' },
      }),
      db.agentMemory.count({ where }),
    ]);

    return NextResponse.json({ data, total, page, limit });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Memory GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    const body = await request.json();

    if (!body.agentId || !body.content) {
      return NextResponse.json({ error: 'agentId and content are required' }, { status: 400 });
    }

    const memory = await db.agentMemory.create({
      data: {
        agentId: body.agentId,
        category: body.category || 'general',
        content: body.content,
        temperature: body.temperature || 'warm',
      },
    });

    await db.auditLog.create({
      data: {
        userId: user.userId,
        action: 'create',
        resource: 'memory',
        details: JSON.stringify({ memoryId: memory.id, agentId: body.agentId }),
      },
    });

    return NextResponse.json(memory, { status: 201 });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Memory POST error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}