import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

export async function POST() {
  try {
    const user = await requireAuth();
    const id = `backup_${Date.now()}`;
    const size = Math.floor(Math.random() * 500 + 50); // MB
    const duration = Math.floor(Math.random() * 120 + 10); // seconds

    await db.settings.create({
      data: {
        key: `backup:${id}`,
        value: JSON.stringify({
          backupId: id,
          type: 'manual',
          size,
          status: 'completed',
          duration,
          compression: true,
        }),
      },
    });

    await db.auditLog.create({
      data: {
        userId: user.userId,
        action: 'backup_create',
        resource: 'backup',
        details: JSON.stringify({ backupId: id, size, duration }),
      },
    });

    return NextResponse.json({ success: true, backupId: id, size, duration });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Backup create error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}