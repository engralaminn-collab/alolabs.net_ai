import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

export async function GET() {
  try {
    await requireAuth();
    const backups = await db.settings.findMany({
      where: { key: { startsWith: 'backup:' } },
      orderBy: { createdAt: 'desc' },
    });

    const data = backups.map((b) => {
      try { return { id: b.id, key: b.key, ...JSON.parse(b.value), createdAt: b.createdAt, updatedAt: b.updatedAt }; }
      catch { return null; }
    }).filter(Boolean);

    // Get config
    const configRecord = await db.settings.findUnique({ where: { key: 'backup_config' } });
    let config = { autoBackup: true, schedule: 'daily', retentionDays: 30, compression: true };
    if (configRecord) {
      try { config = { ...config, ...JSON.parse(configRecord.value) }; } catch { /* use default */ }
    }

    return NextResponse.json({ data, config });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Backups GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}