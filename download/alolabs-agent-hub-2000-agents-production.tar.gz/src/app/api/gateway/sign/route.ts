import { randomUUID } from 'crypto';
import { NextRequest, NextResponse } from 'next/server';
import { generateHMAC, verifyApiKey } from '@/lib/api-gateway';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { companyId, payload, apiKey, method = 'POST', url = '/api/test' } = body;

    if (!payload || typeof payload !== 'string') {
      return NextResponse.json(
        { error: 'payload is required and must be a string' },
        { status: 400 }
      );
    }

    let signingSecret: string;
    let companyInfo: { id: string; name: string; slug: string } | null = null;

    // If apiKey is provided, verify it and use it as the signing secret
    if (apiKey) {
      const keyData = await verifyApiKey(apiKey);
      if (!keyData) {
        return NextResponse.json(
          { error: 'Invalid or inactive API key' },
          { status: 401 }
        );
      }
      signingSecret = apiKey;
      companyInfo = keyData.company;
    } else if (companyId) {
      // If companyId is provided, look up the first active key as the signing secret
      const { db } = await import('@/lib/db');
      const company = await db.company.findUnique({
        where: { id: companyId },
        select: { id: true, name: true, slug: true },
      });
      if (!company) {
        return NextResponse.json(
          { error: 'Company not found' },
          { status: 404 }
        );
      }
      companyInfo = company;
      // Use companyId as a demo signing secret (in production, use the actual API key)
      signingSecret = companyId;
    } else {
      return NextResponse.json(
        { error: 'Either apiKey or companyId is required' },
        { status: 400 }
      );
    }

    const timestamp = Date.now().toString();
    const payloadToSign = `${method}\n${url}\n${timestamp}\n${payload}`;
    const signature = generateHMAC(payloadToSign, signingSecret);

    return NextResponse.json({
      signature,
      timestamp,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey ? apiKey.substring(0, 8) + '...' : 'demo-key'}`,
        'X-ALO-Company-ID': companyInfo?.id || '',
        'X-ALO-Timestamp': timestamp,
        'X-ALO-Signature': signature,
        'X-ALO-Request-ID': randomUUID(),
      },
      signingPayload: payloadToSign,
      company: companyInfo,
    });
  } catch (error) {
    console.error('[Gateway Sign Error]', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}