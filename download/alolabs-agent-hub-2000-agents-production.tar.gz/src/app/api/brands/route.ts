import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

const DEFAULT_BRANDS = {
  'brand:alolabs': JSON.stringify({
    company: 'ALO Labs',
    primaryColor: '#0B1D3A',
    accentColor: '#2563EB',
    fontFamily: 'Inter, system-ui, sans-serif',
    logoUrl: '/logo-alolabs.svg',
    sidebarStyle: 'dark',
  }),
  'brand:aloeducation': JSON.stringify({
    company: 'ALO Education',
    primaryColor: '#1E3A5F',
    accentColor: '#F97316',
    fontFamily: 'Inter, system-ui, sans-serif',
    logoUrl: '/logo-aloeducation.svg',
    sidebarStyle: 'dark',
  }),
};

// GET /api/brands — return brand configurations
export async function GET() {
  try {
    await requireAuth();

    const settings = await db.settings.findMany({
      where: {
        OR: [
          { key: 'brand:alolabs' },
          { key: 'brand:aloeducation' },
          { key: { startsWith: 'brand:' } },
        ],
      },
    });

    if (settings.length === 0) {
      // Return default brand configs
      const brands = Object.entries(DEFAULT_BRANDS).map(([key, value]) => ({
        key,
        ...JSON.parse(value),
      }));
      return NextResponse.json({ data: brands });
    }

    const brands = settings.map((s) => ({
      key: s.key,
      ...JSON.parse(s.value),
    }));

    return NextResponse.json({ data: brands });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST /api/brands — save a brand configuration
export async function POST(req: NextRequest) {
  try {
    await requireAuth();
    const body = await req.json();
    const { company, primaryColor, accentColor, fontFamily, logoUrl, sidebarStyle } = body;

    if (!company) {
      return NextResponse.json({ error: 'company is required' }, { status: 400 });
    }

    const key = `brand:${company.toLowerCase().replace(/\s+/g, '')}`;
    const value = JSON.stringify({
      company,
      primaryColor: primaryColor || '#0B1D3A',
      accentColor: accentColor || '#2563EB',
      fontFamily: fontFamily || 'Inter, system-ui, sans-serif',
      logoUrl: logoUrl || '/logo.svg',
      sidebarStyle: sidebarStyle || 'dark',
    });

    const setting = await db.settings.upsert({
      where: { key },
      update: { value, type: 'json' },
      create: { key, value, type: 'json' },
    });

    return NextResponse.json({
      data: { key: setting.key, ...JSON.parse(setting.value) },
    }, { status: 201 });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}