import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ taskId: string }> }
) {
  try {
    const { taskId } = await params

    const runs = await db.skillRun.findMany({
      where: { taskId },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json(runs)
  } catch (error) {
    console.error('[Skill Runs] Error:', error)
    return NextResponse.json(
      { error: 'Failed to load skill runs' },
      { status: 500 }
    )
  }
}