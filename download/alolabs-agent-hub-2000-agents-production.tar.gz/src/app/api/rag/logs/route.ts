import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET() {
  try {
    const queries = await db.ragQuery.findMany({
      orderBy: { createdAt: 'desc' },
      take: 200,
      include: {
        _count: {
          select: { answers: true, feedback: true },
        },
      },
    })

    return NextResponse.json(queries)
  } catch (error) {
    console.error('[RAG Logs] Error:', error)
    return NextResponse.json(
      { error: 'Failed to load RAG query logs' },
      { status: 500 }
    )
  }
}