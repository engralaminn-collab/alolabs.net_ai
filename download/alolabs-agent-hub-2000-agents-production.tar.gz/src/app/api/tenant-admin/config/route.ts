import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET: Get tenant config for a company. If none exists, create default.
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const companyId = searchParams.get('companyId')

    if (!companyId) {
      return NextResponse.json({ error: 'companyId query parameter is required' }, { status: 400 })
    }

    // Verify company exists
    const company = await db.company.findUnique({ where: { id: companyId } })
    if (!company) {
      return NextResponse.json({ error: 'Company not found' }, { status: 404 })
    }

    // Try to find existing config
    let config = await db.tenantConfig.findUnique({ where: { companyId } })

    // If none exists, create default
    if (!config) {
      config = await db.tenantConfig.create({
        data: {
          companyId,
          primaryColor: '#003ABC',
          locale: 'en',
          timezone: 'Asia/Dhaka',
          notificationsEnabled: true,
          webhookTimeoutMs: 30000,
          maxConcurrentJobs: 5,
          config: '{}',
        },
      })
    }

    return NextResponse.json({ config })
  } catch (error) {
    console.error('Error fetching tenant config:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// POST: Create or update tenant config (upsert)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { companyId, logoUrl, primaryColor, customDomain, emailFrom, supportEmail, locale, timezone, notificationsEnabled, webhookTimeoutMs, maxConcurrentJobs, config } = body

    if (!companyId) {
      return NextResponse.json({ error: 'companyId is required' }, { status: 400 })
    }

    // Verify company exists
    const company = await db.company.findUnique({ where: { id: companyId } })
    if (!company) {
      return NextResponse.json({ error: 'Company not found' }, { status: 404 })
    }

    const data: Record<string, unknown> = {}
    if (logoUrl !== undefined) data.logoUrl = logoUrl
    if (primaryColor !== undefined) data.primaryColor = primaryColor
    if (customDomain !== undefined) data.customDomain = customDomain
    if (emailFrom !== undefined) data.emailFrom = emailFrom
    if (supportEmail !== undefined) data.supportEmail = supportEmail
    if (locale !== undefined) data.locale = locale
    if (timezone !== undefined) data.timezone = timezone
    if (notificationsEnabled !== undefined) data.notificationsEnabled = notificationsEnabled
    if (webhookTimeoutMs !== undefined) data.webhookTimeoutMs = webhookTimeoutMs
    if (maxConcurrentJobs !== undefined) data.maxConcurrentJobs = maxConcurrentJobs
    if (config !== undefined) data.config = typeof config === 'string' ? config : JSON.stringify(config)

    // Upsert
    const result = await db.tenantConfig.upsert({
      where: { companyId },
      update: data,
      create: {
        companyId,
        primaryColor: (data.primaryColor as string) || '#003ABC',
        locale: (data.locale as string) || 'en',
        timezone: (data.timezone as string) || 'Asia/Dhaka',
        notificationsEnabled: (data.notificationsEnabled as boolean) ?? true,
        webhookTimeoutMs: (data.webhookTimeoutMs as number) ?? 30000,
        maxConcurrentJobs: (data.maxConcurrentJobs as number) ?? 5,
        config: (data.config as string) || '{}',
        ...(data.logoUrl ? { logoUrl: data.logoUrl as string } : {}),
        ...(data.customDomain ? { customDomain: data.customDomain as string } : {}),
        ...(data.emailFrom ? { emailFrom: data.emailFrom as string } : {}),
        ...(data.supportEmail ? { supportEmail: data.supportEmail as string } : {}),
      },
    })

    return NextResponse.json({ config: result })
  } catch (error) {
    console.error('Error upserting tenant config:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}