import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ taskId: string }> }
) {
  try {
    const { taskId } = await params

    const outputs = await db.output.findMany({
      where: { taskId },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json(outputs)
  } catch (error) {
    console.error('[Outputs] Error:', error)
    return NextResponse.json(
      { error: 'Failed to load outputs' },
      { status: 500 }
    )
  }
}