import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const allSettings = await db.settings.findMany({
      where: { key: { startsWith: 'mcp_server:' } },
      orderBy: { updatedAt: 'desc' },
    })

    const servers: Array<Record<string, unknown>> = []
    for (const s of allSettings) {
      try {
        const parsed = JSON.parse(s.value)
        servers.push({
          id: s.id,
          ...parsed,
          createdAt: s.createdAt.toISOString(),
          updatedAt: s.updatedAt.toISOString(),
        })
      } catch {
        // skip
      }
    }

    return NextResponse.json({ servers })
  } catch (error) {
    console.error('MCP Servers GET error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, endpointUrl, authType, capabilities, autoStart } = body as {
      name: string
      endpointUrl: string
      authType: string
      capabilities: string
      autoStart: boolean
    }

    if (!name || !endpointUrl) {
      return NextResponse.json({ error: 'name and endpointUrl are required' }, { status: 400 })
    }

    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
    const key = `mcp_server:${slug}`

    const capsArray = (capabilities || '')
      .split(',')
      .map((c: string) => c.trim())
      .filter(Boolean)

    const value = JSON.stringify({
      name,
      endpointUrl,
      authType: authType || 'none',
      capabilities: capsArray,
      autoStart: autoStart ?? false,
      status: 'stopped',
      lastHeartbeat: null,
      createdAt: new Date().toISOString(),
    })

    const setting = await db.settings.upsert({
      where: { key },
      update: { value, type: 'json', updatedAt: new Date() },
      create: { key, value, type: 'json' },
    })

    return NextResponse.json({ success: true, id: setting.id, key })
  } catch (error) {
    console.error('MCP Servers POST error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, status } = body as { id: string; status: string }

    if (!id || !status) {
      return NextResponse.json({ error: 'id and status are required' }, { status: 400 })
    }

    const existing = await db.settings.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Server not found' }, { status: 404 })
    }

    const parsed = JSON.parse(existing.value)
    parsed.status = status
    if (status === 'active') {
      parsed.lastHeartbeat = new Date().toISOString()
    }

    await db.settings.update({
      where: { id },
      data: { value: JSON.stringify(parsed), updatedAt: new Date() },
    })

    return NextResponse.json({ success: true, status })
  } catch (error) {
    console.error('MCP Servers PUT error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    if (!id) {
      return NextResponse.json({ error: 'id is required' }, { status: 400 })
    }
    await db.settings.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('MCP Servers DELETE error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}