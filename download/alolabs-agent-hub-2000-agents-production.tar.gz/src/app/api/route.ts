import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    name: 'ALO Labs Agent Hub API',
    version: '1.0.0',
    endpoints: 131,
    status: 'operational',
  });
}