import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET() {
  try {
    const costEstimates = await db.costEstimate.findMany({
      orderBy: { createdAt: 'desc' },
      take: 200,
    })

    return NextResponse.json(costEstimates)
  } catch (error) {
    console.error('[Cost Estimate List] Error:', error)
    return NextResponse.json(
      { error: 'Failed to list cost estimates' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { companyId, provider, modelOrService, estimatedUnits, estimatedCost, reasonNeeded, localAlternative } = body

    if (!provider || !modelOrService) {
      return NextResponse.json(
        { error: 'provider and modelOrService are required' },
        { status: 400 }
      )
    }

    const costEstimate = await db.costEstimate.create({
      data: {
        companyId: companyId || null,
        provider,
        modelOrService,
        estimatedUnits: estimatedUnits ?? 0,
        estimatedCost: estimatedCost ?? 0,
        reasonNeeded: reasonNeeded || null,
        localAlternative: localAlternative || null,
      },
    })

    return NextResponse.json(costEstimate, { status: 201 })
  } catch (error) {
    console.error('[Cost Estimate Create] Error:', error)
    return NextResponse.json(
      { error: 'Failed to create cost estimate' },
      { status: 500 }
    )
  }
}