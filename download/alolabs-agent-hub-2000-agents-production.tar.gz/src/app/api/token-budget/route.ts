import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/token-budget — get token budget for a company (?companyId=xxx)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const companyId = searchParams.get('companyId');

    if (!companyId) {
      return NextResponse.json({ error: 'companyId query parameter is required' }, { status: 400 });
    }

    let budget = await db.tokenBudget.findUnique({ where: { companyId } });

    // Auto-reset logic: if current day >= resetDayOfMonth and lastReset is last month
    if (budget) {
      const now = new Date();
      const currentDay = now.getUTCDate();
      const lastReset = new Date(budget.lastResetAt);

      // Check if we've crossed into a new month (or it's the reset day in a new month)
      const lastResetMonth = lastReset.getUTCMonth();
      const lastResetYear = lastReset.getUTCFullYear();
      const currentMonth = now.getUTCMonth();
      const currentYear = now.getUTCFullYear();

      const isNewMonth =
        currentYear > lastResetYear ||
        (currentYear === lastResetYear && currentMonth > lastResetMonth);

      const isResetDay = currentDay >= budget.resetDayOfMonth;

      if (isNewMonth && isResetDay) {
        // Reset monthly and daily usage
        budget = await db.tokenBudget.update({
          where: { companyId },
          data: {
            monthlyUsed: 0,
            dailyUsed: 0,
            lastResetAt: new Date(),
          },
        });
      } else if (lastReset.getUTCDate() !== currentDay || lastResetMonth !== currentMonth) {
        // Daily reset if it's a new day within the same month
        const lastResetDate = new Date(lastReset.getFullYear(), lastReset.getMonth(), lastReset.getUTCDate());
        const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getUTCDate());

        if (todayStart > lastResetDate) {
          budget = await db.tokenBudget.update({
            where: { companyId },
            data: {
              dailyUsed: 0,
              lastResetAt: new Date(),
            },
          });
        }
      }
    }

    if (!budget) {
      return NextResponse.json({ error: 'Token budget not found for this company' }, { status: 404 });
    }

    const monthlyPercent = budget.monthlyBudget > 0
      ? (budget.monthlyUsed / budget.monthlyBudget) * 100
      : 0;
    const dailyPercent = budget.dailyBudget > 0
      ? (budget.dailyUsed / budget.dailyBudget) * 100
      : 0;

    return NextResponse.json({
      data: {
        ...budget,
        lastResetAt: budget.lastResetAt.toISOString(),
        createdAt: budget.createdAt.toISOString(),
        updatedAt: budget.updatedAt.toISOString(),
        usage: {
          monthly: {
            budget: budget.monthlyBudget,
            used: budget.monthlyUsed,
            remaining: Math.max(0, budget.monthlyBudget - budget.monthlyUsed),
            percent: Math.round(monthlyPercent * 100) / 100,
          },
          daily: {
            budget: budget.dailyBudget,
            used: budget.dailyUsed,
            remaining: Math.max(0, budget.dailyBudget - budget.dailyUsed),
            percent: Math.round(dailyPercent * 100) / 100,
          },
        },
        warnings: {
          monthlyWarning: monthlyPercent >= budget.warningThreshold * 100,
          monthlyBlocked: monthlyPercent >= budget.blockThreshold * 100,
          dailyWarning: dailyPercent >= budget.warningThreshold * 100,
          dailyBlocked: dailyPercent >= budget.blockThreshold * 100,
        },
      },
    });
  } catch (error) {
    console.error('GET /api/token-budget error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST /api/token-budget — create or update token budget
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      companyId,
      monthlyBudget,
      dailyBudget,
      warningThreshold,
      blockThreshold,
      resetDayOfMonth,
    } = body;

    if (!companyId || typeof companyId !== 'string') {
      return NextResponse.json({ error: 'companyId is required' }, { status: 400 });
    }

    // Verify company exists
    const company = await db.company.findUnique({ where: { id: companyId } });
    if (!company) {
      return NextResponse.json({ error: 'Company not found' }, { status: 404 });
    }

    const budget = await db.tokenBudget.upsert({
      where: { companyId },
      create: {
        companyId,
        monthlyBudget: typeof monthlyBudget === 'number' ? monthlyBudget : 1000000,
        dailyBudget: typeof dailyBudget === 'number' ? dailyBudget : 50000,
        warningThreshold: typeof warningThreshold === 'number' ? warningThreshold : 0.8,
        blockThreshold: typeof blockThreshold === 'number' ? blockThreshold : 1.0,
        resetDayOfMonth: typeof resetDayOfMonth === 'number' ? resetDayOfMonth : 1,
      },
      update: {
        ...(monthlyBudget !== undefined && { monthlyBudget }),
        ...(dailyBudget !== undefined && { dailyBudget }),
        ...(warningThreshold !== undefined && { warningThreshold }),
        ...(blockThreshold !== undefined && { blockThreshold }),
        ...(resetDayOfMonth !== undefined && { resetDayOfMonth }),
      },
    });

    return NextResponse.json({ data: budget });
  } catch (error) {
    console.error('POST /api/token-budget error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}