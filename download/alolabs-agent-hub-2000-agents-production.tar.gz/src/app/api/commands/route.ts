import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireAuth } from '@/lib/api-auth';

export async function POST(request: NextRequest) {
  try {
    const user = await requireAuth();
    const body = await request.json();
    const rawCommand = body.command || body.rawCommand;

    if (!rawCommand || typeof rawCommand !== 'string') {
      return NextResponse.json({ error: 'command is required' }, { status: 400 });
    }

    const lowerCmd = rawCommand.toLowerCase().trim();

    // Parse intent and detect department/workflow
    let detectedDept = '';
    let matchedWorkflow: string | null = null;
    let matchedWorkflowId: string | null = null;
    let parsedIntent = lowerCmd;

    // Match against workflow triggers from the database
    const workflows = await db.workflow.findMany({
      where: { status: 'active' },
    });

    for (const wf of workflows) {
      let triggers: string[] = [];
      try {
        triggers = JSON.parse(wf.triggers);
      } catch {
        // ignore malformed triggers
      }
      for (const trigger of triggers) {
        if (lowerCmd.includes(trigger.toLowerCase())) {
          matchedWorkflowId = wf.id;
          matchedWorkflow = wf.name;
          parsedIntent = `Execute workflow: ${wf.name}`;
          break;
        }
      }
      if (matchedWorkflowId) break;
    }

    // Detect department from command
    if (!detectedDept) {
      const depts = await db.department.findMany();
      for (const dept of depts) {
        const deptWords = dept.name.toLowerCase().split(/[\s&]+/).filter(Boolean);
        for (const word of deptWords) {
          if (word.length > 3 && lowerCmd.includes(word)) {
            detectedDept = dept.name;
            break;
          }
        }
        if (detectedDept) break;
      }
    }

    // Create the command record
    const command = await db.command.create({
      data: {
        rawCommand,
        parsedIntent,
        detectedDept: detectedDept || null,
        workflowId: matchedWorkflowId,
        status: 'pending',
        userId: user.userId,
      },
    });

    // Create associated task
    const task = await db.task.create({
      data: {
        title: `Command: ${rawCommand.substring(0, 100)}`,
        description: `Parsed intent: ${parsedIntent}${detectedDept ? ` | Department: ${detectedDept}` : ''}`,
        status: 'pending',
        priority: 'medium',
        commandId: command.id,
        workflowId: matchedWorkflowId,
        userId: user.userId,
      },
    });

    // If workflow matched, create TaskSteps from workflow steps
    if (matchedWorkflowId) {
      const workflowSteps = await db.workflowStep.findMany({
        where: { workflowId: matchedWorkflowId },
      });

      if (workflowSteps.length > 0) {
        await db.taskStep.createMany({
          data: workflowSteps.map((ws) => ({
            taskId: task.id,
            stepNumber: ws.stepNumber,
            agentId: ws.agentId,
            skillId: ws.skillId,
            action: ws.action,
            input: ws.config,
            status: 'pending',
          })),
        });

        // Update command status to processing since workflow steps are queued
        await db.command.update({
          where: { id: command.id },
          data: { status: 'processing' },
        });
      }
    }

    // Create audit log entry
    await db.auditLog.create({
      data: {
        userId: user.userId,
        action: 'command',
        resource: 'commands',
        details: JSON.stringify({
          commandId: command.id,
          taskId: task.id,
          rawCommand: rawCommand.substring(0, 200),
          parsedIntent,
          detectedDept,
          matchedWorkflow,
        }),
      },
    });

    return NextResponse.json({
      commandId: command.id,
      taskId: task.id,
      status: command.status,
      matchedWorkflow,
    });
  } catch (error: unknown) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Commands POST error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}