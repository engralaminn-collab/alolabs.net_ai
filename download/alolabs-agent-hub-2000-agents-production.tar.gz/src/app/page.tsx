'use client'

import { useEffect } from 'react'
import AgentHubShell from '@/components/agent-hub-shell'
import PublicSite from '@/components/public-site'
import { useAppStore } from '@/store/app'

export default function Home() {
  const _init = useAppStore((s) => s._init)
  const showPublicSite = useAppStore((s) => s.showPublicSite)

  useEffect(() => {
    _init()
  }, [_init])

  if (showPublicSite) {
    return <PublicSite />
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <AgentHubShell />
    </div>
  )
}