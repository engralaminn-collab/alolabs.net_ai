'use client'

import { useEffect, useState, useCallback } from 'react'
import { fetchApi, buildQueryString } from '@/lib/api'
import { useToast } from '@/hooks/use-toast'

interface UseDataTableOptions<T> {
  endpoint: string
  defaultParams?: Record<string, string | number | undefined>
}

interface UseDataTableReturn<T> {
  data: T[]
  total: number
  loading: boolean
  error: string
  page: number
  pageSize: number
  search: string
  filters: Record<string, string>
  setPage: (p: number) => void
  setPageSize: (s: number) => void
  setSearch: (s: string) => void
  setFilter: (key: string, val: string) => void
  refresh: () => void
  setFilters: (f: Record<string, string>) => void
}

export function useDataTable<T = any>(opts: UseDataTableOptions<T>): UseDataTableReturn<T> {
  const [data, setData] = useState<T[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [search, setSearch] = useState('')
  const [filters, setFilters] = useState<Record<string, string>>({})

  const { toast } = useToast()

  const refresh = useCallback(() => {
    setLoading(true)
    setError('')
    const params: Record<string, string | number | undefined> = {
      ...opts.defaultParams,
      page,
      limit: pageSize,
      search: search || undefined,
      ...filters,
    }
    const qs = buildQueryString(params)
    fetchApi<{ data: T[]; total: number }>(`${opts.endpoint}${qs}`)
      .then((res) => {
        setData(res.data ?? res.items ?? (Array.isArray(res) ? res : []))
        setTotal(res.total ?? (Array.isArray(res) ? res.length : 0))
      })
      .catch((e: any) => {
        setError(e.message)
      })
      .finally(() => setLoading(false))
  }, [opts.endpoint, page, pageSize, search, filters, opts.defaultParams, toast])

  useEffect(() => {
    const controller = new AbortController()
    const run = async () => {
      await refresh()
    }
    run()
    return () => { controller.abort() }
  }, [refresh])

  return {
    data, total, loading, error, page, pageSize, search, filters,
    setPage, setPageSize, setSearch, setFilter: (k, v) => setFilters((f) => ({ ...f, [k]: v })),
    refresh, setFilters,
  }
}