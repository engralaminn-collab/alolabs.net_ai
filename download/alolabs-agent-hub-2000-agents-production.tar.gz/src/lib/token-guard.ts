import { db } from '@/lib/db'

// ──────────────────────────────────────────────
// Type definitions
// ──────────────────────────────────────────────

export interface TokenBudgetCheck {
  allowed: boolean
  reason?: string
  monthlyUsed: number
  monthlyBudget: number
  dailyUsed: number
  dailyBudget: number
}

// ──────────────────────────────────────────────
// checkTokenBudget
//
// Checks whether adding `estimatedTokens` would exceed
// the company's daily or monthly token budget.
// If the warning threshold is crossed, an Alert is created.
// ──────────────────────────────────────────────

export async function checkTokenBudget(
  companyId: string,
  estimatedTokens: number,
): Promise<TokenBudgetCheck> {
  const budget = await db.tokenBudget.findUnique({
    where: { companyId },
  })

  // If no budget is configured for the company, allow everything
  if (!budget) {
    return {
      allowed: true,
      monthlyUsed: 0,
      monthlyBudget: 0,
      dailyUsed: 0,
      dailyBudget: 0,
    }
  }

  const newMonthlyTotal = budget.monthlyUsed + estimatedTokens
  const newDailyTotal = budget.dailyUsed + estimatedTokens

  // Block if monthly budget exceeded
  if (newMonthlyTotal > budget.monthlyBudget) {
    return {
      allowed: false,
      reason: `Monthly token budget exceeded. Used: ${budget.monthlyUsed}, Budget: ${budget.monthlyBudget}, Requested: ${estimatedTokens}`,
      monthlyUsed: budget.monthlyUsed,
      monthlyBudget: budget.monthlyBudget,
      dailyUsed: budget.dailyUsed,
      dailyBudget: budget.dailyBudget,
    }
  }

  // Block if daily budget exceeded
  if (newDailyTotal > budget.dailyBudget) {
    return {
      allowed: false,
      reason: `Daily token budget exceeded. Used: ${budget.dailyUsed}, Budget: ${budget.dailyBudget}, Requested: ${estimatedTokens}`,
      monthlyUsed: budget.monthlyUsed,
      monthlyBudget: budget.monthlyBudget,
      dailyUsed: budget.dailyUsed,
      dailyBudget: budget.dailyBudget,
    }
  }

  // Check warning thresholds — fire alerts but still allow
  const monthlyRatio = newMonthlyTotal / budget.monthlyBudget
  const dailyRatio = newDailyTotal / budget.dailyBudget

  if (monthlyRatio >= budget.warningThreshold) {
    await createBudgetAlert(
      companyId,
      'monthly',
      budget.monthlyUsed,
      budget.monthlyBudget,
      estimatedTokens,
      monthlyRatio,
    )
  }

  if (dailyRatio >= budget.warningThreshold) {
    await createBudgetAlert(
      companyId,
      'daily',
      budget.dailyUsed,
      budget.dailyBudget,
      estimatedTokens,
      dailyRatio,
    )
  }

  return {
    allowed: true,
    monthlyUsed: budget.monthlyUsed,
    monthlyBudget: budget.monthlyBudget,
    dailyUsed: budget.dailyUsed,
    dailyBudget: budget.dailyBudget,
  }
}

// ──────────────────────────────────────────────
// Helper: create a budget warning alert
// ──────────────────────────────────────────────

async function createBudgetAlert(
  companyId: string,
  period: 'monthly' | 'daily',
  used: number,
  budget: number,
  requested: number,
  ratio: number,
): Promise<void> {
  const alertName = `token_budget_${period}_warning`
  const severity = ratio >= 0.95 ? 'critical' : 'warning'

  // Upsert the alert: update if already firing, create if not
  const existing = await db.alert.findFirst({
    where: {
      name: alertName,
      condition: { contains: companyId },
      isFiring: true,
    },
  })

  if (existing) {
    // Update existing firing alert
    await db.alert.update({
      where: { id: existing.id },
      data: {
        severity,
        lastFiredAt: new Date(),
        condition: JSON.stringify({
          type: 'token_budget_warning',
          companyId,
          period,
          used,
          budget,
          requested,
          ratio: Math.round(ratio * 100) / 100,
          percentage: Math.round(ratio * 100),
        }),
      },
    })
  } else {
    // Create new alert
    await db.alert.create({
      data: {
        name: alertName,
        severity,
        isFiring: true,
        lastFiredAt: new Date(),
        condition: JSON.stringify({
          type: 'token_budget_warning',
          companyId,
          period,
          used,
          budget,
          requested,
          ratio: Math.round(ratio * 100) / 100,
          percentage: Math.round(ratio * 100),
        }),
      },
    })
  }
}