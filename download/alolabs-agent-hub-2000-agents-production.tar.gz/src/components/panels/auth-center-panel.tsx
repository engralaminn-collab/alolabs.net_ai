'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  Shield,
  Key,
  Link2,
  QrCode,
  Lock,
  Plus,
  Trash2,
  Edit,
  CheckCircle,
  XCircle,
  Copy,
  Check,
  AlertTriangle,
  ExternalLink,
} from 'lucide-react'
import { useAppStore } from '@/store/app'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Switch } from '@/components/ui/switch'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'

// ── Types ───────────────────────────────────────────────────────────────────

interface OAuthProvider {
  id: string
  provider: string
  clientId: string
  authorizationUrl: string
  tokenUrl: string
  userInfoUrl: string
  scopes: string
  isActive: boolean
  createdAt: string
  updatedAt: string
}

interface SsoConfig {
  id: string
  provider: string
  metadataUrl: string | null
  entityId: string | null
  callbackUrl: string | null
  isActive: boolean
  config: string
  createdAt: string
  updatedAt: string
}

interface MfaSetup {
  secret: string
  qrCodeUrl: string
  backupCodes: string[]
}

type InlineMessage = { type: 'error' | 'success'; text: string } | null

// ── Component ───────────────────────────────────────────────────────────────

export default function AuthCenterPanel() {
  const user = useAppStore((s) => s.user)
  const token = useAppStore((s) => s.token)

  return (
    <div className="space-y-6 p-6 bg-[#F8FAFC] min-h-screen">
      {/* Header */}
      <div>
        <h2 className="text-xl font-semibold text-[#1E293B]">Auth Center</h2>
        <p className="text-sm text-[#64748B] mt-1">
          Manage MFA, OAuth providers, and SSO configuration for your organization
        </p>
      </div>

      <Tabs defaultValue="mfa" className="space-y-6">
        <TabsList className="bg-white border border-[#E2E8F0]">
          <TabsTrigger
            value="mfa"
            className="data-[state=active]:bg-[#003ABC] data-[state=active]:text-white text-[#64748B]"
          >
            <Shield className="w-4 h-4 mr-2" />
            MFA
          </TabsTrigger>
          <TabsTrigger
            value="oauth"
            className="data-[state=active]:bg-[#003ABC] data-[state=active]:text-white text-[#64748B]"
          >
            <Link2 className="w-4 h-4 mr-2" />
            OAuth Providers
          </TabsTrigger>
          <TabsTrigger
            value="sso"
            className="data-[state=active]:bg-[#003ABC] data-[state=active]:text-white text-[#64748B]"
          >
            <Key className="w-4 h-4 mr-2" />
            SSO Configuration
          </TabsTrigger>
        </TabsList>

        <TabsContent value="mfa">
          <MfaTab userId={user?.id || ''} token={token} />
        </TabsContent>

        <TabsContent value="oauth">
          <OAuthTab token={token} />
        </TabsContent>

        <TabsContent value="sso">
          <SsoTab token={token} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

// ── Inline Message Component ────────────────────────────────────────────────

function InlineMessage({ message }: { message: InlineMessage }) {
  if (!message) return null
  return (
    <div
      className={`flex items-center gap-2 rounded-lg px-4 py-3 text-sm ${
        message.type === 'error'
          ? 'bg-red-50 border border-red-200 text-red-700'
          : 'bg-green-50 border border-green-200 text-green-700'
      }`}
    >
      {message.type === 'error' ? (
        <XCircle className="w-4 h-4 shrink-0" />
      ) : (
        <CheckCircle className="w-4 h-4 shrink-0" />
      )}
      {message.text}
    </div>
  )
}

// ── MFA Tab ─────────────────────────────────────────────────────────────────

function MfaTab({ userId, token }: { userId: string; token: string | null }) {
  const [loading, setLoading] = useState(true)
  const [mfaEnabled, setMfaEnabled] = useState(false)
  const [setupData, setSetupData] = useState<MfaSetup | null>(null)
  const [verifyCode, setVerifyCode] = useState('')
  const [verifying, setVerifying] = useState(false)
  const [disabling, setDisabling] = useState(false)
  const [settingUp, setSettingUp] = useState(false)
  const [message, setMessage] = useState<InlineMessage>(null)
  const [showBackupCodes, setShowBackupCodes] = useState(true)
  const [copied, setCopied] = useState(false)
  const [disableOpen, setDisableOpen] = useState(false)

  // Check MFA status on mount
  useEffect(() => {
    if (!userId || !token) {
      setLoading(false)
      return
    }
    // Fetch user to check MFA status
    fetch('/api/auth/me', {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.user) {
          setMfaEnabled(data.user.otpEnabled || false)
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [userId, token])

  const handleSetup = async () => {
    if (!userId) return
    setSettingUp(true)
    setMessage(null)
    try {
      const res = await fetch('/api/auth/mfa/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ userId }),
      })
      const data = await res.json()
      if (data.error) {
        setMessage({ type: 'error', text: data.error })
      } else {
        setSetupData(data)
        setShowBackupCodes(true)
        setMessage({ type: 'success', text: 'MFA secret generated. Scan the QR code and verify below.' })
      }
    } catch {
      setMessage({ type: 'error', text: 'Failed to set up MFA. Please try again.' })
    } finally {
      setSettingUp(false)
    }
  }

  const handleVerify = async () => {
    if (!userId || !verifyCode.trim()) return
    setVerifying(true)
    setMessage(null)
    try {
      const res = await fetch('/api/auth/mfa/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ userId, code: verifyCode.trim() }),
      })
      const data = await res.json()
      if (data.error) {
        setMessage({ type: 'error', text: data.error })
      } else {
        setMfaEnabled(true)
        setSetupData(null)
        setVerifyCode('')
        setMessage({ type: 'success', text: 'MFA has been enabled successfully!' })
      }
    } catch {
      setMessage({ type: 'error', text: 'Verification failed. Please try again.' })
    } finally {
      setVerifying(false)
    }
  }

  const handleDisable = async () => {
    if (!userId) return
    setDisabling(true)
    setMessage(null)
    try {
      const res = await fetch('/api/auth/mfa/disable', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ userId }),
      })
      const data = await res.json()
      if (data.error) {
        setMessage({ type: 'error', text: data.error })
      } else {
        setMfaEnabled(false)
        setSetupData(null)
        setVerifyCode('')
        setMessage({ type: 'success', text: 'MFA has been disabled.' })
      }
    } catch {
      setMessage({ type: 'error', text: 'Failed to disable MFA.' })
    } finally {
      setDisabling(false)
      setDisableOpen(false)
    }
  }

  const copyToClipboard = async (text: string) => {
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-32 rounded-xl bg-slate-100" />
        <Skeleton className="h-48 rounded-xl bg-slate-100" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <InlineMessage message={message} />

      {/* Status Card */}
      <Card className="border-[#E2E8F0]">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#003ABC]/10 flex items-center justify-center">
                <Shield className="w-5 h-5 text-[#003ABC]" />
              </div>
              <div>
                <CardTitle className="text-[#1E293B] text-base">Multi-Factor Authentication</CardTitle>
                <CardDescription className="text-[#64748B]">
                  Add an extra layer of security to your account
                </CardDescription>
              </div>
            </div>
            <Badge
              variant="outline"
              className={`text-xs px-3 py-1 ${
                mfaEnabled
                  ? 'bg-green-50 text-green-700 border-green-200'
                  : 'bg-slate-50 text-slate-500 border-slate-200'
              }`}
            >
              {mfaEnabled ? (
                <CheckCircle className="w-3 h-3 mr-1" />
              ) : (
                <XCircle className="w-3 h-3 mr-1" />
              )}
              {mfaEnabled ? 'Enabled' : 'Disabled'}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          {mfaEnabled ? (
            <div className="space-y-4">
              <div className="flex items-center gap-3 rounded-lg bg-green-50 border border-green-200 p-4">
                <CheckCircle className="w-5 h-5 text-green-600 shrink-0" />
                <div>
                  <p className="text-sm font-medium text-green-800">MFA is active</p>
                  <p className="text-xs text-green-600 mt-0.5">
                    Your account is protected with two-factor authentication. Use your authenticator
                    app to generate codes when signing in.
                  </p>
                </div>
              </div>
              <Button
                variant="outline"
                onClick={() => setDisableOpen(true)}
                className="border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700"
              >
                <XCircle className="w-4 h-4 mr-2" />
                Disable MFA
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-3 rounded-lg bg-amber-50 border border-amber-200 p-4">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                <div>
                  <p className="text-sm font-medium text-amber-800">MFA is not enabled</p>
                  <p className="text-xs text-amber-600 mt-0.5">
                    We strongly recommend enabling MFA to protect your account from unauthorized
                    access.
                  </p>
                </div>
              </div>
              <Button
                onClick={handleSetup}
                disabled={settingUp || !!setupData}
                className="bg-[#003ABC] hover:bg-[#002A99] text-white"
              >
                <QrCode className="w-4 h-4 mr-2" />
                {settingUp ? 'Setting up...' : 'Enable MFA'}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Setup Section */}
      {setupData && !mfaEnabled && (
        <Card className="border-[#E2E8F0]">
          <CardHeader>
            <CardTitle className="text-[#1E293B] text-base">Setup MFA</CardTitle>
            <CardDescription className="text-[#64748B]">
              Scan this QR code with your authenticator app, or enter the secret key manually.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* QR Code URL */}
            <div className="space-y-2">
              <Label className="text-[#1E293B] text-sm font-medium">QR Code Link</Label>
              <div className="flex items-center gap-2">
                <code className="flex-1 text-xs bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg px-3 py-2.5 font-mono text-[#1E293B] break-all block">
                  {setupData.qrCodeUrl}
                </code>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => copyToClipboard(setupData.qrCodeUrl)}
                  className="shrink-0 border-[#E2E8F0] hover:bg-[#F8FAFC]"
                >
                  {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
              <p className="text-xs text-[#64748B]">
                Open this link in your authenticator app to automatically configure it.
              </p>
            </div>

            <Separator className="bg-[#E2E8F0]" />

            {/* Manual Secret Key */}
            <div className="space-y-2">
              <Label className="text-[#1E293B] text-sm font-medium">Manual Entry Key</Label>
              <div className="flex items-center gap-2">
                <code className="flex-1 text-sm bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg px-3 py-2.5 font-mono text-[#1E293B] text-center tracking-widest">
                  {setupData.secret}
                </code>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => copyToClipboard(setupData.secret)}
                  className="shrink-0 border-[#E2E8F0] hover:bg-[#F8FAFC]"
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-xs text-[#64748B]">
                If you can&apos;t scan the QR code, enter this key manually in your authenticator app.
              </p>
            </div>

            <Separator className="bg-[#E2E8F0]" />

            {/* Backup Codes */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-[#1E293B] text-sm font-medium">Backup Codes</Label>
                {showBackupCodes && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowBackupCodes(false)}
                    className="text-xs text-[#64748B] hover:text-[#1E293B]"
                  >
                    Hide
                  </Button>
                )}
                {!showBackupCodes && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowBackupCodes(true)}
                    className="text-xs text-[#64748B] hover:text-[#1E293B]"
                  >
                    Show
                  </Button>
                )}
              </div>
              {showBackupCodes ? (
                <>
                  <div className="flex items-start gap-3 rounded-lg border border-amber-300 bg-amber-50 p-3 mb-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
                    <p className="text-xs text-amber-700">
                      Save these backup codes in a secure location. Each code can only be used once.
                      They will not be shown again after you leave this page.
                    </p>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {setupData.backupCodes.map((code, i) => (
                      <code
                        key={i}
                        className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-lg px-3 py-2 text-xs font-mono text-center text-[#1E293B] select-all"
                      >
                        {code}
                      </code>
                    ))}
                  </div>
                </>
              ) : (
                <p className="text-xs text-[#94A3B8]">
                  Backup codes are hidden. Click &quot;Show&quot; to reveal them.
                </p>
              )}
            </div>

            <Separator className="bg-[#E2E8F0]" />

            {/* Verification Code */}
            <div className="space-y-3">
              <Label className="text-[#1E293B] text-sm font-medium">Verification Code</Label>
              <p className="text-xs text-[#64748B]">
                Enter the 6-digit code from your authenticator app to complete setup.
              </p>
              <div className="flex items-center gap-3">
                <Input
                  placeholder="000000"
                  value={verifyCode}
                  onChange={(e) => setVerifyCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  className="max-w-[180px] border-[#E2E8F0] focus-visible:ring-[#003ABC] text-center text-lg font-mono tracking-widest"
                  maxLength={6}
                />
                <Button
                  onClick={handleVerify}
                  disabled={verifyCode.length !== 6 || verifying}
                  className="bg-[#003ABC] hover:bg-[#002A99] text-white"
                >
                  {verifying ? 'Verifying...' : 'Verify & Enable'}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Disable Confirmation Dialog */}
      <AlertDialog open={disableOpen} onOpenChange={setDisableOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-[#1E293B]">Disable MFA</AlertDialogTitle>
            <AlertDialogDescription className="text-[#64748B]">
              Are you sure you want to disable multi-factor authentication? This will make your
              account less secure. You will need to set up MFA again to re-enable it.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-[#E2E8F0] text-[#1E293B]">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDisable}
              disabled={disabling}
              className="bg-red-500 hover:bg-red-600 text-white"
            >
              {disabling ? 'Disabling...' : 'Disable MFA'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ── OAuth Tab ───────────────────────────────────────────────────────────────

const OAUTH_PROVIDER_OPTIONS = [
  { value: 'google', label: 'Google' },
  { value: 'github', label: 'GitHub' },
  { value: 'microsoft', label: 'Microsoft' },
  { value: 'okta', label: 'Okta' },
]

function OAuthTab({ token }: { token: string | null }) {
  const [providers, setProviders] = useState<OAuthProvider[]>([])
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState<InlineMessage>(null)

  // Dialog state
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingProvider, setEditingProvider] = useState<OAuthProvider | null>(null)
  const [saving, setSaving] = useState(false)

  // Delete confirmation
  const [deleteTarget, setDeleteTarget] = useState<OAuthProvider | null>(null)
  const [deleting, setDeleting] = useState(false)

  // Form state
  const [form, setForm] = useState({
    provider: '',
    clientId: '',
    clientSecret: '',
    authorizationUrl: '',
    tokenUrl: '',
    userInfoUrl: '',
    scopes: '',
    isActive: true,
  })

  const fetchProviders = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/oauth/providers', {
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await res.json()
      setProviders(data.providers || [])
    } catch {
      // silently handle
    } finally {
      setLoading(false)
    }
  }, [token])

  useEffect(() => {
    fetchProviders()
  }, [fetchProviders])

  const openCreateDialog = () => {
    setEditingProvider(null)
    setForm({
      provider: '',
      clientId: '',
      clientSecret: '',
      authorizationUrl: '',
      tokenUrl: '',
      userInfoUrl: '',
      scopes: '',
      isActive: true,
    })
    setDialogOpen(true)
  }

  const openEditDialog = (provider: OAuthProvider) => {
    setEditingProvider(provider)
    setForm({
      provider: provider.provider,
      clientId: provider.clientId,
      clientSecret: '', // Secret is not returned from API
      authorizationUrl: provider.authorizationUrl,
      tokenUrl: provider.tokenUrl,
      userInfoUrl: provider.userInfoUrl,
      scopes: provider.scopes,
      isActive: provider.isActive,
    })
    setDialogOpen(true)
  }

  const handleSave = async () => {
    setSaving(true)
    setMessage(null)
    try {
      const payload = {
        ...form,
        scopes: form.scopes || '[]',
      }
      const res = await fetch('/api/auth/oauth/providers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (data.error) {
        setMessage({ type: 'error', text: data.error })
      } else {
        setMessage({ type: 'success', text: `OAuth provider "${form.provider}" saved successfully.` })
        setDialogOpen(false)
        fetchProviders()
      }
    } catch {
      setMessage({ type: 'error', text: 'Failed to save OAuth provider.' })
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async () => {
    if (!deleteTarget) return
    setDeleting(true)
    setMessage(null)
    try {
      const res = await fetch('/api/auth/oauth/providers', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ id: deleteTarget.id }),
      })
      const data = await res.json()
      if (data.error) {
        setMessage({ type: 'error', text: data.error })
      } else {
        setMessage({ type: 'success', text: `OAuth provider "${deleteTarget.provider}" deleted.` })
        fetchProviders()
      }
    } catch {
      setMessage({ type: 'error', text: 'Failed to delete OAuth provider.' })
    } finally {
      setDeleting(false)
      setDeleteTarget(null)
    }
  }

  const activeCount = providers.filter((p) => p.isActive).length

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-32 rounded-xl bg-slate-100" />
        <Skeleton className="h-64 rounded-xl bg-slate-100" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <InlineMessage message={message} />

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-[#E2E8F0]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#003ABC]/10 flex items-center justify-center shrink-0">
              <Link2 className="w-5 h-5 text-[#003ABC]" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[#1E293B]">{providers.length}</p>
              <p className="text-xs text-[#64748B]">Total Providers</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-[#E2E8F0]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-50 flex items-center justify-center shrink-0">
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[#1E293B]">{activeCount}</p>
              <p className="text-xs text-[#64748B]">Active</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-[#E2E8F0]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-slate-50 flex items-center justify-center shrink-0">
              <XCircle className="w-5 h-5 text-slate-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[#1E293B]">{providers.length - activeCount}</p>
              <p className="text-xs text-[#64748B]">Inactive</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Providers Table */}
      <Card className="border-[#E2E8F0]">
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <div>
            <CardTitle className="text-[#1E293B] text-base">OAuth Providers</CardTitle>
            <CardDescription className="text-[#64748B]">
              Configure third-party authentication providers
            </CardDescription>
          </div>
          <Button
            onClick={openCreateDialog}
            className="bg-[#003ABC] hover:bg-[#002A99] text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Provider
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-[#E2E8F0] hover:bg-transparent">
                  <TableHead className="text-[#64748B] font-medium">Provider</TableHead>
                  <TableHead className="text-[#64748B] font-medium">Client ID</TableHead>
                  <TableHead className="text-[#64748B] font-medium">Status</TableHead>
                  <TableHead className="text-[#64748B] font-medium">Scopes</TableHead>
                  <TableHead className="text-[#64748B] font-medium">Created</TableHead>
                  <TableHead className="text-[#64748B] font-medium text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {providers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-12 text-[#94A3B8]">
                      <Link2 className="w-8 h-8 mx-auto mb-2 opacity-40" />
                      No OAuth providers configured
                    </TableCell>
                  </TableRow>
                ) : (
                  providers.map((p) => (
                    <TableRow key={p.id} className="border-[#E2E8F0]">
                      <TableCell className="font-medium text-[#1E293B] capitalize">{p.provider}</TableCell>
                      <TableCell>
                        <code className="text-xs bg-[#F8FAFC] px-2 py-0.5 rounded text-[#64748B] font-mono">
                          {p.clientId.slice(0, 12)}...
                        </code>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={`text-xs px-2 py-0.5 ${
                            p.isActive
                              ? 'bg-green-50 text-green-700 border-green-200'
                              : 'bg-slate-50 text-slate-500 border-slate-200'
                          }`}
                        >
                          {p.isActive ? 'Active' : 'Inactive'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-[#64748B] text-sm">
                        {(() => {
                          try {
                            const scopes = JSON.parse(p.scopes)
                            return Array.isArray(scopes) ? (
                              <div className="flex flex-wrap gap-1">
                                {scopes.slice(0, 2).map((s: string) => (
                                  <Badge
                                    key={s}
                                    variant="secondary"
                                    className="text-[10px] px-1.5 py-0 bg-slate-100 text-[#64748B] hover:bg-slate-100"
                                  >
                                    {s}
                                  </Badge>
                                ))}
                                {scopes.length > 2 && (
                                  <Badge
                                    variant="secondary"
                                    className="text-[10px] px-1.5 py-0 bg-[#003ABC]/10 text-[#003ABC] hover:bg-[#003ABC]/10"
                                  >
                                    +{scopes.length - 2}
                                  </Badge>
                                )}
                              </div>
                            ) : (
                              <span className="text-xs text-[#94A3B8]">None</span>
                            )
                          } catch {
                            return <span className="text-xs text-[#94A3B8]">{p.scopes || 'None'}</span>
                          }
                        })()}
                      </TableCell>
                      <TableCell className="text-[#94A3B8] text-sm">
                        {new Date(p.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openEditDialog(p)}
                            className="text-[#64748B] hover:text-[#003ABC] hover:bg-[#003ABC]/5"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setDeleteTarget(p)}
                            className="text-red-400 hover:text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* ── Create / Edit Dialog ─────────────────────────────────────── */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[560px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-[#1E293B]">
              {editingProvider ? 'Edit OAuth Provider' : 'Add OAuth Provider'}
            </DialogTitle>
            <DialogDescription className="text-[#64748B]">
              {editingProvider
                ? `Update the ${editingProvider.provider} OAuth configuration.`
                : 'Configure a new OAuth provider for authentication.'}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Provider */}
            <div className="space-y-2">
              <Label className="text-[#1E293B]">Provider</Label>
              <Select
                value={form.provider}
                onValueChange={(v) => setForm((p) => ({ ...p, provider: v }))}
                disabled={!!editingProvider}
              >
                <SelectTrigger className="border-[#E2E8F0]">
                  <SelectValue placeholder="Select a provider" />
                </SelectTrigger>
                <SelectContent>
                  {OAUTH_PROVIDER_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Client ID */}
            <div className="space-y-2">
              <Label className="text-[#1E293B]">Client ID</Label>
              <Input
                placeholder="your-client-id"
                value={form.clientId}
                onChange={(e) => setForm((p) => ({ ...p, clientId: e.target.value }))}
                className="border-[#E2E8F0] focus-visible:ring-[#003ABC]"
              />
            </div>

            {/* Client Secret */}
            <div className="space-y-2">
              <Label className="text-[#1E293B]">
                Client Secret{' '}
                {editingProvider && (
                  <span className="text-xs font-normal text-[#94A3B8]">(leave blank to keep current)</span>
                )}
              </Label>
              <Input
                type="password"
                placeholder={editingProvider ? '••••••••' : 'your-client-secret'}
                value={form.clientSecret}
                onChange={(e) => setForm((p) => ({ ...p, clientSecret: e.target.value }))}
                className="border-[#E2E8F0] focus-visible:ring-[#003ABC]"
              />
            </div>

            {/* Authorization URL */}
            <div className="space-y-2">
              <Label className="text-[#1E293B]">Authorization URL</Label>
              <Input
                placeholder="https://example.com/oauth/authorize"
                value={form.authorizationUrl}
                onChange={(e) => setForm((p) => ({ ...p, authorizationUrl: e.target.value }))}
                className="border-[#E2E8F0] focus-visible:ring-[#003ABC]"
              />
            </div>

            {/* Token URL */}
            <div className="space-y-2">
              <Label className="text-[#1E293B]">Token URL</Label>
              <Input
                placeholder="https://example.com/oauth/token"
                value={form.tokenUrl}
                onChange={(e) => setForm((p) => ({ ...p, tokenUrl: e.target.value }))}
                className="border-[#E2E8F0] focus-visible:ring-[#003ABC]"
              />
            </div>

            {/* User Info URL */}
            <div className="space-y-2">
              <Label className="text-[#1E293B]">User Info URL</Label>
              <Input
                placeholder="https://example.com/oauth/userinfo"
                value={form.userInfoUrl}
                onChange={(e) => setForm((p) => ({ ...p, userInfoUrl: e.target.value }))}
                className="border-[#E2E8F0] focus-visible:ring-[#003ABC]"
              />
            </div>

            {/* Scopes */}
            <div className="space-y-2">
              <Label className="text-[#1E293B]">Scopes</Label>
              <Input
                placeholder="openid, email, profile"
                value={
                  (() => {
                    try {
                      const parsed = JSON.parse(form.scopes)
                      return Array.isArray(parsed) ? parsed.join(', ') : form.scopes
                    } catch {
                      return form.scopes
                    }
                  })()
                }
                onChange={(e) =>
                  setForm((p) => ({
                    ...p,
                    scopes: JSON.stringify(e.target.value.split(',').map((s) => s.trim()).filter(Boolean)),
                  }))
                }
                className="border-[#E2E8F0] focus-visible:ring-[#003ABC]"
              />
              <p className="text-xs text-[#94A3B8]">Comma-separated list of OAuth scopes</p>
            </div>

            {/* Active Toggle */}
            <div className="flex items-center justify-between rounded-lg border border-[#E2E8F0] p-3">
              <div>
                <Label className="text-[#1E293B] text-sm font-medium">Active</Label>
                <p className="text-xs text-[#94A3B8]">Allow users to authenticate with this provider</p>
              </div>
              <Switch
                checked={form.isActive}
                onCheckedChange={(checked) => setForm((p) => ({ ...p, isActive: checked }))}
                className="data-[state=checked]:bg-[#003ABC]"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDialogOpen(false)}
              className="border-[#E2E8F0] text-[#1E293B]"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={
                !form.provider ||
                !form.clientId ||
                (!editingProvider && !form.clientSecret) ||
                !form.authorizationUrl ||
                !form.tokenUrl ||
                !form.userInfoUrl ||
                saving
              }
              className="bg-[#003ABC] hover:bg-[#002A99] text-white"
            >
              {saving ? 'Saving...' : editingProvider ? 'Update Provider' : 'Create Provider'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Delete Confirmation Dialog ───────────────────────────────── */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-[#1E293B]">Delete OAuth Provider</AlertDialogTitle>
            <AlertDialogDescription className="text-[#64748B]">
              Are you sure you want to delete the &quot;{deleteTarget?.provider}&quot; OAuth provider?
              Users will no longer be able to authenticate with this provider.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-[#E2E8F0] text-[#1E293B]">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleting}
              className="bg-red-500 hover:bg-red-600 text-white"
            >
              {deleting ? 'Deleting...' : 'Delete Provider'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ── SSO Tab ─────────────────────────────────────────────────────────────────

const SSO_PROVIDER_OPTIONS = [
  { value: 'saml', label: 'SAML' },
  { value: 'ldap', label: 'LDAP' },
  { value: 'oidc', label: 'OIDC' },
]

function SsoTab({ token }: { token: string | null }) {
  const [configs, setConfigs] = useState<SsoConfig[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState<string | null>(null)
  const [message, setMessage] = useState<InlineMessage>(null)

  // Form states for each provider type
  const [forms, setForms] = useState<Record<string, {
    provider: string
    metadataUrl: string
    entityId: string
    callbackUrl: string
    isActive: boolean
  }>>({
    saml: { provider: 'saml', metadataUrl: '', entityId: '', callbackUrl: '', isActive: false },
    ldap: { provider: 'ldap', metadataUrl: '', entityId: '', callbackUrl: '', isActive: false },
    oidc: { provider: 'oidc', metadataUrl: '', entityId: '', callbackUrl: '', isActive: false },
  })

  const fetchConfigs = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/sso', {
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await res.json()
      const cfgs: SsoConfig[] = data.configs || []
      setConfigs(cfgs)

      // Pre-fill forms with existing config data
      for (const cfg of cfgs) {
        setForms((prev) => ({
          ...prev,
          [cfg.provider]: {
            provider: cfg.provider,
            metadataUrl: cfg.metadataUrl || '',
            entityId: cfg.entityId || '',
            callbackUrl: cfg.callbackUrl || '',
            isActive: cfg.isActive,
          },
        }))
      }
    } catch {
      // silently handle
    } finally {
      setLoading(false)
    }
  }, [token])

  useEffect(() => {
    fetchConfigs()
  }, [fetchConfigs])

  const handleSave = async (providerType: string) => {
    const formData = forms[providerType]
    if (!formData) return
    setSaving(providerType)
    setMessage(null)
    try {
      const res = await fetch('/api/auth/sso', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(formData),
      })
      const data = await res.json()
      if (data.error) {
        setMessage({ type: 'error', text: data.error })
      } else {
        setMessage({ type: 'success', text: `SSO configuration for ${providerType.toUpperCase()} saved successfully.` })
        fetchConfigs()
      }
    } catch {
      setMessage({ type: 'error', text: `Failed to save ${providerType.toUpperCase()} SSO configuration.` })
    } finally {
      setSaving(null)
    }
  }

  const getProviderStatus = (providerType: string): 'configured' | 'active' | 'inactive' => {
    const cfg = configs.find((c) => c.provider === providerType)
    if (!cfg) return 'inactive'
    return cfg.isActive ? 'active' : 'configured'
  }

  const activeCount = configs.filter((c) => c.isActive).length

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-32 rounded-xl bg-slate-100" />
        <Skeleton className="h-64 rounded-xl bg-slate-100" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <InlineMessage message={message} />

      {/* Overview Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-[#E2E8F0]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#003ABC]/10 flex items-center justify-center shrink-0">
              <Key className="w-5 h-5 text-[#003ABC]" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[#1E293B]">{configs.length}</p>
              <p className="text-xs text-[#64748B]">Configured</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-[#E2E8F0]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-50 flex items-center justify-center shrink-0">
              <Lock className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[#1E293B]">{activeCount}</p>
              <p className="text-xs text-[#64748B]">Active</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-[#E2E8F0]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#FF6A00]/10 flex items-center justify-center shrink-0">
              <Shield className="w-5 h-5 text-[#FF6A00]" />
            </div>
            <div>
              <p className="text-2xl font-bold text-[#1E293B]">{3 - configs.length}</p>
              <p className="text-xs text-[#64748B]">Available</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* SSO Provider Cards */}
      {SSO_PROVIDER_OPTIONS.map((opt) => {
        const status = getProviderStatus(opt.value)
        const formData = forms[opt.value] || forms.saml

        return (
          <Card key={opt.value} className="border-[#E2E8F0]">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#003ABC]/10 flex items-center justify-center">
                    <Lock className="w-5 h-5 text-[#003ABC]" />
                  </div>
                  <div>
                    <CardTitle className="text-[#1E293B] text-base">{opt.label}</CardTitle>
                    <CardDescription className="text-[#64748B]">
                      {opt.value === 'saml' && 'Security Assertion Markup Language for enterprise SSO'}
                      {opt.value === 'ldap' && 'Lightweight Directory Access Protocol for directory auth'}
                      {opt.value === 'oidc' && 'OpenID Connect for modern identity federation'}
                    </CardDescription>
                  </div>
                </div>
                <Badge
                  variant="outline"
                  className={`text-xs px-3 py-1 ${
                    status === 'active'
                      ? 'bg-green-50 text-green-700 border-green-200'
                      : status === 'configured'
                        ? 'bg-amber-50 text-amber-700 border-amber-200'
                        : 'bg-slate-50 text-slate-500 border-slate-200'
                  }`}
                >
                  {status === 'active' && <CheckCircle className="w-3 h-3 mr-1" />}
                  {status === 'configured' && <AlertTriangle className="w-3 h-3 mr-1" />}
                  {status === 'inactive' && <XCircle className="w-3 h-3 mr-1" />}
                  {status === 'active' ? 'Active' : status === 'configured' ? 'Configured' : 'Not Set Up'}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Provider Type (display only) */}
              <div className="space-y-2">
                <Label className="text-[#1E293B] text-sm font-medium">Provider Type</Label>
                <Select value={formData.provider} disabled>
                  <SelectTrigger className="border-[#E2E8F0] bg-[#F8FAFC]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SSO_PROVIDER_OPTIONS.map((s) => (
                      <SelectItem key={s.value} value={s.value}>
                        {s.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Metadata URL */}
              <div className="space-y-2">
                <Label className="text-[#1E293B] text-sm font-medium">Metadata URL</Label>
                <Input
                  placeholder={`https://your-idp.com/${opt.value}/metadata`}
                  value={formData.metadataUrl}
                  onChange={(e) =>
                    setForms((prev) => ({
                      ...prev,
                      [opt.value]: { ...prev[opt.value], metadataUrl: e.target.value },
                    }))
                  }
                  className="border-[#E2E8F0] focus-visible:ring-[#003ABC]"
                />
              </div>

              {/* Entity ID */}
              <div className="space-y-2">
                <Label className="text-[#1E293B] text-sm font-medium">Entity ID</Label>
                <Input
                  placeholder="urn:example:entity:id"
                  value={formData.entityId}
                  onChange={(e) =>
                    setForms((prev) => ({
                      ...prev,
                      [opt.value]: { ...prev[opt.value], entityId: e.target.value },
                    }))
                  }
                  className="border-[#E2E8F0] focus-visible:ring-[#003ABC]"
                />
              </div>

              {/* Callback URL */}
              <div className="space-y-2">
                <Label className="text-[#1E293B] text-sm font-medium">Callback URL</Label>
                <Input
                  placeholder={`https://your-app.com/api/auth/${opt.value}/callback`}
                  value={formData.callbackUrl}
                  onChange={(e) =>
                    setForms((prev) => ({
                      ...prev,
                      [opt.value]: { ...prev[opt.value], callbackUrl: e.target.value },
                    }))
                  }
                  className="border-[#E2E8F0] focus-visible:ring-[#003ABC]"
                />
              </div>

              {/* Active Toggle */}
              <div className="flex items-center justify-between rounded-lg border border-[#E2E8F0] p-3">
                <div>
                  <Label className="text-[#1E293B] text-sm font-medium">Active</Label>
                  <p className="text-xs text-[#94A3B8]">
                    Enable this SSO provider for authentication
                  </p>
                </div>
                <Switch
                  checked={formData.isActive}
                  onCheckedChange={(checked) =>
                    setForms((prev) => ({
                      ...prev,
                      [opt.value]: { ...prev[opt.value], isActive: checked },
                    }))
                  }
                  className="data-[state=checked]:bg-[#003ABC]"
                />
              </div>

              {/* Save Button */}
              <div className="flex justify-end pt-2">
                <Button
                  onClick={() => handleSave(opt.value)}
                  disabled={saving === opt.value}
                  className="bg-[#003ABC] hover:bg-[#002A99] text-white"
                >
                  {saving === opt.value ? 'Saving...' : 'Save Configuration'}
                </Button>
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}