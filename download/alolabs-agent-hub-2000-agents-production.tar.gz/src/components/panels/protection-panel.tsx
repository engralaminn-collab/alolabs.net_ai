'use client'

import { useEffect, useState } from 'react'
import { Shield, ShieldCheck, ShieldX } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'

interface ProtectionStats {
  total: number
  blocked: number
  allowed: number
  blockRate: string
}

interface ProtectionLog {
  id: string
  actionType: string
  blocked: boolean
  reason: string
  createdAt: string
}

export default function ProtectionPanel() {
  const [stats, setStats] = useState<ProtectionStats | null>(null)
  const [logs, setLogs] = useState<ProtectionLog[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/protection')
      .then((r) => r.json())
      .then((res) => {
        setStats(res.stats)
        setLogs(res.logs || [])
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <Skeleton className="h-8 w-48 bg-cosmic/30" />
        <div className="grid grid-cols-2 gap-4">
          {Array.from({ length: 2 }).map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-lg bg-cosmic/20" />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 p-6">
      <h2 className="text-xl font-semibold text-soft-white">Protection Mode</h2>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { icon: Shield, label: 'Total Checked', value: stats?.total ?? 0, color: 'text-neon' },
          { icon: ShieldX, label: 'Blocked', value: stats?.blocked ?? 0, color: 'text-danger' },
          { icon: ShieldCheck, label: 'Allowed', value: stats?.allowed ?? 0, color: 'text-success' },
          { icon: Shield, label: 'Block Rate', value: stats?.total ? `${Math.round(((stats?.blocked ?? 0) / stats.total) * 100)}%` : '0%', color: 'text-warning' },
        ].map((card) => {
          const Icon = card.icon
          return (
            <div key={card.label} className="glass-card cosmic-lift p-4">
              <div className="flex items-center gap-2 mb-2">
                <Icon className="w-4 h-4 text-muted-slate" />
                <span className="text-xs text-muted-slate">{card.label}</span>
              </div>
              <p className={`text-2xl font-bold ${card.color}`}>{card.value}</p>
            </div>
          )
        })}
      </div>

      <div className="glass-card overflow-hidden">
        <div className="p-4 border-b border-border/30">
          <h3 className="text-sm font-semibold text-soft-white">Recent Protection Logs</h3>
        </div>
        <div className="max-h-96 overflow-y-auto divide-y divide-border/20">
          {logs.length === 0 ? (
            <p className="text-center text-muted-slate text-sm py-12">No protection logs</p>
          ) : (
            logs.map((log) => (
              <div key={log.id} className="p-4 flex items-start justify-between gap-3 hover:bg-white/5">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge
                      variant="secondary"
                      className={`text-[10px] py-0 ${log.blocked ? 'bg-danger/20 text-danger' : 'bg-success/20 text-success'}`}
                    >
                      {log.blocked ? 'BLOCKED' : 'ALLOWED'}
                    </Badge>
                    <span className="text-xs font-medium text-soft-white">{log.actionType}</span>
                  </div>
                  <p className="text-xs text-muted-slate truncate">{log.reason}</p>
                </div>
                <span className="text-[10px] text-muted-slate flex-shrink-0">{new Date(log.createdAt).toLocaleString()}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}