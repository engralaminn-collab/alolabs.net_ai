'use client'

import { useEffect, useState } from 'react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

interface AuditLog {
  id: string
  action: string
  resource: string
  details: string
  createdAt: string
  user?: { name: string; email: string }
}

export default function AuditLogsPanel() {
  const [logs, setLogs] = useState<AuditLog[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(true)
  const limit = 20

  useEffect(() => {
    let cancelled = false
    // eslint-disable-next-line react-hooks/set-state-in-effect -- data fetching
    setLoading(true)
    fetch(`/api/audit-logs?page=${page}&limit=${limit}`)
      .then((r) => r.json())
      .then((res) => {
        if (!cancelled) {
          setLogs(res.logs || [])
          setTotal(res.pagination?.total || 0)
        }
      })
      .catch(() => {})
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [page])

  const totalPages = Math.ceil(total / limit)

  const actionColor = (action: string) => {
    switch (action) {
      case 'create': return 'bg-success/20 text-success'
      case 'update': return 'bg-electric/20 text-electric'
      case 'delete': return 'bg-danger/20 text-danger'
      default: return 'bg-nebula/20 text-nebula'
    }
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-soft-white">Audit Logs</h2>
        <span className="text-sm text-muted-slate">{total} entries</span>
      </div>

      {loading ? (
        <Skeleton className="h-96 rounded-lg bg-cosmic/20" />
      ) : (
        <>
          <div className="glass-card overflow-hidden">
            <Table className="text-sm">
              <TableHeader>
                <TableRow className="bg-cosmic/50 hover:bg-cosmic/50 border-border/30">
                  <TableHead className="text-muted-slate">Timestamp</TableHead>
                  <TableHead className="text-muted-slate hidden md:table-cell">User</TableHead>
                  <TableHead className="text-muted-slate">Action</TableHead>
                  <TableHead className="text-muted-slate">Resource</TableHead>
                  <TableHead className="text-muted-slate hidden lg:table-cell">Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-slate py-12">No audit logs</TableCell>
                  </TableRow>
                ) : (
                  logs.map((log) => (
                    <TableRow key={log.id} className="border-border/20 hover:bg-white/5">
                      <TableCell className="text-muted-slate text-xs whitespace-nowrap">
                        {new Date(log.createdAt).toLocaleString()}
                      </TableCell>
                      <TableCell className="text-soft-white hidden md:table-cell">{log.user?.name || 'System'}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={`text-[10px] py-0 ${actionColor(log.action)}`}>
                          {log.action}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-soft-white">{log.resource}</TableCell>
                      <TableCell className="text-muted-slate text-xs max-w-xs truncate hidden lg:table-cell">
                        {log.details}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 && (
            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-slate">Page {page} of {totalPages}</p>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="h-8 w-8" disabled={page <= 1} onClick={() => setPage(page - 1)}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8" disabled={page >= totalPages} onClick={() => setPage(page + 1)}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}