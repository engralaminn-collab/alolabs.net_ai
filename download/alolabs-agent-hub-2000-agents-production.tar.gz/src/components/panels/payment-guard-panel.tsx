'use client'

import { useEffect, useState } from 'react'
import { CreditCard, Ban, RefreshCw } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

interface PaymentStats {
  total: number
  blocked: number
  allowed: number
  blockRate: string
}

interface PaymentLog {
  id: string
  apiName: string
  blocked: boolean
  replacementUsed: boolean
  replacementName: string | null
  reason: string
  createdAt: string
}

export default function PaymentGuardPanel() {
  const [stats, setStats] = useState<PaymentStats | null>(null)
  const [logs, setLogs] = useState<PaymentLog[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/payment-guard')
      .then((r) => r.json())
      .then((res) => {
        setStats(res.stats)
        setLogs(res.logs || [])
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <Skeleton className="h-8 w-48 bg-cosmic/30" />
        <div className="grid grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-lg bg-cosmic/20" />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 p-6">
      <h2 className="text-xl font-semibold text-soft-white">Payment Guard</h2>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {[
          { icon: CreditCard, label: 'Total Blocked', value: stats?.blocked ?? 0, color: 'text-danger' },
          { icon: RefreshCw, label: 'Replacements Found', value: (stats as any)?.replacementsFound ?? 0, color: 'text-success' },
          { icon: Ban, label: 'Block Rate', value: stats?.total ? `${Math.round(((stats?.blocked ?? 0) / stats.total) * 100)}%` : '0%', color: 'text-warning' },
        ].map((card) => {
          const Icon = card.icon
          return (
            <div key={card.label} className="glass-card cosmic-lift p-4">
              <div className="flex items-center gap-2 mb-2">
                <Icon className="w-4 h-4 text-muted-slate" />
                <span className="text-xs text-muted-slate">{card.label}</span>
              </div>
              <p className={`text-2xl font-bold ${card.color}`}>{card.value}</p>
            </div>
          )
        })}
      </div>

      <div className="glass-card overflow-hidden">
        <Table className="text-sm">
          <TableHeader>
            <TableRow className="bg-cosmic/50 hover:bg-cosmic/50 border-border/30">
              <TableHead className="text-muted-slate">API Name</TableHead>
              <TableHead className="text-muted-slate">Blocked</TableHead>
              <TableHead className="text-muted-slate hidden sm:table-cell">Replacement Used</TableHead>
              <TableHead className="text-muted-slate hidden md:table-cell">Date</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {logs.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center text-muted-slate py-12">No payment guard logs</TableCell>
              </TableRow>
            ) : (
              logs.map((log) => (
                <TableRow key={log.id} className="border-border/20 hover:bg-white/5">
                  <TableCell className="text-soft-white font-medium">{log.apiName}</TableCell>
                  <TableCell>
                    <Badge
                      variant="secondary"
                      className={`text-[10px] py-0 ${log.blocked ? 'bg-danger/20 text-danger' : 'bg-success/20 text-success'}`}
                    >
                      {log.blocked ? 'Blocked' : 'Allowed'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-slate text-xs hidden sm:table-cell">{log.replacementName || '—'}</TableCell>
                  <TableCell className="text-muted-slate text-xs hidden md:table-cell">
                    {new Date(log.createdAt).toLocaleDateString()}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}