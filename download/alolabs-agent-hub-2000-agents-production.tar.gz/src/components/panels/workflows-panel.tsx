'use client'

import { useEffect, useState } from 'react'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { GitBranch } from 'lucide-react'

interface Workflow {
  id: string
  name: string
  slug: string
  description: string | null
  status: string
  stepCount: number
  createdAt: string
}

export default function WorkflowsPanel() {
  const [workflows, setWorkflows] = useState<Workflow[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/workflows')
      .then((r) => r.json())
      .then((res) => setWorkflows(res.data || []))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <Skeleton className="h-8 w-48 bg-cosmic/30" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-36 rounded-lg bg-cosmic/20" />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-soft-white">Workflows</h2>
        <span className="text-sm text-muted-slate">{workflows.length} workflows</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {workflows.map((wf) => (
          <div key={wf.id} className="glass-card cosmic-lift p-4 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-electric/20 flex items-center justify-center flex-shrink-0">
                  <GitBranch className="w-4 h-4 text-electric" />
                </div>
                <h3 className="text-sm font-semibold text-soft-white truncate">{wf.name}</h3>
              </div>
              <Badge
                variant={wf.status === 'active' ? 'default' : 'secondary'}
                className={`text-[10px] py-0 flex-shrink-0 ${wf.status === 'active' ? 'bg-success/20 text-success' : 'bg-muted text-muted-slate'}`}
              >
                {wf.status}
              </Badge>
            </div>
            {wf.description && (
              <p className="text-xs text-muted-slate line-clamp-2">{wf.description}</p>
            )}
            <div className="flex items-center gap-3 text-xs text-muted-slate">
              <span>{wf.stepCount} steps</span>
              <span>·</span>
              <span>{new Date(wf.createdAt).toLocaleDateString()}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}