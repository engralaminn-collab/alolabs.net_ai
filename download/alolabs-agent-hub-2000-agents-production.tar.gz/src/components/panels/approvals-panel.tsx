'use client'

import { useEffect, useState, useRef, useCallback } from 'react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { CheckCircle, XCircle } from 'lucide-react'
import { toast } from 'sonner'

interface Approval {
  id: string
  type: string
  title: string
  status: string
  createdAt: string
  user?: { name: string; email: string }
}

export default function ApprovalsPanel() {
  const [approvals, setApprovals] = useState<Approval[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState('pending')
  const [page, setPage] = useState(1)
  const [refreshKey, setRefreshKey] = useState(0)
  const limit = 20

  useEffect(() => {
    let cancelled = false
    setLoading(true)
    const params = new URLSearchParams({ page: String(page), limit: String(limit) })
    if (tab !== 'all') params.set('status', tab)
    fetch(`/api/approvals?${params}`)
      .then((r) => r.json())
      .then((res) => {
        if (!cancelled) {
          setApprovals(res.data || [])
          setTotal(res.total || 0)
        }
      })
      .catch(() => {})
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [tab, page, refreshKey])

  const handleAction = useCallback(async (approvalId: string, action: 'approve' | 'reject') => {
    try {
      const res = await fetch(`/api/approvals?action=${action}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ approvalId }),
      })
      if (!res.ok) throw new Error()
      toast.success(`Approval ${action}d`)
      setRefreshKey((k) => k + 1)
    } catch {
      toast.error('Action failed')
    }
  }, [])

  const tabs = [
    { id: 'all', label: 'All' },
    { id: 'pending', label: 'Pending' },
    { id: 'approved', label: 'Approved' },
    { id: 'rejected', label: 'Rejected' },
  ]

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h2 className="text-xl font-semibold text-soft-white">Approval Queue</h2>
        <span className="text-sm text-muted-slate">{total} total</span>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2">
        {tabs.map((t) => (
          <Button
            key={t.id}
            variant={tab === t.id ? 'default' : 'ghost'}
            size="sm"
            onClick={() => { setTab(t.id); setPage(1) }}
            className={tab === t.id ? 'bg-electric/20 text-neon hover:bg-electric/30' : 'text-muted-slate hover:text-soft-white'}
          >
            {t.label}
          </Button>
        ))}
      </div>

      {loading ? (
        <Skeleton className="h-96 rounded-lg bg-cosmic/20" />
      ) : (
        <div className="space-y-3">
          {approvals.length === 0 ? (
            <div className="text-center text-muted-slate text-sm py-12">No approvals found</div>
          ) : (
            approvals.map((approval) => (
              <div key={approval.id} className="glass-card p-4 flex items-center justify-between gap-4">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="secondary" className="text-[10px] py-0 bg-electric/20 text-electric">{approval.type}</Badge>
                    <span className="text-sm font-medium text-soft-white truncate">{approval.title}</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-muted-slate">
                    <span>{approval.user?.name || 'System'}</span>
                    <span>·</span>
                    <span>{new Date(approval.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  {approval.status === 'pending' ? (
                    <>
                      <Button size="sm" className="h-7 bg-success/20 text-success hover:bg-success/30" onClick={() => handleAction(approval.id, 'approve')}>
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Approve
                      </Button>
                      <Button size="sm" className="h-7 bg-danger/20 text-danger hover:bg-danger/30" onClick={() => handleAction(approval.id, 'reject')}>
                        <XCircle className="w-3 h-3 mr-1" />
                        Reject
                      </Button>
                    </>
                  ) : (
                    <Badge
                      variant="secondary"
                      className={`text-[10px] py-0 ${approval.status === 'approved' ? 'bg-success/20 text-success' : 'bg-danger/20 text-danger'}`}
                    >
                      {approval.status}
                    </Badge>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  )
}