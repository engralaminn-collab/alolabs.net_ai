'use client'

import { useEffect, useState, useRef } from 'react'
import { Gauge, Zap, Target, Shield, BarChart2, Clock, TrendingUp, Award, Search, Filter } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from 'recharts'

// ─── Types ───────────────────────────────────────────────────────────────────

interface ProductivityReportItem {
  id: string
  taskId: string | null
  speedScore: number
  qualityScore: number
  reuseScore: number
  errorScore: number
  finalProductivityScore: number
  recommendations: string
  createdAt: string
}

interface PerformanceScore {
  id: string
  agentId: string
  period: string
  successRate: number
  errorRate: number
  avgRuntimeMs: number
  outputQualityScore: number
  userCorrectionCount: number
  blockedActionCount: number
  approvalRequiredCount: number
  productivityScore: number
  calculatedAt: string
}

interface ReportData {
  summary: {
    totalReports: number
    averageScores: {
      speed: number
      quality: number
      reuse: number
      error: number
      overall: number
    }
    averagePerformance: {
      successRate: number
      errorRate: number
      avgRuntimeMs: number
      outputQuality: number
      productivityScore: number
      totalCorrections: number
      totalBlockedActions: number
      totalApprovalRequired: number
    }
  }
  productivityReports: ProductivityReportItem[]
  performanceScores: PerformanceScore[]
  topPerformers: PerformanceScore[]
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const round2 = (n: number) => Math.round((n || 0) * 100) / 100

// ─── Component ───────────────────────────────────────────────────────────────

export default function ProductivityPanel() {
  const [report, setReport] = useState<ReportData | null>(null)
  const [loading, setLoading] = useState(true)
  const [searchInput, setSearchInput] = useState('')
  const [search, setSearch] = useState('')
  const [scoreFilter, setScoreFilter] = useState('')

  // Debounced search
  const searchTimerRef = useRef<ReturnType<typeof setTimeout>>(null)
  useEffect(() => {
    if (searchTimerRef.current) clearTimeout(searchTimerRef.current)
    searchTimerRef.current = setTimeout(() => {
      setSearch(searchInput)
    }, 300)
    return () => { if (searchTimerRef.current) clearTimeout(searchTimerRef.current) }
  }, [searchInput])

  useEffect(() => {
    let cancelled = false
    // eslint-disable-next-line react-hooks/set-state-in-effect -- initial data loading
    setLoading(true)
    fetch('/api/productivity/report')
      .then((r) => r.json())
      .then((res) => {
        if (!cancelled) setReport(res)
      })
      .catch(() => {})
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [])

  // Client-side filtering for reports table
  const filteredReports = (report?.productivityReports || []).filter((r) => {
    const matchSearch = !search || (r.taskId || '').toLowerCase().includes(search.toLowerCase())
    const matchScore = !scoreFilter || (
      scoreFilter === 'high' ? r.finalProductivityScore >= 70 :
      scoreFilter === 'medium' ? r.finalProductivityScore >= 40 && r.finalProductivityScore < 70 :
      r.finalProductivityScore < 40
    )
    return matchSearch && matchScore
  })

  // Client-side filtering for top performers
  const filteredPerformers = (report?.topPerformers || []).filter((p) => {
    const matchSearch = !search || p.agentId.toLowerCase().includes(search.toLowerCase())
    return matchSearch
  })

  const avg = report?.summary?.averageScores
  const perf = report?.summary?.averagePerformance
  const overallScore = Math.round(avg?.overall || 0)

  const scores = [
    { icon: Zap, label: 'Speed Score', value: Math.round(avg?.speed || 0), desc: 'Task completion velocity', color: 'text-neon', barColor: 'from-neon/60 to-neon' },
    { icon: Target, label: 'Quality Score', value: Math.round(avg?.quality || 0), desc: 'Output accuracy rating', color: 'text-success', barColor: 'from-success/60 to-success' },
    { icon: Gauge, label: 'Reuse Score', value: Math.round(avg?.reuse || 0), desc: 'Skill/knowledge reuse rate', color: 'text-electric', barColor: 'from-electric/60 to-electric' },
    { icon: Shield, label: 'Error Score', value: Math.round(avg?.error || 0), desc: 'Error-free completion rate', color: 'text-nebula', barColor: 'from-nebula/60 to-nebula' },
  ]

  // Radar chart data
  const radarData = [
    { metric: 'Speed', value: Math.round(avg?.speed || 0) },
    { metric: 'Quality', value: Math.round(avg?.quality || 0) },
    { metric: 'Reuse', value: Math.round(avg?.reuse || 0) },
    { metric: 'Error Free', value: Math.round(avg?.error || 0) },
    { metric: 'Success Rate', value: Math.round((perf?.successRate || 0) * 100) },
    { metric: 'Output Quality', value: Math.round((perf?.outputQuality || 0) * 100) },
  ]

  // Trend data from reports (group by date)
  const reportsByDate: Record<string, { sum: number; count: number }> = {}
  ;(report?.productivityReports || []).forEach((r) => {
    const date = r.createdAt?.slice(0, 10) || 'unknown'
    if (!reportsByDate[date]) reportsByDate[date] = { sum: 0, count: 0 }
    reportsByDate[date].sum += r.finalProductivityScore
    reportsByDate[date].count += 1
  })
  const trendData = Object.entries(reportsByDate)
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(-20)
    .map(([date, d]) => ({ date, score: round2(d.sum / d.count) }))

  // Performance stats
  const perfCards = [
    { icon: TrendingUp, label: 'Success Rate', value: `${round2((perf?.successRate || 0) * 100)}%`, color: 'text-success' },
    { icon: Clock, label: 'Avg Runtime', value: `${perf?.avgRuntimeMs || 0}ms`, color: 'text-electric' },
    { icon: BarChart2, label: 'Output Quality', value: `${round2((perf?.outputQuality || 0) * 100)}%`, color: 'text-neon' },
    { icon: Award, label: 'Total Reports', value: report?.summary?.totalReports?.toLocaleString() || '0', color: 'text-nebula' },
  ]

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <Skeleton className="h-8 w-48 bg-cosmic/30" />
        <div className="grid grid-cols-5 gap-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-lg bg-cosmic/20" />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center gap-3">
        <Gauge className="w-6 h-6 text-neon" />
        <h2 className="text-xl font-semibold text-soft-white">Productivity Center</h2>
      </div>

      {/* Overall score + performance cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
        <div className="glass-card p-6 flex flex-col items-center justify-center">
          <p className="text-xs text-muted-slate mb-1">Overall</p>
          <div className="w-20 h-20 rounded-full border-4 border-neon/30 flex items-center justify-center mb-2">
            <span className="text-2xl font-bold text-neon">{overallScore}</span>
          </div>
          <p className="text-[10px] text-muted-slate">Productivity Score</p>
        </div>
        {perfCards.map((card) => {
          const Icon = card.icon
          return (
            <div key={card.label} className="glass-card cosmic-lift p-4">
              <div className="flex items-center gap-2 mb-2">
                <Icon className="w-4 h-4 text-muted-slate" />
                <span className="text-xs text-muted-slate">{card.label}</span>
              </div>
              <p className={`text-2xl font-bold ${card.color}`}>{card.value}</p>
            </div>
          )
        })}
      </div>

      {/* Score bars */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {scores.map((score) => {
          const Icon = score.icon
          return (
            <div key={score.label} className="glass-card cosmic-lift p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Icon className="w-4 h-4 text-muted-slate" />
                  <span className="text-xs text-muted-slate">{score.label}</span>
                </div>
                <span className={`text-lg font-bold ${score.color}`}>{score.value}%</span>
              </div>
              <div className="h-2 bg-cosmic/30 rounded-full overflow-hidden">
                <div
                  className={`h-full bg-gradient-to-r ${score.barColor} rounded-full transition-all`}
                  style={{ width: `${score.value}%` }}
                />
              </div>
              <p className="text-[10px] text-muted-slate">{score.desc}</p>
            </div>
          )
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Trend Chart */}
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-soft-white">Productivity Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-56">
              {trendData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trendData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(37,99,235,0.1)" />
                    <XAxis dataKey="date" tick={{ fill: '#94A3B8', fontSize: 10 }} />
                    <YAxis tick={{ fill: '#94A3B8', fontSize: 10 }} domain={[0, 100]} />
                    <Tooltip contentStyle={{ background: '#0B1B4D', border: '1px solid rgba(37,99,235,0.3)', borderRadius: 8, fontSize: 12 }} />
                    <Line type="monotone" dataKey="score" stroke="#22D3EE" strokeWidth={2} dot={{ fill: '#22D3EE', r: 3 }} name="Avg Score" />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-muted-slate text-sm">No trend data yet</div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Radar Chart */}
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-soft-white">Score Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radarData}>
                  <PolarGrid stroke="rgba(37,99,235,0.2)" />
                  <PolarAngleAxis dataKey="metric" tick={{ fill: '#94A3B8', fontSize: 10 }} />
                  <PolarRadiusAxis tick={{ fill: '#94A3B8', fontSize: 9 }} domain={[0, 100]} />
                  <Radar name="Score" dataKey="value" stroke="#22D3EE" fill="#22D3EE" fillOpacity={0.15} strokeWidth={2} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search / Filter Bar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-slate" />
          <Input
            placeholder="Search by agent ID or task ID..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="pl-9 bg-cosmic/20 border-border/50 text-soft-white placeholder:text-muted-slate"
          />
        </div>
        <Select value={scoreFilter || '__all__'} onValueChange={(v) => setScoreFilter(v === '__all__' ? '' : v)}>
          <SelectTrigger className="w-[160px] bg-cosmic/20 border-border/50 text-soft-white text-xs">
            <Filter className="w-3.5 h-3.5 mr-1 text-muted-slate" />
            <SelectValue placeholder="All Scores" />
          </SelectTrigger>
          <SelectContent className="bg-[#0B1B4D] border-border/50">
            <SelectItem value="__all__" className="text-soft-white">All Scores</SelectItem>
            <SelectItem value="high" className="text-soft-white">High (≥70)</SelectItem>
            <SelectItem value="medium" className="text-soft-white">Medium (40-69)</SelectItem>
            <SelectItem value="low" className="text-soft-white">Low (&lt;40)</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Top Performers */}
      <Card className="glass-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-soft-white">Agent Productivity Rankings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="max-h-72 overflow-y-auto custom-scrollbar">
            <Table className="text-sm">
              <TableHeader>
                <TableRow className="bg-cosmic/50 hover:bg-cosmic/50 border-border/30">
                  <TableHead className="text-muted-slate w-12">#</TableHead>
                  <TableHead className="text-muted-slate">Agent ID</TableHead>
                  <TableHead className="text-muted-slate hidden sm:table-cell">Period</TableHead>
                  <TableHead className="text-muted-slate">Success Rate</TableHead>
                  <TableHead className="text-muted-slate hidden md:table-cell">Avg Runtime</TableHead>
                  <TableHead className="text-muted-slate">Productivity</TableHead>
                  <TableHead className="text-muted-slate hidden lg:table-cell">Quality</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPerformers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-slate py-8">No performance data found</TableCell>
                  </TableRow>
                ) : (
                  filteredPerformers.map((p, i) => (
                    <TableRow key={p.id} className="border-border/20 hover:bg-white/5">
                      <TableCell className="text-muted-slate font-bold">{i + 1}</TableCell>
                      <TableCell className="font-mono text-xs text-electric">{p.agentId.slice(0, 12)}</TableCell>
                      <TableCell className="text-muted-slate text-xs hidden sm:table-cell capitalize">{p.period}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="text-[10px] py-0 bg-success/20 text-success">
                          {round2(p.successRate * 100)}%
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-slate text-xs hidden md:table-cell">{p.avgRuntimeMs}ms</TableCell>
                      <TableCell>
                        <span className="text-sm font-bold text-neon">{round2(p.productivityScore * 100)}%</span>
                      </TableCell>
                      <TableCell className="text-muted-slate text-xs hidden lg:table-cell">{round2(p.outputQualityScore * 100)}%</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Recent Reports */}
      <Card className="glass-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-soft-white">Recent Productivity Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="max-h-72 overflow-y-auto custom-scrollbar">
            <Table className="text-sm">
              <TableHeader>
                <TableRow className="bg-cosmic/50 hover:bg-cosmic/50 border-border/30">
                  <TableHead className="text-muted-slate">Task</TableHead>
                  <TableHead className="text-muted-slate">Speed</TableHead>
                  <TableHead className="text-muted-slate hidden sm:table-cell">Quality</TableHead>
                  <TableHead className="text-muted-slate hidden md:table-cell">Reuse</TableHead>
                  <TableHead className="text-muted-slate hidden md:table-cell">Error</TableHead>
                  <TableHead className="text-muted-slate">Final</TableHead>
                  <TableHead className="text-muted-slate hidden lg:table-cell">Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredReports.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-slate py-8">No reports found</TableCell>
                  </TableRow>
                ) : (
                  filteredReports.slice(0, 50).map((r) => (
                    <TableRow key={r.id} className="border-border/20 hover:bg-white/5">
                      <TableCell className="font-mono text-[10px] text-electric">{r.taskId ? r.taskId.slice(0, 8) : '—'}</TableCell>
                      <TableCell className="text-xs text-soft-white">{round2(r.speedScore)}</TableCell>
                      <TableCell className="text-xs text-soft-white hidden sm:table-cell">{round2(r.qualityScore)}</TableCell>
                      <TableCell className="text-xs text-soft-white hidden md:table-cell">{round2(r.reuseScore)}</TableCell>
                      <TableCell className="text-xs text-soft-white hidden md:table-cell">{round2(r.errorScore)}</TableCell>
                      <TableCell>
                        <span className={`text-sm font-bold ${r.finalProductivityScore >= 70 ? 'text-success' : r.finalProductivityScore >= 40 ? 'text-warning' : 'text-danger'}`}>
                          {round2(r.finalProductivityScore)}
                        </span>
                      </TableCell>
                      <TableCell className="text-muted-slate text-xs hidden lg:table-cell">{new Date(r.createdAt).toLocaleDateString()}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}