'use client'

import { useEffect, useState } from 'react'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Button } from '@/components/ui/button'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

interface Task {
  id: string
  title: string
  status: string
  priority: string
  createdAt: string
  agent?: { name: string; agentId: string }
  _count?: { steps: number; outputs: number }
}

export default function TasksPanel() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(true)
  const limit = 20

  useEffect(() => {
    let cancelled = false
    // eslint-disable-next-line react-hooks/set-state-in-effect -- data fetching
    setLoading(true)
    fetch(`/api/tasks?page=${page}&limit=${limit}`)
      .then((r) => r.json())
      .then((res) => {
        if (!cancelled) {
          setTasks(res.logs || [])
          setTotal(res.pagination?.total || 0)
        }
      })
      .catch(() => {})
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [page])

  const totalPages = Math.ceil(total / limit)

  const statusColor = (s: string) => {
    switch (s) {
      case 'completed': return 'bg-success/20 text-success'
      case 'failed': return 'bg-danger/20 text-danger'
      case 'in_progress': return 'bg-electric/20 text-electric'
      case 'pending': return 'bg-warning/20 text-warning'
      default: return 'bg-muted text-muted-slate'
    }
  }

  const priorityColor = (p: string) => {
    switch (p) {
      case 'high': return 'bg-danger/20 text-danger'
      case 'medium': return 'bg-warning/20 text-warning'
      case 'low': return 'bg-success/20 text-success'
      default: return 'bg-muted text-muted-slate'
    }
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-soft-white">Tasks</h2>
        <span className="text-sm text-muted-slate">{total} total tasks</span>
      </div>

      {loading ? (
        <Skeleton className="h-96 rounded-lg bg-cosmic/20" />
      ) : (
        <>
          <div className="glass-card overflow-hidden">
            <Table className="text-sm">
              <TableHeader>
                <TableRow className="bg-cosmic/50 hover:bg-cosmic/50 border-border/30">
                  <TableHead className="text-muted-slate">Title</TableHead>
                  <TableHead className="text-muted-slate hidden md:table-cell">Agent</TableHead>
                  <TableHead className="text-muted-slate">Status</TableHead>
                  <TableHead className="text-muted-slate hidden sm:table-cell">Priority</TableHead>
                  <TableHead className="text-muted-slate hidden lg:table-cell">Created</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {tasks.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-slate py-12">No tasks found</TableCell>
                  </TableRow>
                ) : (
                  tasks.map((task) => (
                    <TableRow key={task.id} className="border-border/20 hover:bg-white/5">
                      <TableCell className="text-soft-white font-medium max-w-xs truncate">{task.title}</TableCell>
                      <TableCell className="text-muted-slate hidden md:table-cell">{task.agent?.name || '—'}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={`text-[10px] py-0 ${statusColor(task.status)}`}>
                          {task.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell">
                        {task.priority ? (
                          <Badge variant="secondary" className={`text-[10px] py-0 ${priorityColor(task.priority)}`}>
                            {task.priority}
                          </Badge>
                        ) : (
                          <span className="text-muted-slate text-xs">—</span>
                        )}
                      </TableCell>
                      <TableCell className="text-muted-slate text-xs hidden lg:table-cell">
                        {new Date(task.createdAt).toLocaleDateString()}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 && (
            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-slate">Page {page} of {totalPages}</p>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="h-8 w-8" disabled={page <= 1} onClick={() => setPage(page - 1)}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8" disabled={page >= totalPages} onClick={() => setPage(page + 1)}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}