'use client'

import { useEffect, useState, useMemo } from 'react'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Search, FolderTree } from 'lucide-react'

interface Department {
  id: string
  name: string
  slug: string
  status: string
  agentCount: number
}

export default function DepartmentsPanel() {
  const [departments, setDepartments] = useState<Department[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    fetch('/api/departments')
      .then((r) => r.json())
      .then((res) => setDepartments(res.data || []))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  const filtered = useMemo(() => {
    if (!search.trim()) return departments
    const q = search.toLowerCase()
    return departments.filter((d) => d.name.toLowerCase().includes(q) || d.slug.includes(q))
  }, [departments, search])

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <Skeleton className="h-8 w-48 bg-cosmic/30" />
        <Skeleton className="h-10 w-full max-w-sm bg-cosmic/20" />
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          {Array.from({ length: 20 }).map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-lg bg-cosmic/20" />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-soft-white">Departments</h2>
        <span className="text-sm text-muted-slate">{filtered.length} of {departments.length}</span>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-slate" />
        <Input
          placeholder="Search departments..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9 bg-cosmic/20 border-border/50 text-soft-white placeholder:text-muted-slate"
        />
      </div>

      <div className="max-h-[600px] overflow-y-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          {filtered.map((dept, idx) => (
            <div key={dept.id} className="glass-card cosmic-lift p-3 flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-nebula/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <FolderTree className="w-4 h-4 text-nebula" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-muted-slate">#{idx + 1}</span>
                  <h3 className="text-sm font-medium text-soft-white truncate">{dept.name}</h3>
                </div>
                <p className="text-xs text-neon mt-0.5">{dept.agentCount} agents</p>
                <Badge
                  variant={dept.status === 'active' ? 'default' : 'secondary'}
                  className={`text-[10px] py-0 mt-1 ${dept.status === 'active' ? 'bg-success/20 text-success' : 'bg-muted text-muted-slate'}`}
                >
                  {dept.status}
                </Badge>
              </div>
            </div>
          ))}
        </div>
        {filtered.length === 0 && (
          <p className="text-center text-muted-slate text-sm py-12">No departments found</p>
        )}
      </div>
    </div>
  )
}