'use client'

import { useEffect, useState, useRef } from 'react'
import { Search, ChevronLeft, ChevronRight } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'

interface Agent {
  id: string
  agentId: string
  name: string
  departmentName: string
  role: string
  status: string
  version: string
}

interface Department {
  id: string
  name: string
  slug: string
}

export default function AgentsRegistryPanel() {
  const [agents, setAgents] = useState<Agent[]>([])
  const [departments, setDepartments] = useState<Department[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [searchInput, setSearchInput] = useState('')
  const [deptFilter, setDeptFilter] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const limit = 50

  useEffect(() => {
    fetch('/api/departments')
      .then((r) => r.json())
      .then((res) => setDepartments(res.data || []))
      .catch(() => {})
  }, [])

  // Debounced search
  const searchTimerRef = useRef<ReturnType<typeof setTimeout>>(null)
  useEffect(() => {
    if (searchTimerRef.current) clearTimeout(searchTimerRef.current)
    searchTimerRef.current = setTimeout(() => {
      setSearch(searchInput)
      setPage(1)
    }, 300)
    return () => { if (searchTimerRef.current) clearTimeout(searchTimerRef.current) }
  }, [searchInput])

  // Fetch agents
  useEffect(() => {
    let cancelled = false
    // eslint-disable-next-line react-hooks/set-state-in-effect -- initial data loading
    setLoading(true)
    const params = new URLSearchParams({ page: String(page), limit: String(limit) })
    if (search) params.set('search', search)
    if (deptFilter) params.set('department', deptFilter)
    if (statusFilter) params.set('status', statusFilter)

    fetch(`/api/agents?${params}`)
      .then((r) => r.json())
      .then((res) => {
        if (!cancelled) {
          setAgents(res.data || [])
          setTotal(res.total || 0)
        }
      })
      .catch(() => {})
      .finally(() => { if (!cancelled) setLoading(false) })

    return () => { cancelled = true }
  }, [page, search, deptFilter, statusFilter])

  const totalPages = Math.ceil(total / limit)
  const from = (page - 1) * limit + 1
  const to = Math.min(page * limit, total)

  const statusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-success/20 text-success'
      case 'locked': return 'bg-warning/20 text-warning'
      case 'disabled': return 'bg-danger/20 text-danger'
      default: return 'bg-muted text-muted-slate'
    }
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h2 className="text-xl font-semibold text-soft-white">Agent Registry</h2>
        <span className="text-sm text-muted-slate">
          Showing {total > 0 ? `${from}-${to}` : '0'} of {total} agents
        </span>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-slate" />
          <Input
            placeholder="Search agents..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="pl-9 bg-cosmic/20 border-border/50 text-soft-white placeholder:text-muted-slate"
          />
        </div>
        <Select value={deptFilter || '__all__'} onValueChange={(v) => { setDeptFilter(v === '__all__' ? '' : v); setPage(1) }}>
          <SelectTrigger className="w-[200px] bg-cosmic/20 border-border/50 text-soft-white text-xs">
            <SelectValue placeholder="All Departments" />
          </SelectTrigger>
          <SelectContent className="bg-[#0B1B4D] border-border/50 max-h-64">
            <SelectItem value="__all__" className="text-soft-white">All Departments</SelectItem>
            {departments.map((d) => (
              <SelectItem key={d.slug} value={d.slug} className="text-soft-white">{d.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={statusFilter || '__all__'} onValueChange={(v) => { setStatusFilter(v === '__all__' ? '' : v); setPage(1) }}>
          <SelectTrigger className="w-[140px] bg-cosmic/20 border-border/50 text-soft-white text-xs">
            <SelectValue placeholder="All Status" />
          </SelectTrigger>
          <SelectContent className="bg-[#0B1B4D] border-border/50">
            <SelectItem value="__all__" className="text-soft-white">All Status</SelectItem>
            <SelectItem value="active" className="text-soft-white">Active</SelectItem>
            <SelectItem value="locked" className="text-soft-white">Locked</SelectItem>
            <SelectItem value="disabled" className="text-soft-white">Disabled</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      {loading ? (
        <Skeleton className="h-96 rounded-lg bg-cosmic/20" />
      ) : (
        <>
          <div className="glass-card overflow-hidden">
            <Table className="text-sm">
              <TableHeader>
                <TableRow className="bg-cosmic/50 hover:bg-cosmic/50 border-border/30">
                  <TableHead className="text-muted-slate">Agent ID</TableHead>
                  <TableHead className="text-muted-slate">Name</TableHead>
                  <TableHead className="text-muted-slate hidden md:table-cell">Department</TableHead>
                  <TableHead className="text-muted-slate hidden lg:table-cell">Role</TableHead>
                  <TableHead className="text-muted-slate">Status</TableHead>
                  <TableHead className="text-muted-slate hidden sm:table-cell">Version</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {agents.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-slate py-12">No agents found</TableCell>
                  </TableRow>
                ) : (
                  agents.map((agent) => (
                    <TableRow key={agent.id} className="border-border/20 hover:bg-white/5">
                      <TableCell className="font-mono text-xs text-electric">{agent.agentId}</TableCell>
                      <TableCell className="text-soft-white font-medium">{agent.name}</TableCell>
                      <TableCell className="text-muted-slate hidden md:table-cell">{agent.departmentName}</TableCell>
                      <TableCell className="text-muted-slate hidden lg:table-cell capitalize">{agent.role}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={`text-[10px] py-0 ${statusColor(agent.status)}`}>
                          {agent.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-slate font-mono text-xs hidden sm:table-cell">{agent.version || '1.0.0'}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-slate">Page {page} of {totalPages}</p>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  disabled={page <= 1}
                  onClick={() => setPage(page - 1)}
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  disabled={page >= totalPages}
                  onClick={() => setPage(page + 1)}
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}