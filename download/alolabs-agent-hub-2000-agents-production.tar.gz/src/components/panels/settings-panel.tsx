'use client'

import { useEffect, useState } from 'react'
import { Settings, Shield, Lock, Database } from 'lucide-react'
import { Switch } from '@/components/ui/switch'
import { Skeleton } from '@/components/ui/skeleton'

interface Setting {
  id: string
  key: string
  value: string
  type: string
}

export default function SettingsPanel() {
  const [settings, setSettings] = useState<Setting[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/settings')
      .then((r) => r.json())
      .then((res) => setSettings(res.data || []))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  const isBool = (v: string) => v === 'true' || v === 'false'
  const toBool = (v: string) => v === 'true'

  const handleToggle = async (setting: Setting) => {
    const newVal = String(!toBool(setting.value))
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: setting.key, value: newVal, type: setting.type }),
      })
      if (res.ok) {
        setSettings((prev) => prev.map((s) => (s.key === setting.key ? { ...s, value: newVal } : s)))
      }
    } catch {
      // ignore
    }
  }

  const iconForKey = (key: string) => {
    if (key.includes('LOCAL') || key.includes('RAG')) return Database
    if (key.includes('PROTECT') || key.includes('GUARD')) return Shield
    if (key.includes('PAID') || key.includes('API')) return Lock
    return Settings
  }

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <Skeleton className="h-8 w-48 bg-cosmic/30" />
        <div className="space-y-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-16 rounded-lg bg-cosmic/20" />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center gap-3">
        <Settings className="w-6 h-6 text-neon" />
        <h2 className="text-xl font-semibold text-soft-white">System Settings</h2>
      </div>

      <div className="glass-card p-4">
        <p className="text-sm text-muted-slate">
          Configure system-wide behavior. Changes take effect immediately.
          Some settings require Super Admin privileges to modify.
        </p>
      </div>

      <div className="space-y-2">
        {settings.map((setting) => {
          const Icon = iconForKey(setting.key)
          const boolVal = isBool(setting.value)
          return (
            <div key={setting.id} className="glass-card p-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-lg bg-cosmic/30 flex items-center justify-center flex-shrink-0">
                  <Icon className="w-4 h-4 text-electric" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm font-medium text-soft-white">{setting.key}</h3>
                  {boolVal ? (
                    <p className="text-xs text-muted-slate">
                      {toBool(setting.value) ? 'Enabled' : 'Disabled'}
                    </p>
                  ) : (
                    <p className="text-xs text-neon font-mono truncate">{setting.value}</p>
                  )}
                </div>
              </div>
              {boolVal && (
                <Switch
                  checked={toBool(setting.value)}
                  onCheckedChange={() => handleToggle(setting)}
                />
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}