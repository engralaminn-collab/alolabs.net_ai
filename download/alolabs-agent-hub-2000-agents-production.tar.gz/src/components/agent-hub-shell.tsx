'use client'

import { useEffect, useState, useRef, Suspense } from 'react'
import { useAppStore } from '@/store/app'
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Skeleton } from '@/components/ui/skeleton'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  LayoutDashboard,
  Building2,
  Bot,
  Zap,
  GitBranch,
  ClipboardList,
  BarChart3,
  CheckSquare,
  Settings,
  Menu,
  ChevronLeft,
  Crown,
  ArrowRightLeft,
  Users,
  Key,
  Webhook as WebhookIcon,
  Shield,
  Activity,
  Play,
  Network,
  Database,
  Search,
  Cpu,
  DollarSign,
  MessageSquare,
  ShieldAlert,
  CreditCard,
  TrendingUp,
  BarChart2,
  Brain,
  FolderTree,
  Wrench,
  FileText,
  ShieldCheck,
  Receipt,
  Store,
  Layers,
  Coins,
  Eye,
  Building,
  OctagonAlert,
  Server,
  Lock,
  HardDrive,
  Rocket,
  Bell,
  BellRing,
  MemoryStick,
  Download,
  Upload,
  Palette,
  Plug,
  GraduationCap,
  ClipboardCheck,
  Globe,
} from 'lucide-react'

import WebCrmDashboard from '@/components/panels/web-crm-dashboard'
import SuperCommandingChat from '@/components/panels/super-commanding-chat'
import SuperAdminCommandCenter from '@/components/panels/super-admin-command-center'
import CrmConnectionsPanel from '@/components/panels/crm-connections-panel'
import CompaniesPanel from '@/components/panels/companies-panel'
import AgentsRegistryPanel from '@/components/panels/agents-registry-panel'
import WorkflowsPanel from '@/components/panels/workflows-panel'
import TasksPanel from '@/components/panels/tasks-panel'
import UsagePanel from '@/components/panels/usage-panel'
import ApprovalsPanel from '@/components/panels/approvals-panel'
import SettingsPanel from '@/components/panels/settings-panel'
import CommandCenter from '@/components/panels/command-center'
import DepartmentsPanel from '@/components/panels/departments-panel'
import SkillsPanel from '@/components/panels/skills-panel'
import ProtectionPanel from '@/components/panels/protection-panel'
import PaymentGuardPanel from '@/components/panels/payment-guard-panel'
import AuditLogsPanel from '@/components/panels/audit-logs-panel'
import MemoryPanel from '@/components/panels/memory-panel'
import SelfImprovementPanel from '@/components/panels/self-improvement-panel'
import ProductivityPanel from '@/components/panels/productivity-panel'
import ApiKeysPanel from '@/components/panels/api-keys-panel'
import WebhooksPanel from '@/components/panels/webhooks-panel'
import CompanyAccessPanel from '@/components/panels/company-access-panel'
import SystemHealthPanel from '@/components/panels/system-health-panel'
import JobMonitorPanel from '@/components/panels/job-monitor-panel'
import TenantGatewayPanel from '@/components/panels/tenant-gateway-panel'
import RagPanel from '@/components/panels/rag-panel'
import CapabilityRequestPanel from '@/components/panels/capability-request-panel'
import AgentFactoryPanel from '@/components/panels/agent-factory-panel'
import CostEstimatePanel from '@/components/panels/cost-estimate-panel'
import FeedbackPanel from '@/components/panels/feedback-panel'
import SecurityCenterPanel from '@/components/panels/security-center-panel'
import BillingPanel from '@/components/panels/billing-panel'
import MarketplacePanel from '@/components/panels/marketplace-panel'
import QueuePanel from '@/components/panels/queue-panel'
import TokenBudgetPanel from '@/components/panels/token-budget-panel'
import ObservatoryPanel from '@/components/panels/observatory-panel'
import TenantAdminPanel from '@/components/panels/tenant-admin-panel'
import LoginPage from '@/components/pages/login'
import AuthCenterPanel from '@/components/panels/auth-center-panel'
import EmergencyPanel from '@/components/panels/emergency-panel'
import PromptVaultPanel from '@/components/panels/prompt-vault-panel'
import ToolRegistryPanel from '@/components/panels/tool-registry-panel'
import McpManagerPanel from '@/components/panels/mcp-manager-panel'
import IncidentPanel from '@/components/panels/incident-panel'
import NotificationPanel from '@/components/panels/notification-panel'
import BackupPanel from '@/components/panels/backup-panel'
import WorkerManagerPanel from '@/components/panels/worker-manager-panel'
import OutputCenterPanel from '@/components/panels/output-center-panel'
import DeploymentPanel from '@/components/panels/deployment-panel'
import UserManagementPanel from '@/components/panels/user-management-panel'
import RoleManagementPanel from '@/components/panels/role-management-panel'
import BrandManagementPanel from '@/components/panels/brand-management-panel'
import IntegrationManagerPanel from '@/components/panels/integration-manager-panel'
import AgentTrainingPanel from '@/components/panels/agent-training-panel'
import AgentEvaluationPanel from '@/components/panels/agent-evaluation-panel'
import ModelRegistryPanel from '@/components/panels/model-registry-panel'
import AgentUsagePanel from '@/components/panels/agent-usage-panel'
import WorkflowUsagePanel from '@/components/panels/workflow-usage-panel'
import DisasterRecoveryPanel from '@/components/panels/disaster-recovery-panel'

interface NavItem {
  id: string
  label: string
  icon: React.ElementType
  group: string
}

const navItems: NavItem[] = [
  { id: 'super-admin', label: 'Command Chat', icon: Crown, group: 'Command' },
  { id: 'web-crm', label: 'CRM Dashboard', icon: LayoutDashboard, group: 'Command' },
  { id: 'companies', label: 'Companies', icon: Building2, group: 'Overview' },
  { id: 'departments', label: 'Departments', icon: FolderTree, group: 'Overview' },
  { id: 'agents-registry', label: 'Agent Registry', icon: Bot, group: 'Overview' },
  { id: 'skills-registry', label: 'Skills', icon: Wrench, group: 'Overview' },
  { id: 'deal-pipeline', label: 'Deal Pipeline', icon: GitBranch, group: 'Operations' },
  { id: 'contacts', label: 'Contacts', icon: Users, group: 'Operations' },
  { id: 'tasks', label: 'Tasks', icon: ClipboardList, group: 'Operations' },
  { id: 'output-center', label: 'Outputs', icon: FileText, group: 'Operations' },
  { id: 'usage-analytics', label: 'Usage Analytics', icon: BarChart3, group: 'Operations' },
  { id: 'agent-usage', label: 'Agent Usage', icon: TrendingUp, group: 'Operations' },
  { id: 'workflow-usage', label: 'Workflow Usage', icon: BarChart3, group: 'Operations' },
  { id: 'crm-connections', label: 'CRM Connections', icon: ArrowRightLeft, group: 'Management' },
  { id: 'approvals', label: 'Approvals', icon: CheckSquare, group: 'Management' },
  { id: 'workflows', label: 'Workflows', icon: Zap, group: 'Management' },
  { id: 'integration-manager', label: 'Integrations', icon: Plug, group: 'Management' },
  { id: 'rag-center', label: 'RAG Knowledge', icon: Database, group: 'Intelligence' },
  { id: 'capability-request', label: 'Capability Gap', icon: Search, group: 'Intelligence' },
  { id: 'memory-center', label: 'Memory', icon: Brain, group: 'Intelligence' },
  { id: 'agent-factory', label: 'Agent Factory', icon: Cpu, group: 'Build' },
  { id: 'cost-estimate', label: 'Cost Center', icon: DollarSign, group: 'Finance' },
  { id: 'payment-guard', label: 'Payment Guard', icon: CreditCard, group: 'Finance' },
  { id: 'auth-center', label: 'Auth Center', icon: Shield, group: 'Security' },
  { id: 'prompt-vault', label: 'Prompt Vault', icon: Lock, group: 'Security' },
  { id: 'api-keys', label: 'API Keys', icon: Key, group: 'Security' },
  { id: 'webhooks', label: 'Webhooks', icon: WebhookIcon, group: 'Security' },
  { id: 'company-access', label: 'Access Matrix', icon: Shield, group: 'Security' },
  { id: 'role-management', label: 'Roles', icon: ShieldCheck, group: 'Security' },
  { id: 'protection-mode', label: 'Protection', icon: ShieldAlert, group: 'Security' },
  { id: 'tool-registry', label: 'Tool Registry', icon: Wrench, group: 'Build' },
  { id: 'mcp-manager', label: 'MCP Manager', icon: Server, group: 'Build' },
  { id: 'marketplace', label: 'Marketplace', icon: Store, group: 'Build' },
  { id: 'model-registry', label: 'Model Registry', icon: Database, group: 'Build' },
  { id: 'billing', label: 'Billing', icon: Receipt, group: 'Finance' },
  { id: 'security-center', label: 'Security Center', icon: ShieldCheck, group: 'Security' },
  { id: 'token-budget', label: 'Token Budget', icon: Coins, group: 'System' },
  { id: 'queue', label: 'Job Queue', icon: Layers, group: 'System' },
  { id: 'observatory', label: 'Observatory', icon: Eye, group: 'System' },
  { id: 'emergency', label: 'Emergency', icon: OctagonAlert, group: 'Admin' },
  { id: 'backup', label: 'Backup', icon: HardDrive, group: 'Admin' },
  { id: 'disaster-recovery', label: 'DR Recovery', icon: ShieldAlert, group: 'Admin' },
  { id: 'deployment-center', label: 'Deployments', icon: Rocket, group: 'Admin' },
  { id: 'tenant-admin', label: 'Tenant Admin', icon: Building, group: 'Admin' },
  { id: 'user-management', label: 'Users', icon: Users, group: 'Admin' },
  { id: 'brand-management', label: 'Brand Engine', icon: Palette, group: 'Admin' },
  { id: 'feedback', label: 'Feedback', icon: MessageSquare, group: 'Learning' },
  { id: 'self-improvement', label: 'Self Improve', icon: TrendingUp, group: 'Learning' },
  { id: 'productivity', label: 'Productivity', icon: BarChart2, group: 'Learning' },
  { id: 'agent-training', label: 'Training', icon: GraduationCap, group: 'Learning' },
  { id: 'agent-evaluation', label: 'Evaluation', icon: ClipboardCheck, group: 'Learning' },
  { id: 'system-health', label: 'System Health', icon: Activity, group: 'System' },
  { id: 'job-monitor', label: 'Job Monitor', icon: Play, group: 'System' },
  { id: 'tenant-gateway', label: 'Tenant Gateway', icon: Network, group: 'System' },
  { id: 'incident-center', label: 'Incidents', icon: ShieldAlert, group: 'System' },
  { id: 'notification-center', label: 'Notifications', icon: Bell, group: 'System' },
  { id: 'worker-manager', label: 'Workers', icon: Cpu, group: 'System' },
  { id: 'audit-logs', label: 'Audit Logs', icon: FileText, group: 'System' },
  { id: 'settings', label: 'Settings', icon: Settings, group: 'System' },
]

const groups = ['Command', 'Overview', 'Operations', 'Management', 'Intelligence', 'Build', 'Finance', 'Security', 'Learning', 'System', 'Admin']

function PanelLoader() {
  return (
    <div className="space-y-6 p-6">
      <Skeleton className="h-8 w-48 bg-gray-100" />
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-28 rounded-xl bg-gray-100" />
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Skeleton className="h-96 rounded-xl bg-gray-100 lg:col-span-1" />
        <Skeleton className="h-96 rounded-xl bg-gray-100 lg:col-span-1" />
        <Skeleton className="h-96 rounded-xl bg-gray-100 lg:col-span-1" />
      </div>
      <Skeleton className="h-64 rounded-xl bg-gray-100" />
    </div>
  )
}

/* Hexagonal "A" Logo Component */
function AloLogo({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M20 2L37 11V29L20 38L3 29V11L20 2Z"
        stroke="#FF6A00"
        strokeWidth="2.5"
        fill="#003ABC"
        fillOpacity="0.1"
      />
      <path
        d="M20 2L37 11V29L20 38L3 29V11L20 2Z"
        stroke="#FF6A00"
        strokeWidth="2.5"
        fill="none"
      />
      <text
        x="20"
        y="25"
        textAnchor="middle"
        fontFamily="Inter, sans-serif"
        fontWeight="700"
        fontSize="18"
        fill="#003ABC"
      >
        A
      </text>
      <rect x="14" y="28" width="12" height="2.5" rx="1.25" fill="#FF6A00" />
    </svg>
  )
}

function SidebarContent({ collapsed, onNavigate }: { collapsed: boolean; onNavigate: () => void }) {
  const currentView = useAppStore((s) => s.currentView)
  const setView = useAppStore((s) => s.setView)

  return (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="p-4 flex items-center gap-3">
        <AloLogo size={36} />
        {!collapsed && (
          <div className="min-w-0">
            <h2 className="text-sm font-bold leading-tight">
              <span className="text-[#FF6A00]">ALO Labs</span>
              <span className="text-[#003ABC] ml-1">AgentOS</span>
            </h2>
            <p className="text-[10px] text-[#94A3B8] leading-tight">AI Agent Operating System</p>
          </div>
        )}
      </div>
      <Separator className="bg-[#E2E8F0]" />
      <ScrollArea className="flex-1 py-2">
        {groups.map((group) => (
          <div key={group} className="mb-1">
            {!collapsed && (
              <p className="px-4 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-[#94A3B8]">
                {group}
              </p>
            )}
            {navItems
              .filter((item) => item.group === group)
              .map((item) => {
                const Icon = item.icon
                const active = currentView === item.id
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setView(item.id)
                      onNavigate()
                    }}
                    title={collapsed ? item.label : undefined}
                    className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition-all duration-150 rounded-lg mx-1 ${
                      active
                        ? 'bg-[#003ABC]/8 text-[#003ABC] font-medium'
                        : 'text-[#64748B] hover:text-[#1E293B] hover:bg-[#F1F5F9]'
                    } ${collapsed ? 'justify-center px-2' : ''}`}
                  >
                    <Icon className={`w-[18px] h-[18px] flex-shrink-0 ${active ? 'text-[#003ABC]' : ''}`} />
                    {!collapsed && <span className="truncate text-[13px]">{item.label}</span>}
                    {active && !collapsed && (
                      <div className="ml-auto w-1.5 h-1.5 rounded-full bg-[#FF6A00]" />
                    )}
                  </button>
                )
              })}
          </div>
        ))}
      </ScrollArea>

      {/* Bottom tagline */}
      {!collapsed && (
        <div className="p-4 border-t border-[#E2E8F0]">
          <p className="text-[10px] text-[#94A3B8] leading-relaxed">
            Secure. Smart. Scalable.<br />Built for the Future.
          </p>
        </div>
      )}
    </div>
  )
}

export default function AgentHubShell() {
  const _init = useAppStore((s) => s._init)
  const currentView = useAppStore((s) => s.currentView)
  const sidebarOpen = useAppStore((s) => s.sidebarOpen)
  const setSidebarOpen = useAppStore((s) => s.setSidebarOpen)
  const selectedCompany = useAppStore((s) => s.selectedCompany)
  const setSelectedCompany = useAppStore((s) => s.setSelectedCompany)
  const user = useAppStore((s) => s.user)

  const setShowPublicSite = useAppStore((s) => s.setShowPublicSite)

  const [companies, setCompanies] = useState<{ id: string; name: string; slug: string }[]>([])
  const [mobileOpen, setMobileOpen] = useState(false)
  const [collapsed, setCollapsed] = useState(false)

  // Use ref to track initialization so we only call _init once
  const initializedRef = useRef(false)

  useEffect(() => {
    if (!initializedRef.current) {
      initializedRef.current = true
      _init()
    }
  }, [_init])

  useEffect(() => {
    if (user) {
      fetch('/api/companies')
        .then((r) => r.json())
        .then((res) => setCompanies(res.data || []))
        .catch(() => {})
    }
  }, [user])

  // Show login page if not authenticated
  if (!user) {
    return <LoginPage />
  }

  const renderPanel = () => {
    const panelMap: Record<string, React.ReactNode> = {
      'web-crm': <WebCrmDashboard />,
      'super-admin': <SuperCommandingChat />,
      'super-command': <SuperAdminCommandCenter />,
      'crm-connections': <CrmConnectionsPanel />,
      'command-center': <CommandCenter />,
      'companies': <CompaniesPanel />,
      'departments': <DepartmentsPanel />,
      'agents-registry': <AgentsRegistryPanel />,
      'skills-registry': <SkillsPanel />,
      'workflows': <WorkflowsPanel />,
      'deal-pipeline': <WebCrmDashboard />,
      'contacts': <WebCrmDashboard />,
      'tasks': <TasksPanel />,
      'usage-analytics': <UsagePanel />,
      'approvals': <ApprovalsPanel />,
      'protection-mode': <ProtectionPanel />,
      'payment-guard': <PaymentGuardPanel />,
      'audit-logs': <AuditLogsPanel />,
      'memory-center': <MemoryPanel />,
      'self-improvement': <SelfImprovementPanel />,
      'productivity': <ProductivityPanel />,
      'api-keys': <ApiKeysPanel />,
      'webhooks': <WebhooksPanel />,
      'company-access': <CompanyAccessPanel />,
      'system-health': <SystemHealthPanel />,
      'job-monitor': <JobMonitorPanel />,
      'tenant-gateway': <TenantGatewayPanel />,
      'rag-center': <RagPanel />,
      'capability-request': <CapabilityRequestPanel />,
      'agent-factory': <AgentFactoryPanel />,
      'cost-estimate': <CostEstimatePanel />,
      'feedback': <FeedbackPanel />,
      'settings': <SettingsPanel />,
      'auth-center': <AuthCenterPanel />,
      'security-center': <SecurityCenterPanel />,
      'billing': <BillingPanel />,
      'marketplace': <MarketplacePanel />,
      'queue': <QueuePanel />,
      'token-budget': <TokenBudgetPanel />,
      'observatory': <ObservatoryPanel />,
      'tenant-admin': <TenantAdminPanel />,
      'emergency': <EmergencyPanel />,
      'prompt-vault': <PromptVaultPanel />,
      'tool-registry': <ToolRegistryPanel />,
      'mcp-manager': <McpManagerPanel />,
      'incident-center': <IncidentPanel />,
      'notification-center': <NotificationPanel />,
      'backup': <BackupPanel />,
      'worker-manager': <WorkerManagerPanel />,
      'output-center': <OutputCenterPanel />,
      'deployment-center': <DeploymentPanel />,
      'user-management': <UserManagementPanel />,
      'role-management': <RoleManagementPanel />,
      'brand-management': <BrandManagementPanel />,
      'integration-manager': <IntegrationManagerPanel />,
      'agent-training': <AgentTrainingPanel />,
      'agent-evaluation': <AgentEvaluationPanel />,
      'model-registry': <ModelRegistryPanel />,
      'agent-usage': <AgentUsagePanel />,
      'workflow-usage': <WorkflowUsagePanel />,
      'disaster-recovery': <DisasterRecoveryPanel />,
    }
    return panelMap[currentView] || <WebCrmDashboard />
  }

  const handleMobileNavigate = () => setMobileOpen(false)

  return (
    <div className="flex h-screen overflow-hidden bg-[#F8FAFC]">
      {/* Desktop Sidebar */}
      <aside
        className={`hidden lg:flex flex-col border-r border-[#E2E8F0] bg-white transition-all duration-300 ${
          collapsed ? 'w-[68px]' : 'w-[260px]'
        }`}
      >
        <div className="flex items-center justify-end p-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCollapsed(!collapsed)}
            className="h-8 w-8 text-[#94A3B8] hover:text-[#1E293B] hover:bg-[#F1F5F9] rounded-lg"
          >
            <ChevronLeft className={`w-4 h-4 transition-transform ${collapsed ? 'rotate-180' : ''}`} />
          </Button>
        </div>
        <SidebarContent collapsed={collapsed} onNavigate={() => {}} />
      </aside>

      {/* Main area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="h-14 border-b border-[#E2E8F0] bg-white flex items-center justify-between px-4 flex-shrink-0">
          {/* Left: Mobile menu */}
          <div className="flex items-center gap-3">
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="lg:hidden h-8 w-8 text-[#64748B] hover:text-[#1E293B]">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[260px] p-0 bg-white border-[#E2E8F0]">
                <SheetTitle className="sr-only">Navigation</SheetTitle>
                <SidebarContent collapsed={false} onNavigate={handleMobileNavigate} />
              </SheetContent>
            </Sheet>

            {/* Title */}
            <h1 className="text-lg font-bold hidden sm:block">
              <span className="alo-gradient-text">AgentOS</span>
            </h1>
          </div>

          {/* Right: Public site + Company switcher + health + avatar */}
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowPublicSite(true)}
              className="h-8 text-xs text-[#64748B] hover:text-[#003ABC] hover:bg-[#F1F5F9] gap-1.5 rounded-lg"
            >
              <Globe className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Public Website</span>
            </Button>

            <Select value={selectedCompany || '__all__'} onValueChange={(v) => setSelectedCompany(v === '__all__' ? null : v)}>
              <SelectTrigger className="w-[180px] h-8 text-xs bg-[#F8FAFC] border-[#E2E8F0] text-[#1E293B] rounded-lg">
                <SelectValue placeholder="All Companies" />
              </SelectTrigger>
              <SelectContent className="bg-white border-[#E2E8F0] rounded-lg">
                <SelectItem value="__all__" className="text-[#1E293B] focus:bg-[#F1F5F9] focus:text-[#003ABC]">
                  All Companies
                </SelectItem>
                {companies.map((c) => (
                  <SelectItem key={c.slug} value={c.slug} className="text-[#1E293B] focus:bg-[#F1F5F9] focus:text-[#003ABC]">
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Health dot */}
            <div className="flex items-center gap-2">
              <span className="status-dot status-dot-active alo-pulse" />
              <span className="text-xs text-[#64748B] hidden md:inline">Healthy</span>
            </div>

            {/* Avatar */}
            <Avatar className="h-8 w-8 border-2 border-[#E2E8F0]">
              <AvatarFallback className="bg-[#003ABC] text-white text-xs font-bold rounded-lg">
                {(user?.name || 'SA').slice(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
          </div>
        </header>

        {/* Content */}
        <main className={`flex-1 overflow-hidden bg-[#F8FAFC] ${currentView === 'super-admin' ? '' : 'overflow-y-auto'}`}>
          <Suspense fallback={<PanelLoader />}>
            {renderPanel()}
          </Suspense>
        </main>
      </div>
    </div>
  )
}