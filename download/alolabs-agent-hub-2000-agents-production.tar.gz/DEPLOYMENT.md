# ALO Labs Agent Hub — Complete Deployment Guide

## Project Overview

**ALO Labs Agent Hub** is a central AI workforce dashboard built with:
- **Framework:** Next.js 16 (App Router) + TypeScript
- **Database:** SQLite via Prisma ORM
- **UI:** Tailwind CSS 4 + shadcn/ui + Recharts + Lucide Icons
- **Theme:** Deep Space Cosmic Blue (dark-only)
- **Data:** 2000 Agents, 100 Departments, 8 Sister Companies, 63 Workflows

### Architecture

```
alolabs.net (Cloudflare CDN)
    ↓ (HTTPS, SSL/TLS)
Your VPS Server (Nginx reverse proxy)
    ↓ (proxy_pass :3000)
PM2 → Node.js / Bun
    ↓
Next.js 16 Standalone Server (port 3000)
    ↓
SQLite Database (db/custom.db)
```

### System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| OS | Ubuntu 22.04 / Debian 12 | Ubuntu 24.04 LTS |
| CPU | 1 core | 2+ cores |
| RAM | 1 GB | 2+ GB |
| Disk | 5 GB | 20+ GB SSD |
| Node.js | 18.x | 20.x LTS or 22.x LTS |
| Bun | 1.0+ | Latest |

---

## Step 1: Local Development (Your Laptop)

### 1.1 Install Prerequisites

```bash
# Install Node.js (if not already installed)
# Using nvm (recommended):
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash
source ~/.bashrc
nvm install 20
nvm use 20

# Install Bun (alternative to Node.js):
curl -fsSL https://bun.sh/install | bash
```

### 1.2 Get the Project

Copy the entire project folder to your laptop. The project includes:

```
alolabs-agent-hub/
├── src/                    # Source code
│   ├── app/                # Next.js App Router (API routes + page)
│   │   ├── api/            # 28 API route folders
│   │   ├── globals.css     # Cosmic dark theme
│   │   ├── layout.tsx      # Root layout
│   │   └── page.tsx        # Main entry page
│   ├── components/         # React components
│   │   ├── ui/             # shadcn/ui components
│   │   ├── panels/         # 16 dashboard panels
│   │   └── agent-hub-shell.tsx  # Main shell
│   ├── lib/                # Utilities, DB client
│   ├── hooks/              # Custom React hooks
│   └── store/              # Zustand store
├── prisma/
│   └── schema.prisma       # 40+ database models
├── db/
│   └── custom.db           # SQLite database (with data)
├── scripts/
│   └── seed-agenthub.ts    # Database seeder
├── package.json
├── next.config.ts          # Standalone output configured
├── tsconfig.json
├── .env                    # DATABASE_URL
└── DEPLOYMENT.md           # This file
```

### 1.3 Install Dependencies & Run

```bash
cd alolabs-agent-hub

# Install all dependencies
npm install
# OR: bun install

# Generate Prisma client
npx prisma generate
# OR: bunx prisma generate

# (Optional) Reset and re-seed the database
npx prisma db push --force-reset
npx tsx scripts/seed-agenthub.ts
# OR with bun:
# bunx prisma db push --force-reset
# bunx tsx scripts/seed-agenthub.ts

# Start development server
npm run dev
# OR: bun run dev
```

Open **http://localhost:3000** in your browser.

### 1.4 Default Login

- **Email:** `admin@alolabs.com`
- **Password:** `admin123`

---

## Step 2: Production Build

### 2.1 Build the Application

```bash
cd alolabs-agent-hub

# Install production dependencies
npm install
npx prisma generate

# Build for production (creates .next/standalone/)
npm run build
```

The `next.config.ts` already has `output: "standalone"` configured, which creates a self-contained server in `.next/standalone/`.

### 2.2 Verify Build Output

```bash
ls -la .next/standalone/
# You should see: server.js, .next/, node_modules/

# The build script in package.json automatically copies:
# - .next/static → .next/standalone/.next/static
# - public/ → .next/standalone/public
```

### 2.3 Test Production Build Locally

```bash
# Start production server
npm run start
# OR: NODE_ENV=production node .next/standalone/server.js

# Open http://localhost:3000
```

---

## Step 3: Deploy to Your Own VPS / Server

### 3.1 Get a VPS Server

Recommended providers (cheap & reliable):
| Provider | Starting Price | Location Options |
|----------|---------------|------------------|
| **Hetzner Cloud** | €3.29/mo | Germany, Finland, USA |
| **DigitalOcean** | $4/mo | USA, Europe, Asia |
| **Vultr** | $2.50/mo | 30+ locations |
| **Contabo** | $4.50/mo | Germany, USA, Asia |
| **AWS Lightsail** | $3.50/mo | 20+ locations |

**Recommended for Bangladesh/Asia:** Hetzner (Finland), Vultr (Singapore/Tokyo), DigitalOcean (Singapore/Bangalore)

### 3.2 Initial Server Setup

SSH into your new server:

```bash
ssh root@YOUR_SERVER_IP
```

Run these commands:

```bash
# Update system
apt update && apt upgrade -y

# Install essential tools
apt install -y curl wget git nano ufw nginx certbot

# Install Node.js 20 LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Verify installations
node --version   # v20.x.x
npm --version    # 10.x.x

# Install PM2 (process manager)
npm install -g pm2

# Install Bun (optional, for faster builds)
curl -fsSL https://bun.sh/install | bash

# Configure firewall
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable
```

### 3.3 Upload Project to Server

**Option A: Using Git (recommended)**

```bash
# On your laptop: push project to a private GitHub/GitLab repo
# Then on the server:
cd /var/www
git clone https://github.com/YOUR_USERNAME/alolabs-agent-hub.git
cd alolabs-agent-hub
```

**Option B: Using SCP/Rsync**

```bash
# On your laptop:
# First, create a clean deployment archive (exclude node_modules, .next, audit folder)
tar --exclude='node_modules' --exclude='.next' --exclude='audit' --exclude='db/*.db-journal' \
    -czf alo-hub-deploy.tar.gz .

# Upload to server
scp alo-hub-deploy.tar.gz root@YOUR_SERVER_IP:/var/www/

# On the server:
cd /var/www
mkdir -p alolabs-agent-hub
cd alolabs-agent-hub
tar -xzf ../alo-hub-deploy.tar.gz
rm ../alo-hub-deploy.tar.gz
```

**Option C: Using rsync (for updates)**

```bash
# On your laptop:
rsync -avz --exclude='node_modules' --exclude='.next' --exclude='audit' \
    ./ root@YOUR_SERVER_IP:/var/www/alolabs-agent-hub/
```

### 3.4 Install & Build on Server

```bash
cd /var/www/alolabs-agent-hub

# Install dependencies
npm install --production=false   # install all (including devDeps for build)
npx prisma generate

# If you need to seed the database:
npx prisma db push --force-reset
npx tsx scripts/seed-agenthub.ts

# OR copy your existing database:
# (Just make sure db/custom.db exists with all the data)

# Build for production
npm run build

# Verify build
ls .next/standalone/server.js  # Should exist
```

### 3.5 Start with PM2

```bash
# Create PM2 ecosystem config
cat > ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'alolabs-agent-hub',
    script: '.next/standalone/server.js',
    cwd: '/var/www/alolabs-agent-hub',
    env: {
      NODE_ENV: 'production',
      PORT: 3000,
      HOSTNAME: '0.0.0.0'
    },
    instances: 1,
    autorestart: true,
    max_memory_restart: '512M',
    error_file: '/var/log/alolabs/error.log',
    out_file: '/var/log/alolabs/out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z'
  }]
}
EOF

# Create log directory
mkdir -p /var/log/alolabs

# Start the application
pm2 start ecosystem.config.cjs

# Save PM2 config for auto-restart on reboot
pm2 save
pm2 startup   # Follow the command it prints

# Check status
pm2 status
pm2 logs alolabs-agent-hub --lines 20
```

### 3.6 Configure Nginx Reverse Proxy

```bash
# Create Nginx config
cat > /etc/nginx/sites-available/alolabs.net << 'EOF'
server {
    listen 80;
    server_name alolabs.net www.alolabs.net;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Proxy to Next.js
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }

    # Static file caching
    location /_next/static {
        proxy_pass http://127.0.0.1:3000;
        proxy_cache_valid 200 365d;
        add_header Cache-Control "public, immutable";
    }

    # API - no cache
    location /api {
        proxy_pass http://127.0.0.1:3000;
        proxy_cache_bypass 1;
        proxy_no_cache 1;
    }
}
EOF

# Enable the site
ln -sf /etc/nginx/sites-available/alolabs.net /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test & restart Nginx
nginx -t
systemctl restart nginx
systemctl enable nginx
```

---

## Step 4: Connect to Cloudflare (Your alolabs.net)

You already have Cloudflare configured. Here's how to connect your server:

### 4.1 Update DNS Records

Go to **Cloudflare Dashboard → alolabs.net → DNS → Records** and add/update:

| Type | Name | Content | Proxy | TTL |
|------|------|---------|-------|-----|
| A | `@` | `YOUR_SERVER_IP` | Proxied (orange cloud) | Auto |
| A | `www` | `YOUR_SERVER_IP` | Proxied (orange cloud) | Auto |

**Replace `YOUR_SERVER_IP`** with your VPS IP address.

### 4.2 Cloudflare SSL/TLS Settings

You already have these configured correctly:
- ✅ SSL/TLS mode: **Full** (NOT "Full (Strict)" since Nginx uses HTTP on port 80)
- ✅ Always Use HTTPS: **On**
- ✅ TLS 1.3: **On**
- ✅ Auto HTTPS Rewrites: **On**
- ✅ Universal SSL Certificate: Active (expires 2026-09-26)

### 4.3 Cloudflare Caching Rules (Optional but Recommended)

Go to **Caching → Configuration**:

1. **Browser Cache TTL:** 4 hours
2. **Caching Level:** Standard
3. **Always Online:** On

Go to **Rules → Page Rules** (or Cache Rules):

```
URL: *alolabs.net/api/*
Cache Level: Bypass
```

```
URL: *alolabs.net/_next/static/*
Browser Cache TTL: 1 month
Edge Cache TTL: 1 month
```

### 4.4 Cloudflare Security (Recommended)

Go to **Security → WAF**:
- Enable "Managed Rules" (free tier includes basic protection)
- Enable "Bot Fight Mode" (free)

Go to **Security → Settings**:
- Security Level: Medium
- Challenge Passage: 30 minutes
- Browser Integrity Check: On

---

## Step 5: Verify Everything Works

### 5.1 Test on Server

```bash
# Check if the app is running
curl -s http://localhost:3000/api/health | python3 -m json.tool

# Expected output:
# {
#   "system_name": "ALO Labs Agent Hub",
#   "companies_count": 8,
#   "agents_count": 2000,
#   "departments_count": 100,
#   "workflows_count": 63,
#   "status": "healthy"
# }
```

### 5.2 Test from Internet (after DNS propagates)

```bash
# From your laptop:
curl -s https://alolabs.net/api/health | python3 -m json.tool
```

### 5.3 Test in Browser

Open **https://alolabs.net** in your browser. You should see:
- Deep space cosmic blue dashboard
- Collapsible sidebar with 16 navigation panels
- Command Center showing 2000 agents, 8 companies, 100 departments
- Agent Registry with search, filter, and pagination

---

## Step 6: Ongoing Maintenance

### 6.1 Useful PM2 Commands

```bash
pm2 status                    # Check app status
pm2 logs alolabs-agent-hub    # View logs
pm2 restart alolabs-agent-hub # Restart app
pm2 stop alolabs-agent-hub    # Stop app
pm2 monit                     # Real-time monitoring dashboard
```

### 6.2 Database Backups

```bash
# Create backup script
cat > /var/www/alolabs-agent-hub/backup-db.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/var/backups/alolabs"
mkdir -p $BACKUP_DIR
DATE=$(date +%Y%m%d_%H%M%S)
cp /var/www/alolabs-agent-hub/db/custom.db "$BACKUP_DIR/custom_$DATE.db"
# Keep only last 30 backups
ls -t $BACKUP_DIR/custom_*.db | tail -n +31 | xargs rm -f 2>/dev/null
echo "Backup completed: custom_$DATE.db"
EOF

chmod +x /var/www/alolabs-agent-hub/backup-db.sh

# Run manually
./backup-db.sh

# Schedule automatic daily backup
crontab -e
# Add this line (runs at 2 AM every day):
# 0 2 * * * /var/www/alolabs-agent-hub/backup-db.sh >> /var/log/alolabs/backup.log 2>&1
```

### 6.3 Updating the Application

```bash
# On server: pull latest code
cd /var/www/alolabs-agent-hub
git pull origin main

# Rebuild
npm install
npx prisma generate
npm run build

# Restart
pm2 restart alolabs-agent-hub
```

### 6.4 Monitoring

```bash
# Check server resources
df -h              # Disk usage
free -m            # Memory usage
htop               # Real-time process monitor

# Check Nginx
nginx -t           # Test config
systemctl status nginx

# Check PM2
pm2 status
pm2 monit
```

---

## Step 7: Environment Variables

Create a `.env` file in the project root:

```env
# Database (SQLite - file path)
DATABASE_URL=file:/var/www/alolabs-agent-hub/db/custom.db

# Optional: Override port
PORT=3000

# Optional: Session secret (for production auth)
SESSION_SECRET=your-random-secret-here-change-this

# Optional: If you need to connect sister companies via API
# ALO_EDUCATION_API_URL=https://alo-education.example.com
# ENGLISH_AI_API_URL=https://english-ai.example.com
# ICLA_API_URL=https://icla.example.com
```

---

## Quick Start Summary (Cheat Sheet)

```bash
# === ON YOUR LAPTOP ===
# 1. Install & run locally
cd alolabs-agent-hub
npm install && npx prisma generate
npm run dev                    # → http://localhost:3000

# === ON YOUR VPS ===
# 2. One-time server setup
apt update && apt install -y nginx curl
curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt install -y nodejs
npm install -g pm2

# 3. Deploy
cd /var/www/alolabs-agent-hub
npm install && npx prisma generate && npm run build
pm2 start ecosystem.config.cjs && pm2 save && pm2 startup

# 4. Nginx
# (copy the nginx config from Step 3.6 above)
nginx -t && systemctl restart nginx

# 5. Cloudflare
# Add A record: @ → YOUR_SERVER_IP (Proxied)
# That's it! https://alolabs.net is live
```

---

## Troubleshooting

### Port 3000 already in use
```bash
lsof -i :3000           # Find what's using port 3000
kill -9 $(lsof -t -i:3000)  # Kill it
pm2 restart alolabs-agent-hub
```

### Database errors
```bash
# Regenerate Prisma client
npx prisma generate

# Reset and re-seed
npx prisma db push --force-reset
npx tsx scripts/seed-agenthub.ts
```

### 502 Bad Gateway from Cloudflare/Nginx
```bash
# Check if app is running
pm2 status
curl http://localhost:3000/api/health

# Check Nginx config
nginx -t
tail -f /var/log/nginx/error.log

# Check app logs
pm2 logs alolabs-agent-hub --lines 50
```

### Cloudflare SSL errors
- Go to SSL/TLS → Set mode to **Full** (not "Full (Strict)")
- Wait 15 minutes for Universal SSL to provision
- Clear browser cache / try incognito

### Permission denied errors
```bash
# Fix file ownership
chown -R www-data:www-data /var/www/alolabs-agent-hub
chmod -R 755 /var/www/alolabs-agent-hub
```

---

## File Structure Reference

```
alolabs-agent-hub/
├── src/
│   ├── app/
│   │   ├── api/           # 28 API route directories
│   │   │   ├── agents/        # Agent CRUD + search/paginate
│   │   │   ├── approvals/     # Approval queue
│   │   │   ├── audit-logs/    # Audit trail
│   │   │   ├── auth/          # Login/logout/me
│   │   │   ├── commands/      # Command center
│   │   │   ├── companies/     # 8 sister companies
│   │   │   ├── dashboard/     # Dashboard statistics
│   │   │   ├── departments/   # 100 departments
│   │   │   ├── deploy/        # Domain deployment
│   │   │   ├── health/        # System health
│   │   │   ├── memory/        # RAG memory
│   │   │   ├── payment-guard/ # Cost protection
│   │   │   ├── protection/    # Security rules
│   │   │   ├── self-improvement/ # Agent learning
│   │   │   ├── settings/      # System config
│   │   │   ├── skills/        # Skill registry
│   │   │   ├── tasks/         # Task management
│   │   │   ├── usage/         # Usage analytics
│   │   │   └── workflows/     # Workflow engine
│   │   ├── globals.css    # Cosmic dark theme (250+ lines)
│   │   ├── layout.tsx     # Root layout (dark mode)
│   │   └── page.tsx       # Main entry → AgentHubShell
│   ├── components/
│   │   ├── panels/        # 16 dashboard panels
│   │   │   ├── command-center.tsx
│   │   │   ├── companies-panel.tsx
│   │   │   ├── departments-panel.tsx
│   │   │   ├── agents-registry-panel.tsx
│   │   │   ├── workflows-panel.tsx
│   │   │   ├── tasks-panel.tsx
│   │   │   ├── usage-panel.tsx
│   │   │   ├── approvals-panel.tsx
│   │   │   ├── protection-panel.tsx
│   │   │   ├── payment-guard-panel.tsx
│   │   │   ├── audit-logs-panel.tsx
│   │   │   ├── memory-panel.tsx
│   │   │   ├── self-improvement-panel.tsx
│   │   │   ├── productivity-panel.tsx
│   │   │   ├── settings-panel.tsx
│   │   │   └── skills-panel.tsx
│   │   ├── ui/            # shadcn/ui components
│   │   └── agent-hub-shell.tsx  # Main app shell
│   ├── lib/               # DB client, API helpers, auth
│   ├── hooks/             # Custom React hooks
│   └── store/             # Zustand state management
├── prisma/
│   └── schema.prisma      # 40+ database models
├── db/
│   └── custom.db          # SQLite database (seeded)
├── scripts/
│   └── seed-agenthub.ts   # Database seeder
├── package.json
├── next.config.ts
├── tsconfig.json
├── .env
└── DEPLOYMENT.md
```

---

## Security Checklist for Production

- [x] `.env` file is NOT committed to git
- [x] Change default admin password immediately after first login
- [x] Cloudflare proxy enabled (hides server IP)
- [x] UFW firewall configured (only SSH + Nginx ports open)
- [x] Nginx security headers configured
- [x] PM2 auto-restart on crash
- [x] Regular database backups scheduled
- [ ] Consider adding rate limiting (Cloudflare free plan or Nginx)
- [ ] Consider adding 2FA for admin login
- [ ] Set up server monitoring (UptimeRobot free tier)