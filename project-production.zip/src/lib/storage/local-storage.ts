/**
 * Local Filesystem Storage Provider
 * Implements IStorageProvider for local disk storage with HMAC-signed URLs,
 * thumbnail generation, and directory-based file organization.
 */

import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import type {
  StorageConfig,
  UploadedFile,
  UploadOptions,
  StorageStats,
  IStorageProvider,
} from './types';
import { MediaProcessor } from './media-processor';

const DEFAULT_BASE_PATH = './storage';
const MAX_FILE_SIZE = 5 * 1024 * 1024 * 1024;
const SIGNING_SECRET = process.env.STORAGE_SIGNING_SECRET || 'alo-labs-storage-signing-key';
const DEFAULT_EXPIRY = 3600;

function sanitizeFilename(filename: string): string {
  const base = path.basename(filename).replace(/\s+/g, '-');
  return crypto.randomUUID() + '-' + base;
}

function resolveFilePath(basePath: string, fileId: string): string {
  const safeId = path.normalize(fileId).replace(/^\.\.[\/\\]/, '');
  return path.join(basePath, safeId);
}

function verifySignature(payload: string, signature: string, secret: string): boolean {
  const expected = crypto.createHmac('sha256', secret).update(payload).digest('hex');
  return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
}

async function ensureDir(dirPath: string): Promise<void> {
  await fs.mkdir(dirPath, { recursive: true });
}

export class LocalStorageProvider implements IStorageProvider {
  private basePath: string;
  private mediaProcessor: MediaProcessor;

  constructor(config?: { basePath?: string }) {
    this.basePath = path.resolve(config?.basePath || DEFAULT_BASE_PATH);
    this.mediaProcessor = new MediaProcessor();
  }

  async upload(file: Buffer, originalName: string, options?: UploadOptions): Promise<UploadedFile> {
    if (file.length === 0) {
      throw new Error('File is empty');
    }
    if (file.length > MAX_FILE_SIZE) {
      throw new Error(`File exceeds maximum size of ${MAX_FILE_SIZE / (1024 * 1024 * 1024)} GB`);
    }

    const folder = options?.folder || 'uploads';
    const filename = sanitizeFilename(originalName);
    const fileId = `${folder}/${filename}`;
    const filePath = resolveFilePath(this.basePath, fileId);

    await ensureDir(path.dirname(filePath));
    await fs.writeFile(filePath, file);

    let thumbnailUrl: string | undefined;
    if (options?.generateThumbnail !== false) {
      const detectedType = this.mediaProcessor.detectImageType(file);
      if (detectedType) {
        try {
          thumbnailUrl = await this.generateThumbnail(fileId, 200, 200);
        } catch {
          // Thumbnail generation is best-effort
        }
      }
    }

    return {
      id: fileId,
      filename,
      originalName,
      mimeType: this.detectMimeType(file, originalName),
      size: file.length,
      url: this.getPublicUrl(fileId),
      thumbnailUrl,
      uploadedBy: options?.folder || 'system',
      companyId: 'default',
      createdAt: new Date(),
    };
  }

  async download(fileId: string): Promise<Buffer> {
    const filePath = resolveFilePath(this.basePath, fileId);
    try {
      return await fs.readFile(filePath);
    } catch {
      throw new Error(`File not found: ${fileId}`);
    }
  }

  async delete(fileId: string): Promise<void> {
    const filePath = resolveFilePath(this.basePath, fileId);
    try {
      await fs.unlink(filePath);
      const thumbPath = filePath.replace(/(\.[^.]+)$/, '_thumb$1');
      await fs.unlink(thumbPath).catch(() => {});
      let dir = path.dirname(filePath);
      for (let i = 0; i < 3; i++) {
        try {
          const files = await fs.readdir(dir);
          if (files.length === 0) {
            await fs.rmdir(dir);
            dir = path.dirname(dir);
          } else {
            break;
          }
        } catch {
          break;
        }
      }
    } catch {
      throw new Error(`File not found: ${fileId}`);
    }
  }

  async list(prefix?: string): Promise<UploadedFile[]> {
    const searchDir = prefix
      ? resolveFilePath(this.basePath, prefix)
      : this.basePath;

    const files: UploadedFile[] = [];
    try {
      await this.readdirRecursive(searchDir, this.basePath, files);
    } catch {
      // Directory may not exist yet
    }
    return files;
  }

  async getStats(): Promise<StorageStats> {
    const byType = new Map<string, number>();
    const byMonth = new Map<string, number>();
    let totalFiles = 0;
    let totalSize = 0;

    try {
      await this.statRecursive(this.basePath, byType, byMonth);
    } catch {
      // Directory may not exist yet
    }

    for (const size of byType.values()) {
      totalSize += size;
      totalFiles++;
    }

    return { totalFiles, totalSize, byType, byMonth };
  }

  async generateThumbnail(fileId: string, width: number, height: number): Promise<string> {
    const filePath = resolveFilePath(this.basePath, fileId);
    const buffer = await fs.readFile(filePath);
    const thumbBuffer = await this.mediaProcessor.generateThumbnail(buffer, width, height);
    const ext = path.extname(filePath);
    const thumbPath = filePath.replace(/(\.[^.]+)$/, `_thumb${ext}`);
    const thumbFileId = fileId.replace(/(\.[^.]+)$/, `_thumb$1`);
    await fs.writeFile(thumbPath, thumbBuffer);
    return this.getPublicUrl(thumbFileId);
  }

  getPublicUrl(fileId: string): string {
    return `/api/storage/files/${fileId}`;
  }

  getSignedUrl(fileId: string, expiresInSec: number = DEFAULT_EXPIRY): string {
    const expires = Math.floor(Date.now() / 1000) + expiresInSec;
    const payload = `${fileId}:${expires}`;
    const signature = crypto.createHmac('sha256', SIGNING_SECRET).update(payload).digest('hex');
    return `/api/storage/files/${fileId}?expires=${expires}&sig=${signature}`;
  }

  verifySignedUrl(fileId: string, expires: number, sig: string): boolean {
    if (Date.now() / 1000 > expires) {
      return false;
    }
    const payload = `${fileId}:${expires}`;
    return verifySignature(payload, sig, SIGNING_SECRET);
  }

  private async readdirRecursive(
    dir: string,
    basePath: string,
    results: UploadedFile[]
  ): Promise<void> {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        await this.readdirRecursive(fullPath, basePath, results);
      } else if (entry.isFile()) {
        const relativePath = path.relative(basePath, fullPath);
        let mimeType = 'application/octet-stream';
        try {
          const buffer = await fs.readFile(fullPath).then(b => b.subarray(0, 32));
          const detected = this.mediaProcessor.detectImageType(buffer);
          if (detected) mimeType = detected;
        } catch {
          // Use default mime type
        }
        let thumbnailUrl: string | undefined;
        try {
          const thumbPath = fullPath.replace(/(\.[^.]+)$/, '_thumb$1');
          await fs.access(thumbPath);
          const thumbRelative = path.relative(basePath, thumbPath);
          thumbnailUrl = `/api/storage/files/${thumbRelative}`;
        } catch {
          // No thumbnail
        }
        const stat = await fs.stat(fullPath);
        results.push({
          id: relativePath,
          filename: entry.name,
          originalName: entry.name,
          mimeType,
          size: stat.size,
          url: `/api/storage/files/${relativePath}`,
          thumbnailUrl,
          uploadedBy: 'system',
          companyId: 'default',
          createdAt: stat.mtime,
        });
      }
    }
  }

  private async statRecursive(
    dir: string,
    byType: Map<string, number>,
    byMonth: Map<string, number>
  ): Promise<void> {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        await this.statRecursive(fullPath, byType, byMonth);
      } else if (entry.isFile()) {
        const stat = await fs.stat(fullPath);
        const ext = path.extname(entry.name).toLowerCase().replace('.', '') || 'other';
        byType.set(ext, (byType.get(ext) || 0) + stat.size);
        const month = stat.mtime.toISOString().substring(0, 7);
        byMonth.set(month, (byMonth.get(month) || 0) + stat.size);
      }
    }
  }

  private detectMimeType(buffer: Buffer, filename: string): string {
    const imageType = this.mediaProcessor.detectImageType(buffer);
    if (imageType) return imageType;
    const ext = path.extname(filename).toLowerCase();
    const mimeMap: Record<string, string> = {
      '.pdf': 'application/pdf',
      '.doc': 'application/msword',
      '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      '.xls': 'application/vnd.ms-excel',
      '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      '.txt': 'text/plain',
      '.csv': 'text/csv',
      '.json': 'application/json',
      '.xml': 'application/xml',
      '.zip': 'application/zip',
      '.mp3': 'audio/mpeg',
      '.mp4': 'video/mp4',
      '.svg': 'image/svg+xml',
      '.webp': 'image/webp',
    };
    return mimeMap[ext] || 'application/octet-stream';
  }
}
