import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { processQueue } from '@/lib/job-queue';

/**
 * POST /api/queues/[id]/process — trigger manual processing of a queue.
 *
 * The handler dispatches on `jobType` and executes the appropriate
 * registered handler. For now this is a no-op stub that marks jobs
 * as completed so the pipeline is functional end-to-end.
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  // Auth check
  const authHeader = request.headers.get('authorization');
  const token = authHeader?.replace('Bearer ', '');
  if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { verifySessionToken } = await import('@/lib/auth');
  const session = await verifySessionToken(token);
  if (!session) return NextResponse.json({ error: 'Invalid token' }, { status: 401 });

  try {
    const { id } = await params;

    // Look up queue by ID to get the queue name
    const queue = await db.jobQueue.findUnique({ where: { id } });
    if (!queue) {
      return NextResponse.json({ error: 'Queue not found' }, { status: 404 });
    }

    if (!queue.isActive) {
      return NextResponse.json({ error: 'Queue is not active' }, { status: 400 });
    }

    // Process the queue with a default no-op handler.
    // In a real system, handlers are registered per jobType.
    const results = await processQueue(queue.name, async (job) => {
      // Default handler: attempt to dynamically dispatch by jobType.
      // For now, return a stub acknowledgement.
      return {
        processed: true,
        jobType: job.jobType,
        jobId: job.id,
        timestamp: new Date().toISOString(),
      };
    });

    const summary = {
      total: results.length,
      completed: results.filter((r) => r.status === 'completed').length,
      failed: results.filter((r) => r.status === 'failed').length,
      requeued: results.filter((r) => r.status === 'queued').length,
    };

    return NextResponse.json({ data: { results, summary } });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Internal server error';
    console.error('POST /api/queues/[id]/process error:', error);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
