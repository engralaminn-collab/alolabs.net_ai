import { NextRequest, NextResponse } from 'next/server'
import { isMinioConnected, listObjects, putObject } from '@/lib/minio'

// GET: List objects
export async function GET(request: NextRequest) {
  // Auth check
  const authHeader = request.headers.get('authorization');
  const token = authHeader?.replace('Bearer ', '');
  if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { verifySessionToken } = await import('@/lib/auth');
  const session = await verifySessionToken(token);
  if (!session) return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
  try {
    const { searchParams } = new URL(request.url)
    const prefix = searchParams.get('prefix') || ''
    const limit = parseInt(searchParams.get('limit') || '100', 10)

    const objects = await listObjects(prefix, limit)

    return NextResponse.json({
      connected: isMinioConnected(),
      objects,
      count: objects.length,
      prefix,
    })
  } catch (error) {
    console.error('[Infra MinIO Objects GET] Error:', error)
    return NextResponse.json({ error: 'Failed to list objects' }, { status: 500 })
  }
}

// POST: Upload object (FormData with file + key)
export async function POST(request: NextRequest) {
  // Auth check
  const authHeader = request.headers.get('authorization');
  const token = authHeader?.replace('Bearer ', '');
  if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { verifySessionToken } = await import('@/lib/auth');
  const session = await verifySessionToken(token);
  if (!session) return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File | null
    const key = formData.get('key') as string | null

    if (!file) {
      return NextResponse.json({ error: 'file field is required in FormData' }, { status: 400 })
    }

    if (!key || typeof key !== 'string') {
      return NextResponse.json({ error: 'key field is required in FormData' }, { status: 400 })
    }

    const buffer = await file.arrayBuffer()
    const contentType = file.type || 'application/octet-stream'

    const result = await putObject(key, buffer, contentType)

    return NextResponse.json({
      success: true,
      key: result.key,
      size: result.size,
      storageType: result.storageType,
      message: `Object uploaded to ${result.storageType}`,
    })
  } catch (error) {
    console.error('[Infra MinIO Objects POST] Error:', error)
    return NextResponse.json({ error: 'Failed to upload object' }, { status: 500 })
  }
}