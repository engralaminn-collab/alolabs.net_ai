/**
 * Storage CDN API
 * GET: Generate signed CDN/accessible URLs for one or more files.
 * Supports configurable expiry time and bulk URL generation.
 */

import { NextRequest, NextResponse } from 'next/server';
import { verifySessionToken } from '@/lib/auth';
import { StorageFactory, LocalStorageProvider, S3StorageProvider } from '@/lib/storage';
import type { StorageConfig } from '@/lib/storage';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function resolveStorage() {
  const provider = process.env.STORAGE_PROVIDER || 'local';
  const config: StorageConfig = { provider } as StorageConfig;

  if (provider === 's3' || provider === 'minio') {
    config.endpoint = process.env.S3_ENDPOINT || process.env.MINIO_HOST || '';
    config.bucket = process.env.S3_BUCKET || process.env.MINIO_BUCKET || 'agent-hub';
    config.accessKey = process.env.S3_ACCESS_KEY || process.env.MINIO_ACCESS_KEY || '';
    config.secretKey = process.env.S3_SECRET_KEY || process.env.MINIO_SECRET_KEY || '';
    config.region = process.env.S3_REGION || process.env.MINIO_REGION || 'us-east-1';
    config.cdnUrl = process.env.S3_CDN_URL || process.env.MINIO_CDN_URL || undefined;
    config.port = process.env.S3_PORT || process.env.MINIO_PORT
      ? parseInt(process.env.S3_PORT || process.env.MINIO_PORT!, 10)
      : undefined;
    config.useSSL = process.env.S3_SSL === 'true' || process.env.MINIO_SSL === 'true';
  }

  return StorageFactory.createStorage(config);
}

// ─── GET: Generate Signed URLs ────────────────────────────────────────────────

export async function GET(request: NextRequest) {
  try {
    // ── Auth ─────────────────────────────────────────────────────────────
    const authHeader = request.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const session = await verifySessionToken(token);
    if (!session) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const url = new URL(request.url);

    // ── Parse parameters ─────────────────────────────────────────────────
    const key = url.searchParams.get('key');
    const keys = url.searchParams.get('keys');
    const expiresIn = Math.min(
      604800, // max 7 days
      Math.max(60, parseInt(url.searchParams.get('expires') || '3600', 10)) // min 1 minute
    );
    const action = url.searchParams.get('action') || 'read'; // read | write

    // Collect all requested keys
    const requestedKeys: string[] = [];
    if (key) requestedKeys.push(key);
    if (keys) requestedKeys.push(...keys.split(',').map(k => k.trim()).filter(Boolean));

    if (requestedKeys.length === 0) {
      return NextResponse.json(
        { error: 'Provide ?key=single-key or ?keys=key1,key2,key3' },
        { status: 400 }
      );
    }

    if (requestedKeys.length > 50) {
      return NextResponse.json(
        { error: 'Maximum 50 keys per request' },
        { status: 400 }
      );
    }

    // ── Generate URLs ────────────────────────────────────────────────────
    const storage = resolveStorage();
    const urls: Array<{ key: string; url: string; expiresAt: string; provider: string }> = [];

    for (const fileKey of requestedKeys) {
      let signedUrl: string;

      if (storage instanceof LocalStorageProvider) {
        // Local storage uses HMAC-signed query params
        if (action === 'write') {
          // For write, return the upload endpoint URL
          signedUrl = `/api/storage/upload?key=${encodeURIComponent(fileKey)}&expires=${Math.floor(Date.now() / 1000) + expiresIn}`;
        } else {
          if (storage.getSignedUrl) {
            signedUrl = storage.getSignedUrl(fileKey, expiresIn);
          } else {
            signedUrl = storage.getPublicUrl(fileKey);
          }
        }
      } else if (storage instanceof S3StorageProvider) {
        // S3 provider has native presigned URL support
        if (action === 'write') {
          signedUrl = await storage.getPresignedPutUrl(fileKey, 'application/octet-stream', expiresIn);
        } else {
          signedUrl = await storage.getPresignedGetUrl(fileKey, expiresIn);
        }
      } else {
        // Fallback to public URL
        signedUrl = storage.getPublicUrl(fileKey);
      }

      const expiresAt = new Date(Date.now() + expiresIn * 1000).toISOString();
      const providerName = process.env.STORAGE_PROVIDER || 'local';

      urls.push({
        key: fileKey,
        url: signedUrl,
        expiresAt,
        provider: providerName,
      });
    }

    return NextResponse.json({
      urls,
      expiresIn,
      generatedAt: new Date().toISOString(),
      count: urls.length,
    });
  } catch (err: unknown) {
    console.error('[Storage CDN] GET error:', err);
    const message = err instanceof Error ? err.message : 'Internal server error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}