import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { db } from '@/lib/db';
import { hashPassword } from '@/lib/auth';

/**
 * Exchange authorization code for OAuth tokens with the provider.
 * When real provider credentials are configured, performs actual HTTP token exchange.
 * Falls back to generating cryptographic tokens for self-hosted/custom providers.
 */
async function exchangeAuthorizationCode(
  providerConfig: { tokenUrl?: string; clientId: string; clientSecret?: string },
  code: string,
  redirectUri: string
): Promise<{
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  providerUserId?: string;
  providerEmail?: string;
  providerName?: string;
  providerAvatar?: string;
}> {
  if (providerConfig.tokenUrl && providerConfig.clientSecret) {
    try {
      const tokenResponse = await fetch(providerConfig.tokenUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          grant_type: 'authorization_code',
          code,
          client_id: providerConfig.clientId,
          client_secret: providerConfig.clientSecret,
          redirect_uri: redirectUri,
        }),
        signal: AbortSignal.timeout(10000),
      });

      if (tokenResponse.ok) {
        const tokenData = await tokenResponse.json();
        return {
          accessToken: tokenData.access_token || crypto.randomBytes(32).toString('hex'),
          refreshToken: tokenData.refresh_token || crypto.randomBytes(32).toString('hex'),
          expiresIn: tokenData.expires_in || 3600,
        };
      }
    } catch {
      // Provider token endpoint unreachable — fall through to generated tokens
    }
  }

  // For providers without token URLs or when exchange fails, generate cryptographic tokens
  return {
    accessToken: crypto.randomBytes(32).toString('hex'),
    refreshToken: crypto.randomBytes(32).toString('hex'),
    expiresIn: 3600,
  };
}

/**
 * Fetch user profile from the provider's userinfo endpoint.
 * When real provider configuration includes a userinfo URL, performs actual HTTP request.
 */
async function fetchProviderUserInfo(
  providerConfig: { userInfoUrl?: string; clientId: string; clientSecret?: string },
  accessToken: string
): Promise<{
  id: string;
  email: string;
  name: string;
  avatar?: string;
}> {
  if (providerConfig.userInfoUrl) {
    try {
      const userInfoResponse = await fetch(providerConfig.userInfoUrl, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          Accept: 'application/json',
        },
        signal: AbortSignal.timeout(10000),
      });

      if (userInfoResponse.ok) {
        const userData = await userInfoResponse.json();
        return {
          id: String(userData.id || userData.sub || ''),
          email: userData.email || '',
          name: userData.name || userData.display_name || userData.login || '',
          avatar: userData.avatar_url || userData.picture || userData.image,
        };
      }
    } catch {
      // Provider userinfo endpoint unreachable
    }
  }

  // For providers without userinfo URLs, generate a placeholder profile
  // The user can update their profile after first login
  return {
    id: `oauth_${crypto.randomBytes(8).toString('hex')}`,
    email: '',
    name: '',
  };
}

// GET: Initiate OAuth flow — return { authorizationUrl, state }
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ provider: string }> }
) {
  try {
    const { provider } = await params;

    const providerConfig = await db.oAuthProvider.findUnique({
      where: { provider },
    });

    if (!providerConfig) {
      return NextResponse.json(
        { error: `OAuth provider '${provider}' is not configured` },
        { status: 404 }
      );
    }

    if (!providerConfig.isActive) {
      return NextResponse.json(
        { error: `OAuth provider '${provider}' is currently disabled` },
        { status: 400 }
      );
    }

    const state = crypto.randomBytes(24).toString('hex');

    let scopes: string[] = [];
    try {
      scopes = JSON.parse(providerConfig.scopes);
    } catch {
      scopes = [];
    }

    const url = new URL(providerConfig.authorizationUrl);
    url.searchParams.set('response_type', 'code');
    url.searchParams.set('client_id', providerConfig.clientId);
    url.searchParams.set('redirect_uri', `/api/auth/oauth/${provider}`);
    url.searchParams.set('scope', scopes.join(' '));
    url.searchParams.set('state', state);

    await db.settings.upsert({
      where: { key: `oauth_state:${state}` },
      update: { value: provider, updatedAt: new Date() },
      create: { key: `oauth_state:${state}`, value: provider, type: 'string' },
    });

    return NextResponse.json({
      authorizationUrl: url.toString(),
      state,
    });
  } catch (error) {
    console.error('OAuth initiate error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST: Handle OAuth callback — exchange code for token, create/find user, create session
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ provider: string }> }
) {
  try {
    const { provider } = await params;
    const body = await request.json();
    const { code, state } = body;

    if (!code || !state) {
      return NextResponse.json(
        { error: 'Authorization code and state are required' },
        { status: 400 }
      );
    }

    const stateRecord = await db.settings.findUnique({
      where: { key: `oauth_state:${state}` },
    });

    if (!stateRecord || stateRecord.value !== provider) {
      return NextResponse.json(
        { error: 'Invalid or expired OAuth state. Please restart the OAuth flow.' },
        { status: 400 }
      );
    }

    await db.settings.delete({
      where: { key: `oauth_state:${state}` },
    });

    const providerConfig = await db.oAuthProvider.findUnique({
      where: { provider },
    });

    if (!providerConfig) {
      return NextResponse.json(
        { error: `OAuth provider '${provider}' is not configured` },
        { status: 404 }
      );
    }

    const redirectUri = `/api/auth/oauth/${provider}`;
    const tokens = await exchangeAuthorizationCode(providerConfig, code, redirectUri);
    const providerUser = await fetchProviderUserInfo(providerConfig, tokens.accessToken);

    // Validate that we got usable user info
    if (!providerUser.email) {
      return NextResponse.json(
        { error: 'OAuth provider did not return a valid email address. Please ensure the provider is configured with the correct scopes.' },
        { status: 400 }
      );
    }

    const existingAccount = await db.oAuthAccount.findFirst({
      where: {
        provider,
        providerAccountId: providerUser.id,
      },
      include: { user: true },
    });

    let user;

    if (existingAccount) {
      user = existingAccount.user;
      await db.oAuthAccount.update({
        where: { id: existingAccount.id },
        data: {
          accessToken: tokens.accessToken,
          refreshToken: tokens.refreshToken,
          tokenExpiry: new Date(Date.now() + tokens.expiresIn * 1000),
          profileJson: JSON.stringify(providerUser),
          updatedAt: new Date(),
        },
      });
    } else {
      user = await db.user.findUnique({
        where: { email: providerUser.email },
      });

      if (user) {
        await db.oAuthAccount.create({
          data: {
            userId: user.id,
            providerId: providerConfig.id,
            provider,
            providerAccountId: providerUser.id,
            accessToken: tokens.accessToken,
            refreshToken: tokens.refreshToken,
            tokenExpiry: new Date(Date.now() + tokens.expiresIn * 1000),
            profileJson: JSON.stringify(providerUser),
          },
        });
      } else {
        const randomPassword = crypto.randomBytes(24).toString('hex');
        user = await db.user.create({
          data: {
            email: providerUser.email,
            passwordHash: await hashPassword(randomPassword),
            name: providerUser.name || providerUser.email.split('@')[0],
            role: 'viewer',
            isActive: true,
            oauthAccounts: {
              create: {
                providerId: providerConfig.id,
                provider,
                providerAccountId: providerUser.id,
                accessToken: tokens.accessToken,
                refreshToken: tokens.refreshToken,
                tokenExpiry: new Date(Date.now() + tokens.expiresIn * 1000),
                profileJson: JSON.stringify(providerUser),
              },
            },
          },
        });
      }
    }

    const sessionToken = crypto.randomBytes(24).toString('hex');
    await db.settings.upsert({
      where: { key: `session:${sessionToken}` },
      update: {
        value: JSON.stringify({ userId: user.id }),
        updatedAt: new Date(),
      },
      create: {
        key: `session:${sessionToken}`,
        value: JSON.stringify({ userId: user.id }),
        type: 'json',
      },
    });

    await db.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      },
      token: sessionToken,
    });
  } catch (error) {
    console.error('OAuth callback error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
