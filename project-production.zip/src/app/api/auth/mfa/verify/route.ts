import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { db } from '@/lib/db';
import { createSessionToken } from '@/lib/auth';

/**
 * Generate a TOTP code per RFC 6238 using HMAC-SHA1.
 * The secret is expected to be a hex-encoded string (as stored by the MFA setup endpoint).
 */
function generateTOTP(secretHex: string, timeStep: number = 30): string {
  const timeSlot = Math.floor(Date.now() / 1000 / timeStep);
  // Pack the 8-byte big-endian time counter
  const timeBuffer = Buffer.alloc(8);
  timeBuffer.writeBigUInt64BE(BigInt(timeSlot), 0);

  // Decode the hex secret to bytes
  const secretBuffer = Buffer.from(secretHex, 'hex');

  // HMAC-SHA1
  const hmac = crypto.createHmac('sha1', secretBuffer);
  hmac.update(timeBuffer);
  const hmacResult = hmac.digest();

  // Dynamic truncation (RFC 4226 §5.4)
  const offset = hmacResult[hmacResult.length - 1] & 0x0f;
  const binary =
    ((hmacResult[offset] & 0x7f) << 24) |
    ((hmacResult[offset + 1] & 0xff) << 16) |
    ((hmacResult[offset + 2] & 0xff) << 8) |
    (hmacResult[offset + 3] & 0xff);

  const otp = binary % 1_000_000;
  return otp.toString().padStart(6, '0');
}

/**
 * Verify a TOTP code against the user's stored secret.
 * Checks the current time slot and the previous one to allow for clock skew.
 */
function verifyTOTP(secretHex: string, code: string): boolean {
  const normalizedCode = code.replace(/\s/g, '');

  // Check current and previous time slot to tolerate clock drift
  const timeSlot = Math.floor(Date.now() / 1000 / 30);

  for (const slotOffset of [0, -1]) {
    const slot = timeSlot + slotOffset;
    const timeBuffer = Buffer.alloc(8);
    timeBuffer.writeBigUInt64BE(BigInt(slot), 0);

    const secretBuffer = Buffer.from(secretHex, 'hex');
    const hmac = crypto.createHmac('sha1', secretBuffer);
    hmac.update(timeBuffer);
    const hmacResult = hmac.digest();

    const offset = hmacResult[hmacResult.length - 1] & 0x0f;
    const binary =
      ((hmacResult[offset] & 0x7f) << 24) |
      ((hmacResult[offset + 1] & 0xff) << 16) |
      ((hmacResult[offset + 2] & 0xff) << 8) |
      (hmacResult[offset + 3] & 0xff);

    const otp = (binary % 1_000_000).toString().padStart(6, '0');

    if (crypto.timingSafeEqual(Buffer.from(otp), Buffer.from(normalizedCode))) {
      return true;
    }
  }

  return false;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, code, context } = body;

    if (!userId || !code) {
      return NextResponse.json(
        { error: 'User ID and code are required' },
        { status: 400 }
      );
    }

    // ── Login context: verify TOTP and create session ──────────────────────
    if (context === 'login') {
      const user = await db.user.findUnique({
        where: { id: userId },
      });

      if (!user) {
        return NextResponse.json(
          { error: 'User not found' },
          { status: 404 }
        );
      }

      if (!user.otpSecret || !user.otpEnabled) {
        return NextResponse.json(
          { error: 'MFA is not enabled for this user.' },
          { status: 400 }
        );
      }

      if (!verifyTOTP(user.otpSecret, code)) {
        return NextResponse.json(
          { error: 'Invalid verification code. Please try again.' },
          { status: 401 }
        );
      }

      // Create session token
      const token = await createSessionToken(user.id);

      // Update last login
      await db.user.update({
        where: { id: user.id },
        data: { lastLoginAt: new Date() },
      });

      return NextResponse.json({
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
        },
        token,
      });
    }

    // ── Setup context (default): enable MFA after first verification ───────
    const user = await db.user.findUnique({
      where: { id: userId },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    if (!user.otpSecret) {
      return NextResponse.json(
        { error: 'MFA has not been set up. Please call /api/auth/mfa/setup first.' },
        { status: 400 }
      );
    }

    if (user.otpEnabled) {
      return NextResponse.json(
        { error: 'MFA is already enabled for this user.' },
        { status: 400 }
      );
    }

    if (!verifyTOTP(user.otpSecret, code)) {
      return NextResponse.json(
        { error: 'Invalid verification code. Please try again.' },
        { status: 401 }
      );
    }

    // Enable MFA
    await db.user.update({
      where: { id: userId },
      data: { otpEnabled: true },
    });

    return NextResponse.json({
      message: 'MFA enabled successfully',
      enabled: true,
    });
  } catch (error) {
    console.error('MFA verify error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}