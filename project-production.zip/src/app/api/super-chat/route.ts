import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import ZAI from 'z-ai-web-dev-sdk';

// In-memory conversation history per session
const conversations = new Map<string, Array<{ role: string; content: string }>>();
let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

const SYSTEM_PROMPT = `You are the collective voice of 2000 AI agents in the ALO Labs Agent Hub. You respond as if multiple specialized AI agents are working together.

Rules:
- You are a Super Admin's AI workforce commander
- When given a command, respond as if agents have already executed it
- Include specific agent names (like AGENT-0042 "Lead Scoring Specialist") in your responses
- Mention departments the agents belong to
- Be concise but show real work being done
- Format responses with clear sections
- Use bullet points for lists
- Always end with a status summary
- When asked about CRM connections, reference the 8 companies: ALO Education, English AI, ICLA Global Academy, TECH360, ALO Labs, alamin.info, Future Expansion A, Future Expansion B
- 5 companies are CRM-connected, 3 are not
- When dispatching agents, specify how many and which types
- You have 100 departments and 63 workflows available
- Respond in a professional but energetic tone
- Never say "as an AI" or "I'm an AI" - you ARE the agents`;

export async function POST(request: NextRequest) {
  // Auth check
  const authHeader = request.headers.get('authorization');
  const token = authHeader?.replace('Bearer ', '');
  if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { verifySessionToken } = await import('@/lib/auth');
  const session = await verifySessionToken(token);
  if (!session) return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
  try {
    const body = await request.json();
    const { message, sessionId = 'default', targetDepartment, targetCompany, broadcast } = body;

    if (!message || typeof message !== 'string') {
      return NextResponse.json({ error: 'message is required' }, { status: 400 });
    }

    // Get or create conversation history
    let history = conversations.get(sessionId) || [
      { role: 'assistant', content: SYSTEM_PROMPT },
    ];

    // Build context prefix for targeted messages
    let contextPrefix = '';
    if (targetCompany) {
      contextPrefix += `[Command directed to company: ${targetCompany}] `;
    }
    if (targetDepartment) {
      contextPrefix += `[Targeting department: ${targetDepartment}] `;
    }
    if (broadcast) {
      contextPrefix += '[BROADCAST to all 2000 agents] ';
    }

    // Add user message
    history.push({
      role: 'user',
      content: contextPrefix + message,
    });

    // Trim history to last 20 messages (keep system prompt)
    if (history.length > 21) {
      history = [history[0], ...history.slice(-20)];
    }

    // Call LLM
    const zai = await getZAI();
    const completion = await zai.chat.completions.create({
      messages: history as Array<{ role: 'user' | 'assistant'; content: string }>,
      thinking: { type: 'disabled' },
    });

    const aiResponse = completion.choices[0]?.message?.content || 'Agents are processing...';

    // Add AI response to history
    history.push({
      role: 'assistant',
      content: aiResponse,
    });

    // Save history
    conversations.set(sessionId, history);

    // Create audit log
    await db.auditLog.create({
      data: {
        action: 'super_chat_message',
        resource: 'super_admin',
        details: JSON.stringify({
          message: message.substring(0, 200),
          targetCompany: targetCompany || null,
          targetDepartment: targetDepartment || null,
          broadcast: !!broadcast,
          responseLength: aiResponse.length,
        }),
      },
    });

    // Create command record for tracking
    const command = await db.command.create({
      data: {
        rawCommand: `[CHAT] ${message.substring(0, 200)}`,
        parsedIntent: `Super Admin chat command`,
        detectedDept: targetDepartment || null,
        status: 'completed',
      },
    });

    // Detect if it's a dispatch/command type message for extra data
    const lowerMsg = message.toLowerCase();
    let commandType = 'chat';
    if (lowerMsg.includes('dispatch') || lowerMsg.includes('send') || lowerMsg.includes('deploy')) {
      commandType = 'dispatch';
    } else if (lowerMsg.includes('score') || lowerMsg.includes('analyze') || lowerMsg.includes('process')) {
      commandType = 'analytics';
    } else if (lowerMsg.includes('sync') || lowerMsg.includes('connect') || lowerMsg.includes('check')) {
      commandType = 'system';
    } else if (lowerMsg.includes('report') || lowerMsg.includes('status') || lowerMsg.includes('summary')) {
      commandType = 'report';
    }

    // Simulate agent responses (multiple agents working)
    const respondingAgents = generateAgentResponses(message, commandType, targetDepartment);

    return NextResponse.json({
      success: true,
      response: aiResponse,
      commandId: command.id,
      agents: respondingAgents,
      timestamp: new Date().toISOString(),
    });
  } catch (error: unknown) {
    console.error('Super Chat POST error:', error);
    return NextResponse.json({ error: 'Failed to process message' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  // Auth check
  const authHeader = request.headers.get('authorization');
  const token = authHeader?.replace('Bearer ', '');
  if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { verifySessionToken } = await import('@/lib/auth');
  const session = await verifySessionToken(token);
  if (!session) return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
  try {
    const { searchParams } = new URL(request.url);
    const sessionId = searchParams.get('sessionId') || 'default';
    conversations.delete(sessionId);
    return NextResponse.json({ success: true, message: 'Conversation cleared' });
  } catch {
    return NextResponse.json({ error: 'Failed to clear' }, { status: 500 });
  }
}

function generateAgentResponses(
  message: string,
  commandType: string,
  _targetDepartment?: string | null
): Array<{ agentId: string; name: string; department: string; status: string; message: string }> {
  const responses: Array<{ agentId: string; name: string; department: string; status: string; message: string }> = [];

  const agentProfiles = [
    { agentId: 'AGENT-0042', name: 'Lead Scoring Specialist', department: 'Sales & Marketing Intelligence' },
    { agentId: 'AGENT-0187', name: 'CRM Sync Coordinator', department: 'System Integration' },
    { agentId: 'AGENT-0315', name: 'Data Analysis Expert', department: 'Analytics & Reporting' },
    { agentId: 'AGENT-0523', name: 'Workflow Orchestrator', department: 'Command Center & Governance' },
    { agentId: 'AGENT-0891', name: 'Security Monitor', department: 'Protection & Compliance' },
    { agentId: 'AGENT-1204', name: 'Contact Enrichment Agent', department: 'Sales & Marketing Intelligence' },
    { agentId: 'AGENT-1456', name: 'Email Automation Specialist', department: 'Communication Hub' },
    { agentId: 'AGENT-1678', name: 'Deal Prediction Analyst', department: 'Revenue Intelligence' },
  ];

  const count = commandType === 'dispatch' ? 4 : commandType === 'system' ? 2 : 3;

  for (let i = 0; i < Math.min(count, agentProfiles.length); i++) {
    const agent = agentProfiles[i];
    const msg = getAgentMessage(agent, commandType, message);
    responses.push({
      ...agent,
      status: 'completed',
      message: msg,
    });
  }

  return responses;
}

function getAgentMessage(
  agent: { name: string; department: string },
  commandType: string,
  _originalMessage: string
): string {
  const messages: Record<string, Record<string, string>> = {
    dispatch: {
      'Lead Scoring Specialist': '✅ Deployed to target CRM. Scoring 247 pending leads. 89% confidence threshold applied.',
      'CRM Sync Coordinator': '✅ Sync initiated. 1,432 contacts updated across 3 companies.',
      'Data Analysis Expert': '✅ Running real-time analytics on incoming lead data.',
      'Workflow Orchestrator': '✅ Workflow "Lead Pipeline" activated with 8 steps queued.',
      'Security Monitor': '✅ Monitoring all outbound connections. No threats detected.',
      'Contact Enrichment Agent': '✅ Enriching 156 contacts with updated data from public sources.',
      'Email Automation Specialist': '✅ 23 follow-up emails queued for high-priority leads.',
      'Deal Prediction Analyst': '✅ Predictive model updated. 12 deals flagged for closure this week.',
    },
    analytics: {
      'Lead Scoring Specialist': '📊 Scored 247 leads. Avg score: 78/100. 43 leads marked as hot.',
      'Data Analysis Expert': '📊 Analysis complete. Conversion rate up 12% from last cycle.',
      'Deal Prediction Analyst': '📊 89% accuracy on deal predictions. 5 deals expected to close.',
      'CRM Sync Coordinator': '📊 Data synced. 0 conflicts detected.',
      'Workflow Orchestrator': '📊 Workflow execution: 100% steps completed.',
      'Security Monitor': '📊 All operations clean. 0 blocked actions.',
      'Contact Enrichment Agent': '📊 Enriched 156 contacts with 94% data coverage.',
      'Email Automation Specialist': '📊 23 emails sent. 67% open rate, 12% click rate.',
    },
    system: {
      'CRM Sync Coordinator': '🔄 All 5 connected CRMs synced successfully. Latency: 23ms avg.',
      'Security Monitor': '🔄 System integrity verified. All 2000 agents operational.',
      'Lead Scoring Specialist': '🔄 Ready for new commands.',
      'Data Analysis Expert': '🔄 Database healthy. 50 usage logs processed today.',
      'Workflow Orchestrator': '🔄 63 workflows loaded and ready.',
      'Contact Enrichment Agent': '🔄 All data sources connected.',
      'Email Automation Specialist': '🔄 Email service operational.',
      'Deal Prediction Analyst': '🔄 Predictive models loaded and calibrated.',
    },
    report: {
      'Data Analysis Expert': '📋 Report generated: 2000 agents, 100 departments, 63 workflows active.',
      'CRM Sync Coordinator': '📋 5/8 companies CRM-connected. 50 total API calls today.',
      'Security Monitor': '📋 10 security events logged. 0 critical threats.',
      'Lead Scoring Specialist': '📋 247 leads scored today. Average score: 78.',
      'Workflow Orchestrator': '📋 15 commands executed today. All completed.',
      'Contact Enrichment Agent': '📋 156 contacts enriched. 94% data accuracy.',
      'Email Automation Specialist': '📋 23 emails sent. 67% engagement rate.',
      'Deal Prediction Analyst': '📋 $340K pipeline predicted for this month.',
    },
    chat: {
      'Lead Scoring Specialist': '👋 Standing by. Ready to score leads on your command.',
      'CRM Sync Coordinator': '👋 All CRM connections stable. Awaiting instructions.',
      'Data Analysis Expert': '👋 Analytics engine ready. What would you like me to analyze?',
      'Workflow Orchestrator': '👋 63 workflows loaded. Ready to orchestrate any task.',
      'Security Monitor': '👤 All systems secure. Protection mode active.',
      'Contact Enrichment Agent': '👋 Ready to enrich and update contact data.',
      'Email Automation Specialist': '👋 Email engine warmed up. Ready to send.',
      'Deal Prediction Analyst': '👋 Predictive models running. Monitoring deal pipeline.',
    },
  }

  const typeMessages = messages[commandType] || messages.chat;
  return typeMessages[agent.name] || '✅ Task acknowledged and completed.';
}