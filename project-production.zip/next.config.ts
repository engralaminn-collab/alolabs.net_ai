import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  poweredByHeader: false,
  typescript: {
    ignoreBuildErrors: false,
  },
  reactStrictMode: true,
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: '**.space-z.ai' },
      { protocol: 'https', hostname: 'localhost', port: '9001' as any },
      { protocol: 'http', hostname: 'localhost', port: '9001' as any },
      { protocol: 'https', hostname: 'cdn.min.io' },
    ],
  },
  allowedDevOrigins: ["https://preview-chat-d1cdb6cf-cc69-4421-aad8-07d2511d9bec.space-z.ai", "http://preview-chat-d1cdb6cf-cc69-4421-aad8-07d2511d9bec.space-z.ai", "https://*.space-z.ai", "http://*.space-z.ai", "127.0.0.1", "localhost", "0.0.0.0"],
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'X-XSS-Protection', value: '1; mode=block' },
          { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
          { key: 'Strict-Transport-Security', value: 'max-age=31536000; includeSubDomains' },
          { key: 'Content-Security-Policy', value: "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self' ws: wss:; frame-ancestors 'none';" },
        ],
      },
      {
        source: '/api/:path*',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
        ],
      },
    ];
  },
};

export default nextConfig;
